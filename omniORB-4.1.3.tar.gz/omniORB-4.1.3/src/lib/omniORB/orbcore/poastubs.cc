// -*- Mode: C++; -*-
//                            Package   : omniORB
// poastubs.cc                Created on: 19/7/99
//                            Author    : David Riddoch (djr)
//
//    Copyright (C) 1996-1999 AT&T Research Cambridge
//
//    This file is part of the omniORB library
//
//    The omniORB library is free software; you can redistribute it and/or
//    modify it under the terms of the GNU Library General Public
//    License as published by the Free Software Foundation; either
//    version 2 of the License, or (at your option) any later version.
//
//    This library is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//    Library General Public License for more details.
//
//    You should have received a copy of the GNU Library General Public
//    License along with this library; if not, write to the Free
//    Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  
//    02111-1307, USA
//
//
// Description:
//
 
/*
  $Log: poastubs.cc,v $
  Revision 1.4.2.3  2005/11/09 12:22:17  dgrisby
  Local interfaces support.

  Revision 1.4.2.2  2005/01/13 21:55:55  dgrisby
  Turn off -g debugging; suppress some compiler warnings.

  Revision 1.4.2.1  2003/03/23 21:02:06  dgrisby
  Start of omniORB 4.1.x development branch.

  Revision 1.2.2.12  2002/05/28 22:00:39  dgrisby
  Incorrect repoIds.

  Revision 1.2.2.11  2002/01/16 11:32:00  dpg1
  Race condition in use of registerNilCorbaObject/registerTrackedObject.
  (Reported by Teemu Torma).

  Revision 1.2.2.10  2001/11/08 16:33:53  dpg1
  Local servant POA shortcut policy.

  Revision 1.2.2.9  2001/11/07 15:45:53  dpg1
  Faster _ptrToInterface/_ptrToObjRef in common cases.

  Revision 1.2.2.8  2001/10/17 16:44:07  dpg1
  Update DynAny to CORBA 2.5 spec, const Any exception extraction.

  Revision 1.2.2.7  2001/09/19 17:26:52  dpg1
  Full clean-up after orb->destroy().

  Revision 1.2.2.6  2001/08/15 10:26:14  dpg1
  New object table behaviour, correct POA semantics.

  Revision 1.2.2.5  2001/05/31 16:18:15  dpg1
  inline string matching functions, re-ordered string matching in
  _ptrToInterface/_ptrToObjRef

  Revision 1.2.2.4  2001/05/29 17:03:53  dpg1
  In process identity.

  Revision 1.2.2.3  2001/04/18 18:18:05  sll
  Big checkin with the brand new internal APIs.

  Revision 1.2.2.2  2000/09/27 18:03:40  sll
  Updated to use the new cdrStream abstraction.
  Updated to match the changes in the proxyFactory class.

  Revision 1.2.2.1  2000/07/17 10:35:57  sll
  Merged from omni3_develop the diff between omni3_0_0_pre3 and omni3_0_0.

  Revision 1.3  2000/07/13 15:25:56  dpg1
  Merge from omni3_develop for 3.0 release.

  Revision 1.1.2.5  2000/01/27 10:55:47  djr
  Mods needed for powerpc_aix.  New macro OMNIORB_BASE_CTOR to provide
  fqname for base class constructor for some compilers.

  Revision 1.1.2.4  1999/10/29 13:18:19  djr
  Changes to ensure mutexes are constructed when accessed.

  Revision 1.1.2.3  1999/10/16 13:22:54  djr
  Changes to support compiling on MSVC.

  Revision 1.1.2.2  1999/10/04 17:08:34  djr
  Some more fixes/MSVC work-arounds.

  Revision 1.1.2.1  1999/09/22 14:27:03  djr
  Major rewrite of orbcore to support POA.

*/

#include <omniORB4/CORBA.h>
#include <omniORB4/callDescriptor.h>
#include <omniORB4/objTracker.h>

OMNI_USING_NAMESPACE(omni)

//////////////////////////////////////////////////////////////////////
/////////////////////////// ForwardRequest ///////////////////////////
//////////////////////////////////////////////////////////////////////

CORBA::Exception::insertExceptionToAny PortableServer::ForwardRequest::insertToAnyFn = 0;
CORBA::Exception::insertExceptionToAnyNCP PortableServer::ForwardRequest::insertToAnyFnNCP = 0;

PortableServer::ForwardRequest::ForwardRequest(const PortableServer::ForwardRequest& _s) : CORBA::UserException(_s)
{
  forward_reference = _s.forward_reference;
}

PortableServer::ForwardRequest::ForwardRequest(CORBA::Object_ptr _forward_reference)
{
  pd_insertToAnyFn    = PortableServer::ForwardRequest::insertToAnyFn;
  pd_insertToAnyFnNCP = PortableServer::ForwardRequest::insertToAnyFnNCP;
  CORBA::Object_Helper::duplicate(_forward_reference);
  forward_reference = _forward_reference;
}

PortableServer::ForwardRequest& PortableServer::ForwardRequest::operator=(const PortableServer::ForwardRequest& _s)
{
  ((CORBA::UserException*) this)->operator=(_s);
  forward_reference = _s.forward_reference;
  return *this;
}

PortableServer::ForwardRequest::~ForwardRequest() {}

void PortableServer::ForwardRequest::_raise() const { throw *this; }

PortableServer::ForwardRequest* PortableServer::ForwardRequest::_downcast(CORBA::Exception* e) {
  return (ForwardRequest*) _NP_is_a(e, "Exception/UserException/PortableServer::ForwardRequest");
}

const PortableServer::ForwardRequest* PortableServer::ForwardRequest::_downcast(const CORBA::Exception* e) {
  return (const ForwardRequest*) _NP_is_a(e, "Exception/UserException/PortableServer::ForwardRequest");
}

const char* PortableServer::ForwardRequest::_PD_repoId = "IDL:omg.org/PortableServer/ForwardRequest:1.0";

CORBA::Exception* PortableServer::ForwardRequest::_NP_duplicate() const {
  return new ForwardRequest(*this);
}

const char* PortableServer::ForwardRequest::_NP_typeId() const {
  return "Exception/UserException/PortableServer::ForwardRequest";
}

const char* PortableServer::ForwardRequest::_NP_repoId(int* _size) const {
  *_size = sizeof("IDL:omg.org/PortableServer/ForwardRequest:1.0");
  return "IDL:omg.org/PortableServer/ForwardRequest:1.0";
}

void PortableServer::ForwardRequest::_NP_marshal(cdrStream& _s) const {
  *this >>= _s;
}

void
PortableServer::ForwardRequest::operator>>= (cdrStream& _n) const
{
  CORBA::Object_Helper::marshalObjRef(forward_reference,_n);
}

void
PortableServer::ForwardRequest::operator<<= (cdrStream& _n)
{
  forward_reference = CORBA::Object_Helper::unmarshalObjRef(_n);
}

PortableServer::AdapterActivator_ptr PortableServer::AdapterActivator_Helper::_nil() {
  return PortableServer::AdapterActivator::_nil();
}

CORBA::Boolean PortableServer::AdapterActivator_Helper::is_nil(PortableServer::AdapterActivator_ptr p) {
  return CORBA::is_nil(p);
}

void PortableServer::AdapterActivator_Helper::release(PortableServer::AdapterActivator_ptr p) {
  CORBA::release(p);
}

void PortableServer::AdapterActivator_Helper::duplicate(PortableServer::AdapterActivator_ptr p) {
  if( p && !p->_NP_is_nil() )  p->_NP_incrRefCount();
}

void PortableServer::AdapterActivator_Helper::marshalObjRef(PortableServer::AdapterActivator_ptr obj, cdrStream& s) {
  PortableServer::AdapterActivator::_marshalObjRef(obj, s);
}

PortableServer::AdapterActivator_ptr PortableServer::AdapterActivator_Helper::unmarshalObjRef(cdrStream& s) {
  return PortableServer::AdapterActivator::_unmarshalObjRef(s);
}


void
PortableServer::AdapterActivator::_NP_incrRefCount()
{
  if (_NP_is_pseudo())
    _add_ref();
  else
    omni::duplicateObjRef(_PR_getobj());
}

void
PortableServer::AdapterActivator::_NP_decrRefCount()
{
  if (_NP_is_pseudo())
    _remove_ref();
  else
    omni::releaseObjRef(_PR_getobj());
}

PortableServer::AdapterActivator_ptr
PortableServer::AdapterActivator::_duplicate(PortableServer::AdapterActivator_ptr obj)
{
  if( obj && !obj->_NP_is_nil() )  obj->_NP_incrRefCount();
  return obj;
}


PortableServer::AdapterActivator_ptr
PortableServer::AdapterActivator::_narrow(CORBA::Object_ptr obj)
{
  if( !obj || obj->_NP_is_nil() ) return _nil();
  if( obj->_NP_is_pseudo() ) {
    _ptr_type e = (_ptr_type) obj->_ptrToObjRef(_PD_repoId);
    if (e) {
      e->_NP_incrRefCount();
      return e;
    }
    else {
      return _nil();
    }
  }
  else {
    _ptr_type e = (_ptr_type) obj->_PR_getobj()->_realNarrow(_PD_repoId);
    return e ? e : _nil();
  }
}

PortableServer::AdapterActivator_ptr
PortableServer::AdapterActivator::_unchecked_narrow(CORBA::Object_ptr obj)
{
  return _narrow(obj);
}


PortableServer::AdapterActivator_ptr
PortableServer::AdapterActivator::_nil()
{
  static _objref_AdapterActivator* _the_nil_ptr = 0;
  if( !_the_nil_ptr ) {
    omni::nilRefLock().lock();
    if( !_the_nil_ptr ) {
      _the_nil_ptr = new _objref_AdapterActivator();
      registerNilCorbaObject(_the_nil_ptr);
    }
    omni::nilRefLock().unlock();
  }
  return _the_nil_ptr;
}


const char* PortableServer::AdapterActivator::_PD_repoId = "IDL:omg.org/PortableServer/AdapterActivator:1.0";


PortableServer::AdapterActivator::AdapterActivator()
{
  _PR_setobj((omniObjRef*)1);
}

PortableServer::AdapterActivator::~AdapterActivator() {}

PortableServer::_objref_AdapterActivator::~_objref_AdapterActivator() {}


PortableServer::_objref_AdapterActivator::_objref_AdapterActivator(omniIOR* ior,
         omniIdentity* id)
 : omniObjRef(PortableServer::AdapterActivator::_PD_repoId, ior, id, 1)
{
  _PR_setobj(this);
}


void*
PortableServer::AdapterActivator::_ptrToObjRef(const char* id)
{
  if( id == PortableServer::AdapterActivator::_PD_repoId )
    return (PortableServer::AdapterActivator_ptr) this;

  if( id == CORBA::LocalObject::_PD_repoId )
    return (CORBA::LocalObject_ptr) this;

  if( id == CORBA::Object::_PD_repoId )
    return (CORBA::Object_ptr) this;

  if( omni::strMatch(id, PortableServer::AdapterActivator::_PD_repoId) )
    return (PortableServer::AdapterActivator_ptr) this;

  if( omni::strMatch(id, CORBA::LocalObject::_PD_repoId) )
    return (CORBA::LocalObject_ptr) this;

  if( omni::strMatch(id, CORBA::Object::_PD_repoId) )
    return (CORBA::Object_ptr) this;

  return 0;
}

void*
PortableServer::_objref_AdapterActivator::_ptrToObjRef(const char* id)
{
  if( id == PortableServer::AdapterActivator::_PD_repoId )
    return (PortableServer::AdapterActivator_ptr) this;

  if( id == CORBA::LocalObject::_PD_repoId )
    return (CORBA::LocalObject_ptr) this;

  if( id == CORBA::Object::_PD_repoId )
    return (CORBA::Object_ptr) this;

  if( omni::strMatch(id, PortableServer::AdapterActivator::_PD_repoId) )
    return (PortableServer::AdapterActivator_ptr) this;

  if( omni::strMatch(id, CORBA::LocalObject::_PD_repoId) )
    return (CORBA::LocalObject_ptr) this;

  if( omni::strMatch(id, CORBA::Object::_PD_repoId) )
    return (CORBA::Object_ptr) this;

  return 0;
}


// Proxy call descriptor class. Mangled signature:
//  _cboolean_i_cPortableServer_mPOA_i_cstring
class _0RL_cd_3c165f58b5a16b59_00000000
  : public omniLocalOnlyCallDescriptor
{
public:
  inline _0RL_cd_3c165f58b5a16b59_00000000(LocalCallFn lcfn, const char* op, size_t oplen, _CORBA_Boolean oneway, PortableServer::POA_ptr a_0, const char* a_1) :
    omniLocalOnlyCallDescriptor(lcfn, op, oplen, oneway),
    arg_0(a_0),
    arg_1(a_1)  {}

  inline CORBA::Boolean result() { return pd_result; }

  PortableServer::POA_ptr arg_0;
  const char* arg_1;
  CORBA::Boolean pd_result;
};


// Local call call-back function.
static void
_0RL_lcfn_3c165f58b5a16b59_10000000(omniCallDescriptor* cd, omniServant* svnt)
{
  _0RL_cd_3c165f58b5a16b59_00000000* tcd = (_0RL_cd_3c165f58b5a16b59_00000000*) cd;
  PortableServer::_impl_AdapterActivator* impl = (PortableServer::_impl_AdapterActivator*) svnt->_ptrToInterface(PortableServer::AdapterActivator::_PD_repoId);
  tcd->pd_result = impl->unknown_adapter(tcd->arg_0, tcd->arg_1);
}


CORBA::Boolean PortableServer::_objref_AdapterActivator::unknown_adapter(PortableServer::POA_ptr parent, const char* name)
{
  _0RL_cd_3c165f58b5a16b59_00000000 _call_desc(_0RL_lcfn_3c165f58b5a16b59_10000000, "unknown_adapter", 16, 0, parent, name);

  _invoke(_call_desc);
  return _call_desc.result();
}


PortableServer::_pof_AdapterActivator::~_pof_AdapterActivator() {}


omniObjRef*
PortableServer::_pof_AdapterActivator::newObjRef(omniIOR* ior,omniIdentity* id)
{
  return new PortableServer::_objref_AdapterActivator(ior, id);
}


CORBA::Boolean
PortableServer::_pof_AdapterActivator::is_a(const char* id) const
{
  if( omni::ptrStrMatch(id, PortableServer::AdapterActivator::_PD_repoId) )
    return 1;

  return 0;
}


const PortableServer::_pof_AdapterActivator _the_pof_PortableServer_mAdapterActivator;


PortableServer::_impl_AdapterActivator::~_impl_AdapterActivator() {}


CORBA::Boolean
PortableServer::_impl_AdapterActivator::_dispatch(omniCallHandle& handle)
{
  return 0;
}


void*
PortableServer::_impl_AdapterActivator::_ptrToInterface(const char* id)
{
  if( id == PortableServer::AdapterActivator::_PD_repoId )
    return (_impl_AdapterActivator*) this;
  if( id == CORBA::Object::_PD_repoId )
    return (void*) 1;

  if( omni::strMatch(id, PortableServer::AdapterActivator::_PD_repoId) )
    return (_impl_AdapterActivator*) this;
  if( omni::strMatch(id, CORBA::Object::_PD_repoId) )
    return (void*) 1;

  return 0;
}


const char*
PortableServer::_impl_AdapterActivator::_mostDerivedRepoId()
{
  return PortableServer::AdapterActivator::_PD_repoId;
}


PortableServer::ServantManager_ptr PortableServer::ServantManager_Helper::_nil() {
  return PortableServer::ServantManager::_nil();
}

CORBA::Boolean PortableServer::ServantManager_Helper::is_nil(PortableServer::ServantManager_ptr p) {
  return CORBA::is_nil(p);
}

void PortableServer::ServantManager_Helper::release(PortableServer::ServantManager_ptr p) {
  CORBA::release(p);
}

void PortableServer::ServantManager_Helper::duplicate(PortableServer::ServantManager_ptr p) {
  if( p && !p->_NP_is_nil() )  p->_NP_incrRefCount();
}

void PortableServer::ServantManager_Helper::marshalObjRef(PortableServer::ServantManager_ptr obj, cdrStream& s) {
  PortableServer::ServantManager::_marshalObjRef(obj, s);
}

PortableServer::ServantManager_ptr PortableServer::ServantManager_Helper::unmarshalObjRef(cdrStream& s) {
  return PortableServer::ServantManager::_unmarshalObjRef(s);
}

void
PortableServer::ServantManager::_NP_incrRefCount()
{
  if (_NP_is_pseudo())
    _add_ref();
  else
    omni::duplicateObjRef(_PR_getobj());
}

void
PortableServer::ServantManager::_NP_decrRefCount()
{
  if (_NP_is_pseudo())
    _remove_ref();
  else
    omni::releaseObjRef(_PR_getobj());
}


PortableServer::ServantManager_ptr
PortableServer::ServantManager::_duplicate(PortableServer::ServantManager_ptr obj)
{
  if( obj && !obj->_NP_is_nil() )  obj->_NP_incrRefCount();
  return obj;
}


PortableServer::ServantManager_ptr
PortableServer::ServantManager::_narrow(CORBA::Object_ptr obj)
{
  if( !obj || obj->_NP_is_nil() ) return _nil();
  if( obj->_NP_is_pseudo() ) {
    _ptr_type e = (_ptr_type) obj->_ptrToObjRef(_PD_repoId);
    if (e) {
      e->_NP_incrRefCount();
      return e;
    }
    else {
      return _nil();
    }
  }
  else {
    _ptr_type e = (_ptr_type) obj->_PR_getobj()->_realNarrow(_PD_repoId);
    return e ? e : _nil();
  }
}

PortableServer::ServantManager_ptr
PortableServer::ServantManager::_unchecked_narrow(CORBA::Object_ptr obj)
{
  return _narrow(obj);
}

PortableServer::ServantManager_ptr
PortableServer::ServantManager::_nil()
{
  static _objref_ServantManager* _the_nil_ptr = 0;
  if( !_the_nil_ptr ) {
    omni::nilRefLock().lock();
    if( !_the_nil_ptr ) {
      _the_nil_ptr = new _objref_ServantManager();
      registerNilCorbaObject(_the_nil_ptr);
    }
    omni::nilRefLock().unlock();
  }
  return _the_nil_ptr;
}


const char* PortableServer::ServantManager::_PD_repoId = "IDL:omg.org/PortableServer/ServantManager:1.0";

PortableServer::ServantManager::ServantManager()
{
  _PR_setobj((omniObjRef*)1);
}

PortableServer::ServantManager::~ServantManager() {}

PortableServer::_objref_ServantManager::~_objref_ServantManager() {}


PortableServer::_objref_ServantManager::_objref_ServantManager(omniIOR* ior,
         omniIdentity* id)
 : omniObjRef(PortableServer::ServantManager::_PD_repoId, ior, id, 1)
{
  _PR_setobj(this);
}


void*
PortableServer::ServantManager::_ptrToObjRef(const char* id)
{
  if( id == PortableServer::ServantManager::_PD_repoId )
    return (PortableServer::ServantManager_ptr) this;

  if( id == CORBA::LocalObject::_PD_repoId )
    return (CORBA::LocalObject_ptr) this;

  if( id == CORBA::Object::_PD_repoId )
    return (CORBA::Object_ptr) this;

  if( omni::strMatch(id, PortableServer::ServantManager::_PD_repoId) )
    return (PortableServer::ServantManager_ptr) this;

  if( omni::strMatch(id, CORBA::LocalObject::_PD_repoId) )
    return (CORBA::LocalObject_ptr) this;

  if( omni::strMatch(id, CORBA::Object::_PD_repoId) )
    return (CORBA::Object_ptr) this;

  return 0;
}

void*
PortableServer::_objref_ServantManager::_ptrToObjRef(const char* id)
{
  if( id == PortableServer::ServantManager::_PD_repoId )
    return (PortableServer::ServantManager_ptr) this;

  if( id == CORBA::LocalObject::_PD_repoId )
    return (CORBA::LocalObject_ptr) this;

  if( id == CORBA::Object::_PD_repoId )
    return (CORBA::Object_ptr) this;

  if( omni::strMatch(id, PortableServer::ServantManager::_PD_repoId) )
    return (PortableServer::ServantManager_ptr) this;

  if( omni::strMatch(id, CORBA::LocalObject::_PD_repoId) )
    return (CORBA::LocalObject_ptr) this;

  if( omni::strMatch(id, CORBA::Object::_PD_repoId) )
    return (CORBA::Object_ptr) this;

  return 0;
}


PortableServer::_pof_ServantManager::~_pof_ServantManager() {}


omniObjRef*
PortableServer::_pof_ServantManager::newObjRef(omniIOR* ior, omniIdentity* id)
{
  return new PortableServer::_objref_ServantManager(ior, id);
}


CORBA::Boolean
PortableServer::_pof_ServantManager::is_a(const char* id) const
{
  if( omni::ptrStrMatch(id, PortableServer::ServantManager::_PD_repoId) )
    return 1;

  return 0;
}


const PortableServer::_pof_ServantManager _the_pof_PortableServer_mServantManager;


PortableServer::_impl_ServantManager::~_impl_ServantManager() {}


CORBA::Boolean
PortableServer::_impl_ServantManager::_dispatch(omniCallHandle& handle)
{
  return 0;
}


void*
PortableServer::_impl_ServantManager::_ptrToInterface(const char* id)
{
  if( id == PortableServer::ServantManager::_PD_repoId )
    return (_impl_ServantManager*) this;
  if( id == CORBA::Object::_PD_repoId )
    return (void*) 1;

  if( omni::strMatch(id, PortableServer::ServantManager::_PD_repoId) )
    return (_impl_ServantManager*) this;
  if( omni::strMatch(id, CORBA::Object::_PD_repoId) )
    return (void*) 1;

  return 0;
}


const char*
PortableServer::_impl_ServantManager::_mostDerivedRepoId()
{
  return PortableServer::ServantManager::_PD_repoId;
}


PortableServer::ServantActivator_ptr PortableServer::ServantActivator_Helper::_nil() {
  return PortableServer::ServantActivator::_nil();
}

CORBA::Boolean PortableServer::ServantActivator_Helper::is_nil(PortableServer::ServantActivator_ptr p) {
  return CORBA::is_nil(p);
}

void PortableServer::ServantActivator_Helper::release(PortableServer::ServantActivator_ptr p) {
  CORBA::release(p);
}

void PortableServer::ServantActivator_Helper::duplicate(PortableServer::ServantActivator_ptr p) {
  if( p && !p->_NP_is_nil() )  p->_NP_incrRefCount();
}

void PortableServer::ServantActivator_Helper::marshalObjRef(PortableServer::ServantActivator_ptr obj, cdrStream& s) {
  PortableServer::ServantActivator::_marshalObjRef(obj, s);
}

PortableServer::ServantActivator_ptr PortableServer::ServantActivator_Helper::unmarshalObjRef(cdrStream& s) {
  return PortableServer::ServantActivator::_unmarshalObjRef(s);
}


PortableServer::ServantActivator_ptr
PortableServer::ServantActivator::_duplicate(PortableServer::ServantActivator_ptr obj)
{
  if( obj && !obj->_NP_is_nil() )  obj->_NP_incrRefCount();
  return obj;
}


PortableServer::ServantActivator_ptr
PortableServer::ServantActivator::_narrow(CORBA::Object_ptr obj)
{
  if( !obj || obj->_NP_is_nil() ) return _nil();
  if( obj->_NP_is_pseudo() ) {
    _ptr_type e = (_ptr_type) obj->_ptrToObjRef(_PD_repoId);
    if (e) {
      e->_NP_incrRefCount();
      return e;
    }
    else {
      return _nil();
    }
  }
  else {
    _ptr_type e = (_ptr_type) obj->_PR_getobj()->_realNarrow(_PD_repoId);
    return e ? e : _nil();
  }
}

PortableServer::ServantActivator_ptr
PortableServer::ServantActivator::_unchecked_narrow(CORBA::Object_ptr obj)
{
  return _narrow(obj);
}

PortableServer::ServantActivator_ptr
PortableServer::ServantActivator::_nil()
{
  static _objref_ServantActivator* _the_nil_ptr = 0;
  if( !_the_nil_ptr ) {
    omni::nilRefLock().lock();
    if( !_the_nil_ptr ) {
      _the_nil_ptr = new _objref_ServantActivator();
      registerNilCorbaObject(_the_nil_ptr);
    }
    omni::nilRefLock().unlock();
  }
  return _the_nil_ptr;
}


const char* PortableServer::ServantActivator::_PD_repoId = "IDL:omg.org/PortableServer/ServantActivator:1.0";

PortableServer::ServantActivator::ServantActivator()
{
  _PR_setobj((omniObjRef*)1);
}

PortableServer::ServantActivator::~ServantActivator() {}

PortableServer::_objref_ServantActivator::~_objref_::ptrStrMatch(id, Porta aglCorbaObject(_the_nil_ptr);

tr o

PortableServer::ServantActivatg.org/Portablen PPortableSerg->pd_cRi1;

  if( omivant0antManager::_objref_ServantManager(omniIOR* ior,
          if( omni::strMatch(id, CORBA::Object::_PD_repoId) )
    return (CORB;
      registerNilCorbaObjecf( id == CORBA::Object::_PD_repoId )
_AdapterActivator::_ptrToObjRef(co)
    return (CORBA::Object_ptr) this;

  return 0;
}

void*
PortableServer::_objref_ServantManager::_ptrToObjRef(const char* id)
{
  if( id == PortableServer::ServantManager::_PD_repoId )
    return (PortableServer::ServantManager_ptr) this;

  if( id == CORBA::LocalObject::_PD_repoId )
    return (CORBA::LocalObject_ptr) this;

  if( id == CORBA::Object::_PD_repopoId )
_AdapterActivator::_ptrToObjct::_PD_repoId )
    return (CORBA::LocalObject_ptr) this;

  if( id == CORBA::Object::_PD_repoId )
    return (CORBA::Object_ptr) this;

  if( omni::strMatch(id, PortableServer::ServantManager::_PD_repoId) )
    return (PortableServer::ServantManager_ptr) this;

  if( omni::strMatch(id, CORBA::LocalObject::_PD_repoId) )
    return (CORBA::LocalObject_ptr) this;

  if( omni::strMatch(id, CORBA::Object::_PD_repoId) )
    return (CORB;
      registerNilCorbaObjecf( id == CORBA::Object::_PD_repoId )
_AdapterActivator::_ptrToObjRef(co)
    return (CORBA::Object_ptr) this;

  return 0;
}

void*
PortableServer::_objref_ServantManager::_ptrToObjRef(const char* id)
{
  if( id == PortableServer::ServantManager::_PD_repoId )
    return (PortableServer::ServantManager_ptr) this;

  if( id == CORBA::LocalObject::_PD_repoId )
    return (CORBA::LocalObject_ptr) this;

  if( id == CORBA::Object::_PD_repopoId )
_AdapterActivator::_ptrToObjct::_PD_repoId )
    return (CORBA::LocalObject_ptr) this;

  if( id == CORBA::Object::_PD_repoId )
    return (CORBA::Object_ptr) this;

  if( omni::strMatch(id, PortableServer::ServantManager::_PD_repoId) )
    return (PortableServer::ServantManager_ptr) this;

  if( omni::strMatch(id, CORBA::LocalObject::_PD_repoId) )
    return(CORBA::LocalObject_ptr) this;

  if( omni::enA::Lo omivantg_1;
  CORBA:_svnown_adap000
  : public*st ch  if (_NP_isvn  _add_ register=  if( id == COR::Object::_isvn* tcd = (_0RL_cd_3::  return (CORBA::LocalObject_ptr) this;

  ife
    omni::d_ register= rrow(t chaleturver chrow(  return (CORBA::LocalObject_ptr) this;

  if( omni::strMatch( regiBA::Object::_PD_repo:LocalIdBA::Object::_PD_repoId) e::Object::_PD_repoerver::Forwardurn (CORBA::Object_ptr) this;

 2return 0;
}


// Proxy call descriptor class. Mangled signature:
//  _cboolean_i_cPortableS2return OA_i_cstring
class _0RL_cd_3c165f58b5a16b59_00000000
  : public omniLocatManager::is_a(const c:LocalId&ublic:
  tcd->pd_result = implRL_cd_3c165f58b5a16b59_00000000(LocalCallFn lcfn, const char* op, size_t oplen, _CORBA_Boolean oneway, Portabl  return (CORBA::LocalOtr a_0, const char* a_1) :
    omnitManager::is_a(const c:LocalId&ubcfn, op,
  tcd->pd_result = implRy),
      return (CORBA::LocalOt arg_1(a_1)  {}

  inline CORBA::Boolean result() { return pd_result; }

  PortableServer3:POA_ptr arg_0;
  const char* arg_1;
  CORBA::Boolean pd_result;
};


// Local c2return -back function.
static void
_0RL_l2return -f58b5a16b59_10000000(omniCallDA::Object_ptr obj)iServant* svnt)
{
  _0RL_cd_3c == COR::Object::_00000* tcd = (_0RL_cd_3c165f58b5a16b59_:LocalObject_ptr) this;

  ife
  _impl_AdapterActivator*incarnretueServer::_impl_AdapterActivat  return (CORBA::LocalOtCORBA::LocalObject_ptr) this;

  if( omni:incarnretutManager::is_a(const c:LocalId&uo)
    return (CORBA:t = implR) )
  lean pdCallDA::Object_ptr obj)_srver:registe;f (_NP_is///////////
s*t chalet)eudo() ) {
    _psr*incarnretuo)
  R) )
  l( obj->_NP_is_pseudo() ) :enA::Lo omivant0,0nil_ptr =
  drm absrough 1.1n

  Bosthar*e e = (_ptr_tction.
static void
_0RL_l2return ortableServer::_objref_AdapterActivator3:POA_pt, "incarnretServ0r::POo)
  R) )
  l( 
nst char* name)
{
  _0RL_cd_3c165f58b5a16b59_00000000 _caurn (CORBA::LocalObject_ptr) this;

  if( omni::strMatcn pdBA::Object::_PD_repo:LocalIdBA::Object::_PD_repoId) ih( regiBA::id, CORBA::id, CORurn (CORBA::Object_ptr) this;

 4return 0;
}


// Proxy call descriptor class. Mangled signature:
//  _cboolean_i_cPortableS4return OA_i_cstring
class _0RL_cd_3c165f58b5a16b59_00000000
  : public omniLocatManager::is_a(const c:LocalId&ublic:
  tcd->pd_result = implRL_    return (CORBA::LocalOlRL2, arg_0(a_0),
   a_3, arg_0(a_0),
   a_4cd_3c165f58b5a16b59_00000000(LocalCallFn lcfn, const char* op, size_t oplen, _CORBA_Boolean  _CORBA_Bo2lea2  _CORBA_Bo3lea3  _CORBA_Bo4(a_4cdneway, tManager::is_a(const c:LocalId&ubcfn, op,
  tcd->pd_result = implRy),
      return (CORBA::LocalOtA_Bo2    arg_0(a_0),
   A_Bo3    arg_0(a_0),
   A_Bo41)  {}

  inline CORBA::Boolean result() { return pd_result; }

  PortableServer5:POA_ptr arg_0;
  const char* arg_1;
  CORBA::Boolean pd_result;
};


// Local c4return -back function.
static void
_0RL_l4return -f58b5a16b59_10000000(omniCallDA::Object_ptr obj)iServant* svnt)
{
  _0RL_cd_3c == COR::Object::_00000* tcd = (_0RL_cd_3c165f58b5a16b59_:LocalObject_ptr) this;

  ife
  vator*eibutealeztueServer::_impl_Adapterimpl_Adapte2impl_Adapte3impl_Adapte4ervantManagtCORBA::LocalObject_ptr) this;

  if( omni:eibutealeztutManager::is_a(const c:LocalId&uo)
    return (CORBA:t = implR) )
      return (CORBA::LocalOlsLoc, arg_0(a_0),
   1/10/upt c_prog.4.2, arg_0(a_0),
   rkipInput_a if( o0:26lean pdCallDA::Object_ptr obj)_srver:registe;f (_NP_is///////////
s*t chalet)eudo() ) psr*eibutealeztuo)
  R) )
  ,lsLoc, 1/10/upt c_prog.4.2, rkipInput_a if( o0:26l;_cd_3c1( obj->_NP_is_pseudo() ) :enA::Lo omivant0,0nil_ptr =
  drm absrough 1.1n

  Bosthar*e e = (_ptr_tction.
static void
_0RL_l4return ortableServer::_objref_AdapterActivator5:POA_pt, "eibutealeztServ2r::POo)
  R) )
  ,lsLoc, 1/10/upt c_prog.4.2, rkipInput_a if( o0:26l; 
nst char* name)
{
  _0R return (CORBA::LocalObject_ptr)a16b59_10000000, {
  _PR_setobj((omniObjRA::Object::_PD_repoId) )
    return (COR
  return _call_desc.result();
}


						0;
}


PortableServer::_pof_ServantManager::~_pof_ServantManager( {}


omniObjRef*
PortableServer::_pof_AdapterActivator::newthis;

  if( omni:iior, omniIdentity* id)
{
  return new PortableServer::_objref_ServantManager(io id);
}


CORBA::Boolean
PortableServereturn new PortableServer::_objref_ServantManager(ior, id);
}


CORBA::Boolean
PortableServer::_pof_ServantManager::is_a(const char* id) con
{
  if( omni::ptrStrMatch(id, Portid) con
{
  if( ::ServantManager::_PD_repoId) )
 eturn 1;

  return{
  _PR_setobj((omniObjRrtableServer::_pof_ServantManager _the_pof_PeServer_mAdapterActivator;


PortableServer::_impl_AdapterActivator::~_impl_AdapterActivatothis;

  if( omni::strMaean
PortableServer::_impl_ServantManager::_dispatch(omniCallHane& handle)
{
  return 0;
}


void*
Portabl == COR::Object::_0l_ServantManager::RBA::Object_ptr) this;

  return 0;
}

vod*
PortableServer::_impl_ServantManager::_ptrToInterface(const char* id)
{
  if( id == PortableServer::ServantManager::_PD_repoId )
    retu (_impl_AdapterActivator*) this;
  if( id = == COR::Object::_0l_ServantManver::ServantManager:LocalObject_ptr) this;

  if( id == CORBAif( id == CORBA::Object::_PD_repoId )
    return (void*) 1;

  if( omni::strMatch(id, PortableServer::ServantManager::_PD_repoId) )
    return (_impl_ServantManager*) this;
  if( omni::strMatch(id, CORBA::Object::_PD_repoI   retu (_impl_AdapterActivactivat  return (CORBA::LocalOtion;eServer::ServantActivator_ptr tion;eSeerivedRepoId()
{
  return PortableServer::Servanttion;eS_PD_repoId;
}


PortableServer::ServantActivator_pttion;eSeerivedReServantActivator_Helper::_nil(tion;eServerortableServer::ServantActivator::_nil();
}

CORBA::Boolean Porttion;eSeerivedRetActivator_Helper::is_nil(Portation;eServerortableivator_ptr p) {
  return CORBA::is_nil(p);
}

voidtion;eSeerivedRe) {
  return PortableServer::Servtion;eServerortabletActivator_ptr p) {
  CORBA::release(p);
}

void PortableServer::ServantActivator_Htion;eSeerivedReortableServer::ServantActivator_ptr ption;eServer !p->_NP_is_nil() )  p->_NP_incrRefCount();
}
tion;eS_PDleServer::ServantActivator_Helper::marshalObjRef(tion;eServer::ServantActivator_ptr tion;eSeerivedRe {
  PortableServer::ServantActivator::_marshalObjRef(obj, s);
}tion;eS_PDrver::ServantActivator_ptr PortableServer::Servtion;eServeptr PortableServer::Servtion;eS& s) {
  return PortableServer::Servtion;eServer !pmarshalObjRef(s);
}


PortableServer::ServantActivator_ptr
PortableServer::ServantActivator::_duplicate(Ption;eServeptr PortableServer::Servtion;eS& sobj && !obj->_NP_is_nil() )  obj->_NP_incrRefCount();
  return obj;
}


PortableServer::ServantActivator_ptr
PortableServer::ServantActivator::_narrow(CORBA::Object_ptr obj)
{
  if( !obj || obj->_NP_is_nil() ) return _nil();
  if( obj->_NP_is_pseudo() ) {
    _ptr_type e = (_ptr_type) obj->_ptrToObjRef(_PD_repoId);
    if (e) {
      e->_NP_incrRefCount();
      return e;
    }
    else {
      return _nil();
    }
tion;eServeptr PortableServer::Servtion;eS& sPR_getobj()->_realNarrow(_PD_repoId);
    return e ? e : _nil();
  }
}

PortableServeicate(Ption;eServeptr PortableServer::Servtion;eS& so::_unchecked_narrow(CORBA::Objetion;eSj)
{
  return _narrow(obj);
}

PortableServer::ServantActivator_ptr
PortableServer::ServantActivator::_nil()
{
  static _objref_ServantActivation;eS_nil_ptr = 0;
  if( !_the_nil_ptr ) {
    omni::nilRefLock().lock();
    if( !_the_nil_ptr ) {
      _the_nil_ptr = new _objref_ServantActivator();
     tion;eS& sCorbaObject(_the_nil_ptr);
    }
    omni::nilRtion;eS&nlock();
  }
  return _t;
     tion;eS& tActivation;eS_neServer::ServantActivator::_PD_repoId = "IDL:omg.org/Portabtion;eS& ~tActivation;eS_nniObjRef*)1);
}

PortableServer::Servtion;eS& ~f_ServantActivation;eS_nniObjRef*)1);
}

PortableServer::Servtion;eS& f_ServantActivation;eS_

PortableServer::_objref_ServantActivator::~_objref_::ptrStrMatch(id, Porta ation;eS& sCorbaObjel_ptr);

tr o

PortableServer::ServantActivatg.org/Portablen PPortableSerg->pd_cRi1;

  if( omivant0antManager::_objref_ServantManager(omniIOR* ior,
        tion;eS& sstrMatch(id, CORBA::Object::_PD_repoId) )
    return (CORB;
     tion;eS& sCorbaObjecf( id == CORBA::Object::_PD_repoId )
tion;eServeator::_ptrToObjRef(co)
    return (CORBA::Object_ptr) this;

  return 0;
}

void*
PortableServer::_objref_ServantManager::_ptrToObjRef(const char* id)
{
  if( id == PortableServer::ServantManager::_PD_repoId )
    return (PortableServer::ServantManager_ptr) this;

  if( id == CORBA::LocalObject::_PD_repoId )
    return (CORBA::LocalOtion;eS& sCorbaObje if( id == CORBA::Object::_PD_repoId )
tion;eServeator::_ptrToObjct::_PD_repoId )
    return (CORBA::LocalObject_ptr) this;

  if( id == CORBA::Object::_PD_repoId )
    return (CORBA::Object_ptr) this;

  if( omni::strMatch(id, PortableServer::ServantManager::_PD_repoId) )
    return (PortableServer::ServantManager_ptr) this;

  if( omni::strMatch(id, CORBA::LocalObject::_PD_repoId) )
    return (CORBA::LocalObject_ptr) this;

tion;eS& sstrMatch(id, CORBA::Object::_PD_repoId) )
    return (CORB;
     tion;eS& sCorbaObjecf( id == CORBA::Object::_PD_repoId )
tion;eServeator::_ptrToObjRef(co)
    return (CORBA::Object_ptr) this;

  return 0;
}

void*
PortableServer::_objref_ServantManager::_ptrToObjRef(const char* id)
{
  if( id == PortableServer::ServantManager::_PD_repoId )
    return (PortableServer::ServantManager_ptr) this;

  if( id == CORBA::LocalObject::_PD_repoId )
    return (CORBA::LocalOtion;eS& sCorbaObje if( id == CORBA::Object::_PD_repoId )
tion;eServeator::_ptrToObjct::_PD_repoId )
    return (CORBA::LocalObject_ptr) this;

  if( id == CORBA::Object::_PD_repoId )
    return (CORBA::Object_ptr) this;

  if( omni::strMatch(id, PortableServer::ServantManager::_PD_repoId) )
    return (PortableServer::ServantManager_ptr) this;

  if( omni::strMatch(id, CORBA::LocalObject::_PD_repoId) )
    return(CORBA::LocalObject_ptr) this;

tion;eS& senA::Lo omivantg_1;
  CORBA:_svnown_adap000
  : public*st ch  if (_NP_isvn  _add_ register=  if( id == CORtion;eSj_isvn* tcd = (_0RL_cd_3::  return (CORBA::LocalOtion;eS& sCorbaObje e
    omni::d_ register= rrow(t chaleturver chrow(  reurn (CORBA::LocalObject_ptr) this;

  if( omni::strMatch( regiBA::Object::_PD_repo:LocalIdBA::Object::_PD_repoId) )
    ret_oh( regiBe::Object::_PD_repoerver::Forwardurn (CORBA::Object_ptr) this;

 6return 0;
}


// Proxy call descriptor class. Mangled signature:
//  _cboolean_i_cPortableS6return OA_i_cstring
class _0RL_cd_3c165f58b5a16b59_00000000
  : public omniLocatManager::is_a(const c:LocalId&ublic:
  tcd->pd_result = implRL_  
  inline _0RL2    return (CORBA::LocalOtion;eS& Cookie&ubl3cd_3c165f58b5a16b59_00000000(LocalCallFn lcfn, const char* op, size_t oplen, _CORBA_Boolean  _CORBA_Bo2lea2  _CORBA_Bo3lea3 oneway, Portabl  return (CORBA::LocalOtr a_0, const char* a_1) :
    omnitManager::is_a(const c:LocalId&ubcfn, op,
  tcd->pd_result = implRy),
     oplen, oneway),2      return (CORBA::LocalOtion;eS& Cookie&ub_Bo3      return (CORBA::LocalOt arg_1(a_1)  {}

  inline CORBA::Boolean result() { return pd_result; }

  PortableServer7:POA_ptr arg_0;
  const char* arg_1;
  CORBA::Boolean pd_result;
};


// Local c6return -back function.
static void
_0RL_l6return -f58b5a16b59_10000000(omniCallDA::Objetion;eSj)iServant* svnt)
{
  _0RL_cd_3c == CORtion;eSj_00000* tcd = (_0RL_cd_3c165f58b5a16b59_:LocalOtion;eS& sCorbaObje e
  _impl_AdapterActivator*pre char* eServer::_impl_Adapterimpl_Adapte2impl_Adapte3Activat  return (CORBA::LocalOtCORBA::LocalObject_ptr) this;

tion;eS& pre char* tManager::is_a(const c:LocalId&uo)
    return (CORBA:t = implR) )
    _0RL_cd_3c165fest:lt(    return (CORBA::LocalOtion;eS& Cookie&u_thecookielean pdCallDA::Objetion;eSj)
srver:registe;f (_NP_is///////////
s*t chalet)eudo() ) {
    _psr*pre char* o)
  R) )
  ,l5fest:lt(  _thecookiel( obj->_NP_is_pseudo() ) :enA::Lo omivant0,0nil_ptr =
  drm absrough 1.1n

  Bosthar*e e = (_ptr_tction.
static void
_0RL_l6return ortableServer::_objref_AdapterActivator7:POA_pt, "pre char*Serv0r::POo)
  R) )
  ,l5fest:lt(  _thecookiel( 
nst char* name)
{
  _0RL_cd_3c165f58b5a16b59_00000000 _caurn (CORBA::LocalObject_ptr) this;

  if( omni::strMatcn pdBA::Object::_PD_repo:LocalIdBA::Object::_PD_repoId) ih(   ret_ih( regiBA:: regiurn (CORBA::Object_ptr) this;

 8return 0;
}


// Proxy call descriptor class. Mangled signature:
//  _cboolean_i_cPortableS8return OA_i_cstring
class _0RL_cd_3c165f58b5a16b59_00000000
  : public omniLocatManager::is_a(const c:LocalId&ublic:
  tcd->pd_result = implRL_  
  inline _0RL2    return (CORBA::LocalOtion;eS& Cookie a_3,   return (CORBA::LocalOlRL4cd_3c165f58b5a16b59_00000000(LocalCallFn lcfn, const char* op, size_t oplen, _CORBA_Boolean  _CORBA_Bo2lea2  _CORBA_Bo3lea3  _CORBA_Bo4(a_4cdneway, tManager::is_a(const c:LocalId&ubcfn, op,
  tcd->pd_result = implRy),
     oplen, oneway),2      return (CORBA::LocalOtion;eS& Cookieub_Bo3      return (CORBA::LocalOtA_Bo41)  {}

  inline CORBA::Boolean result() { return pd_result; }

  PortableServer9:POA_ptr arg_0;
  const char* arg_1;
  CORBA::Boolean pd_result;
};


// Local c8return -back function.
static void
_0RL_l8return -f58b5a16b59_10000000(omniCallDA::Objetion;eSj)iServant* svnt)
{
  _0RL_cd_3c == CORtion;eSj_00000* tcd = (_0RL_cd_3c165f58b5a16b59_:LocalOtion;eS& sCorbaObje e
  vator*post char* eServer::_impl_Adapterimpl_Adapte2impl_Adapte3impl_Adapte4ervantManagtCORBA::LocalObject_ptr) this;

tion;eS& post char* tManager::is_a(const c:LocalId&uo)
    return (CORBA:t = implR) )
    _0RL_cd_3c165fest:lt(    return (CORBA::LocalOtion;eS& Cookie _thecookie,   return (CORBA::LocalOl_thesLocalOlean pdCallDA::Objetion;eSj)
srver:registe;f (_NP_is///////////
s*t chalet)eudo() ) psr*post char* o)
  R) )
  ,l5fest:lt(  _thecookie,l_thesLocalOl;_cd_3c1( obj->_NP_is_pseudo() ) :enA::Lo omivant0,0nil_ptr =
  drm absrough 1.1n

  Bosthar*e e = (_ptr_tction.
static void
_0RL_l8return ortableServer::_objref_AdapterActivator9:POA_pt, "post char*Serv1r::POo)
  R) )
  ,l5fest:lt(  _thecookie,l_thesLocalOl; 
nst char* name)
{
  _0R return (CORBA::LocalObject_ptr)tion;eS& ~fObject_ptr)tion;eSomniObjRA::Object::_PD_repoId) )
    return (CORtion;eS& t_ptr) this;

  return 0;
}


PortableServer::_pof_ServantManager::~_pof_ServantManager(tion;eSoObjRef*
PortableServer::_pof_AdapterActivator::newthis;

tion;eS& iior, omniIdentity* id)
{
  return new PortableServer::_objref_ServantManager(iotion;eS& sCorbaObje if( id == CORBvereturn new PortableServer::_objref_ServantManager(ior, id);
}


CORBA::Boolean
PortableServer::_pof_ServantManager::is_a(const char* id) contion;eSomni::ptrStrMatch(id, Portid) contion;eS::ServantManager::_PD_repoId) )
 tion;eS& ~f_repoId) )
 tion;eSomniObjRrtableServer::_pof_ServantManager _the_pof_Ption;eS& s)terActivator;


PortableServer::_impl_AdapterActivator::~_impl_AdapterActivatothis;

tion;eS& sstrMaean
PortableServer::_impl_ServantManager::_dispatch(omniCallHantion;eS& sCorbaObjecf( id == CORBA_cd_3c == CORtion;eSj_0l_ServantManager::RBA::Object_ptr) this;

  return 0;
}

vod*
PortableServer::_impl_ServantManager::_ptrToInterface(const char* id)
{
  if( id == PortableServer::ServantManager::_PD_repoId )
    retution;eS& sCorbaObje if( id == CORBA_cd_3c == CORtion;eSj_0l_ServantManver::ServantManager:LocalObject_ptr) this;

  if( id == CORBAif( id == CORBA::Object::_PD_repoId )
    return (void*) 1;

  if( omni::strMatch(id, PortableServer::ServantManager::_PD_repoId) )
    return (_impl_ServantManagetion;eS_PDlf( omni::strMatch(id, CORBA::Object::_PD_repoI   retution;eS& sCorbaObje0R retu = bject::_PD_repoIPortableServer/AdapterActivator:1.0";


Potu = bject::_PD_repoI:LocalObject_ptrerver/ServantManager:1tu = bject::_PD_repoI:LocalOleServer/ServantActivator:1.0";

Potu = bject::_PD_repoI:LocalOtion;eS& ~tActivation;eS_nniObjR                                                                                                                                                