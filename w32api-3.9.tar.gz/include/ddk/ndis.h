/*
 * ndis.h
 *
 * Network Device Interface Specification definitions
 *
 * This file is part of the w32api package.
 *
 * Contributors:
 *   Created by Casper S. Hornstrup <chorns@users.sourceforge.net>
 *
 * THIS SOFTWARE IS NOT COPYRIGHTED
 *
 * This source code is offered for use in the public domain. You may
 * use, modify or distribute it freely.
 *
 * This code is distributed in the hope that it will be useful but
 * WITHOUT ANY WARRANTY. ALL WARRANTIES, EXPRESS OR IMPLIED ARE HEREBY
 * DISCLAIMED. This includes but is not limited to warranties of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * DEFINES: i386                 - Target platform is i386
 *          _NDIS_               - Define only for NDIS library
 *          NDIS_MINIPORT_DRIVER - Define only for NDIS miniport drivers
 *          NDIS40               - Use NDIS 4.0 structures by default
 *          NDIS50               - Use NDIS 5.0 structures by default
 *          NDIS50_MINIPORT      - Building NDIS 5.0 miniport driver
 *          NDIS51_MINIPORT      - Building NDIS 5.1 miniport driver
 */
#ifndef __NDIS_H
#define __NDIS_H

#if __GNUC__ >=3
#pragma GCC system_header
#endif

#ifdef __cplusplus
extern "C" {
#endif

#include "ntddk.h"
#include "ntddndis.h"
#include "netpnp.h"
#include "netevent.h"
#include <winsock2.h>

#if defined(_NDIS_)
  #define NDISAPI DECLSPEC_EXPORT
#else
  #define NDISAPI DECLSPEC_IMPORT
#endif

#if defined(NDIS50_MINIPORT)
#ifndef NDIS50
#define NDIS50
#endif
#endif /* NDIS50_MINIPORT */

#if defined(NDIS51_MINIPORT)
#ifndef NDIS51
#define NDIS51
#endif
#endif /* NDIS51_MINIPORT */

/* NDIS 3.0 is default */
#if !defined(NDIS30) || !defined(NDIS40) || !defined(NDIS50) || !defined(NDIS51)
#define NDIS30
#endif /* !NDIS30 || !NDIS40 || !NDIS50 || !NDIS51 */

#if 1
/* FIXME: */
typedef PVOID QUEUED_CLOSE;
#endif

typedef ULONG NDIS_OID, *PNDIS_OID;

typedef struct _X_FILTER FDDI_FILTER, *PFDDI_FILTER;
typedef struct _X_FILTER TR_FILTER, *PTR_FILTER;
typedef struct _X_FILTER NULL_FILTER, *PNULL_FILTER;

typedef struct _REFERENCE {
	KSPIN_LOCK  SpinLock;
	USHORT  ReferenceCount;
	BOOLEAN  Closing;
} REFERENCE, * PREFERENCE;


/* NDIS base types */

typedef struct _NDIS_SPIN_LOCK {
  KSPIN_LOCK  SpinLock;
  KIRQL  OldIrql;
} NDIS_SPIN_LOCK, * PNDIS_SPIN_LOCK;

typedef struct _NDIS_EVENT {
  KEVENT  Event;
} NDIS_EVENT, *PNDIS_EVENT;

typedef PVOID NDIS_HANDLE, *PNDIS_HANDLE;
typedef int NDIS_STATUS, *PNDIS_STATUS;

typedef ANSI_STRING NDIS_ANSI_STRING, *PNDIS_ANSI_STRING;
typedef UNICODE_STRING NDIS_STRING, *PNDIS_STRING;

typedef MDL NDIS_BUFFER, *PNDIS_BUFFER;
typedef ULONG NDIS_ERROR_CODE, *PNDIS_ERROR_CODE;


/* NDIS_STATUS constants */
#define NDIS_STATUS_SUCCESS                     ((NDIS_STATUS)STATUS_SUCCESS)
#define NDIS_STATUS_PENDING                     ((NDIS_STATUS)STATUS_PENDING)
#define NDIS_STATUS_NOT_RECOGNIZED              ((NDIS_STATUS)0x00010001L)
#define NDIS_STATUS_NOT_COPIED                  ((NDIS_STATUS)0x00010002L)
#define NDIS_STATUS_NOT_ACCEPTED                ((NDIS_STATUS)0x00010003L)
#define NDIS_STATUS_CALL_ACTIVE                 ((NDIS_STATUS)0x00010007L)
#define NDIS_STATUS_ONLINE                      ((NDIS_STATUS)0x40010003L)
#define NDIS_STATUS_RESET_START                 ((NDIS_STATUS)0x40010004L)
#define NDIS_STATUS_RESET_END                   ((NDIS_STATUS)0x40010005L)
#define NDIS_STATUS_RING_STATUS                 ((NDIS_STATUS)0x40010006L)
#define NDIS_STATUS_CLOSED                      ((NDIS_STATUS)0x40010007L)
#define NDIS_STATUS_WAN_LINE_UP                 ((NDIS_STATUS)0x40010008L)
#define NDIS_STATUS_WAN_LINE_DOWN               ((NDIS_STATUS)0x40010009L)
#define NDIS_STATUS_WAN_FRAGMENT                ((NDIS_STATUS)0x4001000AL)
#define	NDIS_STATUS_MEDIA_CONNECT               ((NDIS_STATUS)0x4001000BL)
#define	NDIS_STATUS_MEDIA_DISCONNECT            ((NDIS_STATUS)0x4001000CL)
#define NDIS_STATUS_HARDWARE_LINE_UP            ((NDIS_STATUS)0x4001000DL)
#define NDIS_STATUS_HARDWARE_LINE_DOWN          ((NDIS_STATUS)0x4001000EL)
#define NDIS_STATUS_INTERFACE_UP                ((NDIS_STATUS)0x4001000FL)
#define NDIS_STATUS_INTERFACE_DOWN              ((NDIS_STATUS)0x40010010L)
#define NDIS_STATUS_MEDIA_BUSY                  ((NDIS_STATUS)0x40010011L)
#define NDIS_STATUS_MEDIA_SPECIFIC_INDICATION   ((NDIS_STATUS)0x40010012L)
#define NDIS_STATUS_WW_INDICATION               NDIS_STATUS_MEDIA_SPECIFIC_INDICATION
#define NDIS_STATUS_LINK_SPEED_CHANGE           ((NDIS_STATUS)0x40010013L)
#define NDIS_STATUS_WAN_GET_STATS               ((NDIS_STATUS)0x40010014L)
#define NDIS_STATUS_WAN_CO_FRAGMENT             ((NDIS_STATUS)0x40010015L)
#define NDIS_STATUS_WAN_CO_LINKPARAMS           ((NDIS_STATUS)0x40010016L)

#define NDIS_STATUS_NOT_RESETTABLE              ((NDIS_STATUS)0x80010001L)
#define NDIS_STATUS_SOFT_ERRORS	                ((NDIS_STATUS)0x80010003L)
#define NDIS_STATUS_HARD_ERRORS                 ((NDIS_STATUS)0x80010004L)
#define NDIS_STATUS_BUFFER_OVERFLOW	            ((NDIS_STATUS)STATUS_BUFFER_OVERFLOW)

#define NDIS_STATUS_FAILURE	                    ((NDIS_STATUS)STATUS_UNSUCCESSFUL)
#define NDIS_STATUS_RESOURCES                   ((NDIS_STATUS)STATUS_INSUFFICIENT_RESOURCES)
#define NDIS_STATUS_CLOSING	                    ((NDIS_STATUS)0xC0010002L)
#define NDIS_STATUS_BAD_VERSION	                ((NDIS_STATUS)0xC0010004L)
#define NDIS_STATUS_BAD_CHARACTERISTICS         ((NDIS_STATUS)0xC0010005L)
#define NDIS_STATUS_ADAPTER_NOT_FOUND           ((NDIS_STATUS)0xC0010006L)
#define NDIS_STATUS_OPEN_FAILED	                ((NDIS_STATUS)0xC0010007L)
#define NDIS_STATUS_DEVICE_FAILED               ((NDIS_STATUS)0xC0010008L)
#define NDIS_STATUS_MULTICAST_FULL              ((NDIS_STATUS)0xC0010009L)
#define NDIS_STATUS_MULTICAST_EXISTS            ((NDIS_STATUS)0xC001000AL)
#define NDIS_STATUS_MULTICAST_NOT_FOUND	        ((NDIS_STATUS)0xC001000BL)
#define NDIS_STATUS_REQUEST_ABORTED	            ((NDIS_STATUS)0xC001000CL)
#define NDIS_STATUS_RESET_IN_PROGRESS           ((NDIS_STATUS)0xC001000DL)
#define NDIS_STATUS_CLOSING_INDICATING          ((NDIS_STATUS)0xC001000EL)
#define NDIS_STATUS_NOT_SUPPORTED               ((NDIS_STATUS)STATUS_NOT_SUPPORTED)
#define NDIS_STATUS_INVALID_PACKET              ((NDIS_STATUS)0xC001000FL)
#define NDIS_STATUS_OPEN_LIST_FULL              ((NDIS_STATUS)0xC0010010L)
#define NDIS_STATUS_ADAPTER_NOT_READY           ((NDIS_STATUS)0xC0010011L)
#define NDIS_STATUS_ADAPTER_NOT_OPEN            ((NDIS_STATUS)0xC0010012L)
#define NDIS_STATUS_NOT_INDICATING              ((NDIS_STATUS)0xC0010013L)
#define NDIS_STATUS_INVALID_LENGTH              ((NDIS_STATUS)0xC0010014L)
#define NDIS_STATUS_INVALID_DATA                ((NDIS_STATUS)0xC0010015L)
#define NDIS_STATUS_BUFFER_TOO_SHORT            ((NDIS_STATUS)0xC0010016L)
#define NDIS_STATUS_INVALID_OID	                ((NDIS_STATUS)0xC0010017L)
#define NDIS_STATUS_ADAPTER_REMOVED	            ((NDIS_STATUS)0xC0010018L)
#define NDIS_STATUS_UNSUPPORTED_MEDIA           ((NDIS_STATUS)0xC0010019L)
#define NDIS_STATUS_GROUP_ADDRESS_IN_USE        ((NDIS_STATUS)0xC001001AL)
#define NDIS_STATUS_FILE_NOT_FOUND              ((NDIS_STATUS)0xC001001BL)
#define NDIS_STATUS_ERROR_READING_FILE          ((NDIS_STATUS)0xC001001CL)
#define NDIS_STATUS_ALREADY_MAPPED              ((NDIS_STATUS)0xC001001DL)
#define NDIS_STATUS_RESOURCE_CONFLICT           ((NDIS_STATUS)0xC001001EL)
#define NDIS_STATUS_NO_CABLE                    ((NDIS_STATUS)0xC001001FL)

#define NDIS_STATUS_INVALID_SAP	                ((NDIS_STATUS)0xC0010020L)
#define NDIS_STATUS_SAP_IN_USE                  ((NDIS_STATUS)0xC0010021L)
#define NDIS_STATUS_INVALID_ADDRESS             ((NDIS_STATUS)0xC0010022L)
#define NDIS_STATUS_VC_NOT_ACTIVATED            ((NDIS_STATUS)0xC0010023L)
#define NDIS_STATUS_DEST_OUT_OF_ORDER           ((NDIS_STATUS)0xC0010024L)
#define NDIS_STATUS_VC_NOT_AVAILABLE            ((NDIS_STATUS)0xC0010025L)
#define NDIS_STATUS_CELLRATE_NOT_AVAILABLE      ((NDIS_STATUS)0xC0010026L)
#define NDIS_STATUS_INCOMPATABLE_QOS            ((NDIS_STATUS)0xC0010027L)
#define NDIS_STATUS_AAL_PARAMS_UNSUPPORTED      ((NDIS_STATUS)0xC0010028L)
#define NDIS_STATUS_NO_ROUTE_TO_DESTINATION     ((NDIS_STATUS)0xC0010029L)

#define NDIS_STATUS_TOKEN_RING_OPEN_ERROR       ((NDIS_STATUS)0xC0011000L)
#define NDIS_STATUS_INVALID_DEVICE_REQUEST      ((NDIS_STATUS)STATUS_INVALID_DEVICE_REQUEST)
#define NDIS_STATUS_NETWORK_UNREACHABLE         ((NDIS_STATUS)STATUS_NETWORK_UNREACHABLE)


/* NDIS error codes for error logging */

#define NDIS_ERROR_CODE_RESOURCE_CONFLICT			            EVENT_NDIS_RESOURCE_CONFLICT
#define NDIS_ERROR_CODE_OUT_OF_RESOURCES			            EVENT_NDIS_OUT_OF_RESOURCE
#define NDIS_ERROR_CODE_HARDWARE_FAILURE			            EVENT_NDIS_HARDWARE_FAILURE
#define NDIS_ERROR_CODE_ADAPTER_NOT_FOUND			            EVENT_NDIS_ADAPTER_NOT_FOUND
#define NDIS_ERROR_CODE_INTERRUPT_CONNECT			            EVENT_NDIS_INTERRUPT_CONNECT
#define NDIS_ERROR_CODE_DRIVER_FAILURE				            EVENT_NDIS_DRIVER_FAILURE
#define NDIS_ERROR_CODE_BAD_VERSION					              EVENT_NDIS_BAD_VERSION
#define NDIS_ERROR_CODE_TIMEOUT						                EVENT_NDIS_TIMEOUT
#define NDIS_ERROR_CODE_NETWORK_ADDRESS				            EVENT_NDIS_NETWORK_ADDRESS
#define NDIS_ERROR_CODE_UNSUPPORTED_CONFIGURATION	        EVENT_NDIS_UNSUPPORTED_CONFIGURATION
#define NDIS_ERROR_CODE_INVALID_VALUE_FROM_ADAPTER	      EVENT_NDIS_INVALID_VALUE_FROM_ADAPTER
#define NDIS_ERROR_CODE_MISSING_CONFIGURATION_PARAMETER	  EVENT_NDIS_MISSING_CONFIGURATION_PARAMETER
#define NDIS_ERROR_CODE_BAD_IO_BASE_ADDRESS			          EVENT_NDIS_BAD_IO_BASE_ADDRESS
#define NDIS_ERROR_CODE_RECEIVE_SPACE_SMALL			          EVENT_NDIS_RECEIVE_SPACE_SMALL
#define NDIS_ERROR_CODE_ADAPTER_DISABLED			            EVENT_NDIS_ADAPTER_DISABLED


/* Memory allocation flags. Used by Ndis[Allocate|Free]Memory */
#define NDIS_MEMORY_CONTIGUOUS            0x00000001
#define NDIS_MEMORY_NONCACHED             0x00000002

/* NIC attribute flags. Used by NdisMSetAttributes(Ex) */
#define	NDIS_ATTRIBUTE_IGNORE_PACKET_TIMEOUT    0x00000001
#define NDIS_ATTRIBUTE_IGNORE_REQUEST_TIMEOUT   0x00000002
#define NDIS_ATTRIBUTE_IGNORE_TOKEN_RING_ERRORS 0x00000004
#define NDIS_ATTRIBUTE_BUS_MASTER               0x00000008
#define NDIS_ATTRIBUTE_INTERMEDIATE_DRIVER      0x00000010
#define NDIS_ATTRIBUTE_DESERIALIZE              0x00000020
#define NDIS_ATTRIBUTE_NO_HALT_ON_SUSPEND       0x00000040
#define NDIS_ATTRIBUTE_SURPRISE_REMOVE_OK       0x00000080
#define NDIS_ATTRIBUTE_NOT_CO_NDIS              0x00000100
#define NDIS_ATTRIBUTE_USES_SAFE_BUFFER_APIS    0x00000200


/* Lock */

typedef union _NDIS_RW_LOCK_REFCOUNT {
  UINT  RefCount;
  UCHAR  cacheLine[16];
} NDIS_RW_LOCK_REFCOUNT;

typedef struct _NDIS_RW_LOCK {
  union {
    struct {
      KSPIN_LOCK  SpinLock;
      PVOID  Context;
    } s;
    UCHAR  Reserved[16];
  } u;

  NDIS_RW_LOCK_REFCOUNT  RefCount[MAXIMUM_PROCESSORS];
} NDIS_RW_LOCK, *PNDIS_RW_LOCK;

typedef struct _LOCK_STATE {
  USHORT  LockState;
  KIRQL  OldIrql;
} LOCK_STATE, *PLOCK_STATE;



/* Timer */

typedef VOID DDKAPI
(*PNDIS_TIMER_FUNCTION)(
  /*IN*/ PVOID  SystemSpecific1,
  /*IN*/ PVOID  FunctionContext,
  /*IN*/ PVOID  SystemSpecific2,
  /*IN*/ PVOID  SystemSpecific3);

typedef struct _NDIS_TIMER {
  KTIMER  Timer;
  KDPC  Dpc;
} NDIS_TIMER, *PNDIS_TIMER;



/* Hardware */

typedef CM_MCA_POS_DATA NDIS_MCA_POS_DATA, *PNDIS_MCA_POS_DATA;
typedef CM_EISA_SLOT_INFORMATION NDIS_EISA_SLOT_INFORMATION, *PNDIS_EISA_SLOT_INFORMATION;
typedef CM_EISA_FUNCTION_INFORMATION NDIS_EISA_FUNCTION_INFORMATION, *PNDIS_EISA_FUNCTION_INFORMATION;
typedef CM_PARTIAL_RESOURCE_LIST NDIS_RESOURCE_LIST, *PNDIS_RESOURCE_LIST;

/* Hardware status codes (OID_GEN_HARDWARE_STATUS) */
typedef enum _NDIS_HARDWARE_STATUS {
  NdisHardwareStatusReady,
  NdisHardwareStatusInitializing,
  NdisHardwareStatusReset,
  NdisHardwareStatusClosing,
  NdisHardwareStatusNotReady
} NDIS_HARDWARE_STATUS, *PNDIS_HARDWARE_STATUS;

/* OID_GEN_GET_TIME_CAPS */
typedef struct _GEN_GET_TIME_CAPS {
  ULONG  Flags;
  ULONG  ClockPrecision;
} GEN_GET_TIME_CAPS, *PGEN_GET_TIME_CAPS;

/* Flag bits */
#define	READABLE_LOCAL_CLOCK                    0x00000001
#define	CLOCK_NETWORK_DERIVED                   0x00000002
#define	CLOCK_PRECISION                         0x00000004
#define	RECEIVE_TIME_INDICATION_CAPABLE         0x00000008
#define	TIMED_SEND_CAPABLE                      0x00000010
#define	TIME_STAMP_CAPABLE                      0x00000020

/* OID_GEN_GET_NETCARD_TIME */
typedef struct _GEN_GET_NETCARD_TIME {
  ULONGLONG  ReadTime;
} GEN_GET_NETCARD_TIME, *PGEN_GET_NETCARD_TIME;

/* NDIS driver medium (OID_GEN_MEDIA_SUPPORTED / OID_GEN_MEDIA_IN_USE) */
typedef enum _NDIS_MEDIUM {
  NdisMedium802_3,
  NdisMedium802_5,
  NdisMediumFddi,
  NdisMediumWan,
  NdisMediumLocalTalk,
  NdisMediumDix,
  NdisMediumArcnetRaw,
  NdisMediumArcnet878_2,
  NdisMediumAtm,
  NdisMediumWirelessWan,
  NdisMediumIrda,
  NdisMediumBpc,
  NdisMediumCoWan,
  NdisMedium1394,
  NdisMediumMax
} NDIS_MEDIUM, *PNDIS_MEDIUM;

/* NDIS packet filter bits (OID_GEN_CURRENT_PACKET_FILTER) */
#define NDIS_PACKET_TYPE_DIRECTED               0x00000001
#define NDIS_PACKET_TYPE_MULTICAST              0x00000002
#define NDIS_PACKET_TYPE_ALL_MULTICAST          0x00000004
#define NDIS_PACKET_TYPE_BROADCAST              0x00000008
#define NDIS_PACKET_TYPE_SOURCE_ROUTING         0x00000010
#define NDIS_PACKET_TYPE_PROMISCUOUS            0x00000020
#define NDIS_PACKET_TYPE_SMT                    0x00000040
#define NDIS_PACKET_TYPE_ALL_LOCAL              0x00000080
#define NDIS_PACKET_TYPE_GROUP                  0x00001000
#define NDIS_PACKET_TYPE_ALL_FUNCTIONAL         0x00002000
#define NDIS_PACKET_TYPE_FUNCTIONAL             0x00004000
#define NDIS_PACKET_TYPE_MAC_FRAME              0x00008000

/* NDIS protocol option bits (OID_GEN_PROTOCOL_OPTIONS) */
#define NDIS_PROT_OPTION_ESTIMATED_LENGTH       0x00000001
#define NDIS_PROT_OPTION_NO_LOOPBACK            0x00000002
#define NDIS_PROT_OPTION_NO_RSVD_ON_RCVPKT      0x00000004

/* NDIS MAC option bits (OID_GEN_MAC_OPTIONS) */
#define NDIS_MAC_OPTION_COPY_LOOKAHEAD_DATA     0x00000001
#define NDIS_MAC_OPTION_RECEIVE_SERIALIZED      0x00000002
#define NDIS_MAC_OPTION_TRANSFERS_NOT_PEND      0x00000004
#define NDIS_MAC_OPTION_NO_LOOPBACK             0x00000008
#define NDIS_MAC_OPTION_FULL_DUPLEX             0x00000010
#define	NDIS_MAC_OPTION_EOTX_INDICATION         0x00000020
#define	NDIS_MAC_OPTION_8021P_PRIORITY          0x00000040
#define NDIS_MAC_OPTION_RESERVED                0x80000000

/* State of the LAN media (OID_GEN_MEDIA_CONNECT_STATUS) */
typedef enum _NDIS_MEDIA_STATE {
	NdisMediaStateConnected,
	NdisMediaStateDisconnected
} NDIS_MEDIA_STATE, *PNDIS_MEDIA_STATE;

/* OID_GEN_SUPPORTED_GUIDS */
typedef struct _NDIS_GUID {
	GUID  Guid;
	union {
		NDIS_OID  Oid;
		NDIS_STATUS  Status;
	} u;
	ULONG  Size;
	ULONG  Flags;
} NDIS_GUID, *PNDIS_GUID;

#define	NDIS_GUID_TO_OID                  0x00000001
#define	NDIS_GUID_TO_STATUS               0x00000002
#define	NDIS_GUID_ANSI_STRING             0x00000004
#define	NDIS_GUID_UNICODE_STRING          0x00000008
#define	NDIS_GUID_ARRAY	                  0x00000010


typedef struct _NDIS_PACKET_POOL {
  NDIS_SPIN_LOCK  SpinLock;
  struct _NDIS_PACKET *FreeList;
  UINT  PacketLength;
  UCHAR  Buffer[1];
} NDIS_PACKET_POOL, * PNDIS_PACKET_POOL;

/* NDIS_PACKET_PRIVATE.Flags constants */
#define fPACKET_CONTAINS_MEDIA_SPECIFIC_INFO    0x40
#define fPACKET_ALLOCATED_BY_NDIS               0x80

typedef struct _NDIS_PACKET_PRIVATE {
  UINT  PhysicalCount;
  UINT  TotalLength;
  PNDIS_BUFFER  Head;
  PNDIS_BUFFER  Tail;
  PNDIS_PACKET_POOL  Pool;
  UINT  Count;
  ULONG  Flags;
  BOOLEAN	 ValidCounts;
  UCHAR  NdisPacketFlags;
  USHORT  NdisPacketOobOffset;
} NDIS_PACKET_PRIVATE, * PNDIS_PACKET_PRIVATE;

typedef struct _NDIS_PACKET {
  NDIS_PACKET_PRIVATE  Private;
  union {
    struct {
      UCHAR  MiniportReserved[2 * sizeof(PVOID)];
      UCHAR  WrapperReserved[2 * sizeof(PVOID)];
    } s1;
    struct {
      UCHAR  MiniportReservedEx[3 * sizeof(PVOID)];
      UCHAR  WrapperReservedEx[sizeof(PVOID)];
    } s2;
    struct {
      UCHAR  MacReserved[4 * sizeof(PVOID)];
    } s3;
  } u;
  ULONG_PTR  Reserved[2];
  UCHAR  ProtocolReserved[1];
} NDIS_PACKET, *PNDIS_PACKET, **PPNDIS_PACKET;

typedef enum _NDIS_CLASS_ID {
	NdisClass802_3Priority,
	NdisClassWirelessWanMbxMailbox,
	NdisClassIrdaPacketInfo,
	NdisClassAtmAALInfo
} NDIS_CLASS_ID;

typedef struct MediaSpecificInformation {
  UINT  NextEntryOffset;
  NDIS_CLASS_ID  ClassId;
  UINT  Size;
  UCHAR  ClassInformation[1];
} MEDIA_SPECIFIC_INFORMATION;

typedef struct _NDIS_PACKET_OOB_DATA {
  _ANONYMOUS_UNION union {
    ULONGLONG  TimeToSend;
    ULONGLONG  TimeSent;
  } DUMMYUNIONNAME;
  ULONGLONG  TimeReceived;
  UINT  HeaderSize;
  UINT  SizeMediaSpecificInfo;
  PVOID  MediaSpecificInformation;
  NDIS_STATUS  Status;
} NDIS_PACKET_OOB_DATA, *PNDIS_PACKET_OOB_DATA;

typedef struct _NDIS_PM_PACKET_PATTERN {
  ULONG  Priority;
  ULONG  Reserved;
  ULONG  MaskSize;
  ULONG  PatternOffset;
  ULONG  PatternSize;
  ULONG  PatternFlags;
} NDIS_PM_PACKET_PATTERN,  *PNDIS_PM_PACKET_PATTERN;


/* Request types used by NdisRequest */
typedef enum _NDIS_REQUEST_TYPE {
  NdisRequestQueryInformation,
  NdisRequestSetInformation,
  NdisRequestQueryStatistics,
  NdisRequestOpen,
  NdisRequestClose,
  NdisRequestSend,
  NdisRequestTransferData,
  NdisRequestReset,
  NdisRequestGeneric1,
  NdisRequestGeneric2,
  NdisRequestGeneric3,
  NdisRequestGeneric4
} NDIS_REQUEST_TYPE, *PNDIS_REQUEST_TYPE;

typedef struct _NDIS_REQUEST {
  UCHAR  MacReserved[4 * sizeof(PVOID)];
  NDIS_REQUEST_TYPE  RequestType;
  union _DATA {
    struct QUERY_INFORMATION {
      NDIS_OID  Oid;
      PVOID  InformationBuffer;
      UINT  InformationBufferLength;
      UINT  BytesWritten;
      UINT  BytesNeeded;
    } QUERY_INFORMATION;
    struct SET_INFORMATION {
      NDIS_OID  Oid;
      PVOID  InformationBuffer;
      UINT  InformationBufferLength;
      UINT  BytesRead;
      UINT  BytesNeeded;
    } SET_INFORMATION;
 } DATA;
#if (defined(NDIS50) || defined(NDIS51))
  UCHAR  NdisReserved[9 * sizeof(PVOID)];
  union {
    UCHAR  CallMgrReserved[2 * sizeof(PVOID)];
    UCHAR  ProtocolReserved[2 * sizeof(PVOID)];
  };
  UCHAR  MiniportReserved[2 * sizeof(PVOID)];
#endif
} NDIS_REQUEST, *PNDIS_REQUEST;



/* Wide Area Networks definitions */

typedef struct _NDIS_WAN_PACKET {
  LIST_ENTRY  WanPacketQueue;
  PUCHAR  CurrentBuffer;
  ULONG  CurrentLength;
  PUCHAR  StartBuffer;
  PUCHAR  EndBuffer;
  PVOID  ProtocolReserved1;
  PVOID  ProtocolReserved2;
  PVOID  ProtocolReserved3;
  PVOID  ProtocolReserved4;
  PVOID  MacReserved1;
  PVOID  MacReserved2;
  PVOID  MacReserved3;
  PVOID  MacReserved4;
} NDIS_WAN_PACKET, *PNDIS_WAN_PACKET;



/* DMA channel information */

typedef struct _NDIS_DMA_DESCRIPTION {
  BOOLEAN  DemandMode;
  BOOLEAN  AutoInitialize;
  BOOLEAN  DmaChannelSpecified;
  DMA_WIDTH  DmaWidth;
  DMA_SPEED  DmaSpeed;
  ULONG  DmaPort;
  ULONG  DmaChannel;
} NDIS_DMA_DESCRIPTION, *PNDIS_DMA_DESCRIPTION;

typedef struct _NDIS_DMA_BLOCK {
  PVOID  MapRegisterBase;
  KEVENT  AllocationEvent;
  PADAPTER_OBJECT  SystemAdapterObject;
  PVOID  Miniport;
  BOOLEAN  InProgress;
} NDIS_DMA_BLOCK, *PNDIS_DMA_BLOCK;


/* Possible hardware architecture */
typedef enum _NDIS_INTERFACE_TYPE {
	NdisInterfaceInternal = Internal,
	NdisInterfaceIsa = Isa,
	NdisInterfaceEisa = Eisa,
	NdisInterfaceMca = MicroChannel,
	NdisInterfaceTurboChannel = TurboChannel,
	NdisInterfacePci = PCIBus,
	NdisInterfacePcMcia = PCMCIABus,
	NdisInterfaceCBus = CBus,
	NdisInterfaceMPIBus = MPIBus,
	NdisInterfaceMPSABus = MPSABus,
	NdisInterfaceProcessorInternal = ProcessorInternal,
	NdisInterfaceInternalPowerBus = InternalPowerBus,
	NdisInterfacePNPISABus = PNPISABus,
	NdisInterfacePNPBus = PNPBus,
	NdisMaximumInterfaceType
} NDIS_INTERFACE_TYPE, *PNDIS_INTERFACE_TYPE;

#define NdisInterruptLevelSensitive       LevelSensitive
#define NdisInterruptLatched              Latched
typedef KINTERRUPT_MODE NDIS_INTERRUPT_MODE, *PNDIS_INTERRUPT_MODE;


typedef enum _NDIS_PARAMETER_TYPE {
  NdisParameterInteger,
  NdisParameterHexInteger,
  NdisParameterString,
  NdisParameterMultiString,
  NdisParameterBinary
} NDIS_PARAMETER_TYPE, *PNDIS_PARAMETER_TYPE;

typedef struct {
	USHORT  Length;
	PVOID  Buffer;
} BINARY_DATA;

typedef struct _NDIS_CONFIGURATION_PARAMETER {
  NDIS_PARAMETER_TYPE  ParameterType;
  union {
    ULONG  IntegerData;
    NDIS_STRING  StringData;
    BINARY_DATA  BinaryData;
  } ParameterData;
} NDIS_CONFIGURATION_PARAMETER, *PNDIS_CONFIGURATION_PARAMETER;


typedef PHYSICAL_ADDRESS NDIS_PHYSICAL_ADDRESS, *PNDIS_PHYSICAL_ADDRESS;

typedef struct _NDIS_PHYSICAL_ADDRESS_UNIT {
  NDIS_PHYSICAL_ADDRESS  PhysicalAddress;
  UINT  Length;
} NDIS_PHYSICAL_ADDRESS_UNIT, *PNDIS_PHYSICAL_ADDRESS_UNIT;

typedef struct _NDIS_WAN_LINE_DOWN {
  UCHAR  RemoteAddress[6];
  UCHAR  LocalAddress[6];
} NDIS_WAN_LINE_DOWN, *PNDIS_WAN_LINE_DOWN;

typedef struct _NDIS_WAN_LINE_UP {
  ULONG  LinkSpeed;
  ULONG  MaximumTotalSize;
  NDIS_WAN_QUALITY  Quality;
  USHORT  SendWindow;
  UCHAR  RemoteAddress[6];
  /*OUT*/ UCHAR  LocalAddress[6];
  ULONG  ProtocolBufferLength;
  PUCHAR  ProtocolBuffer;
  USHORT  ProtocolType;
  NDIS_STRING  DeviceName;
} NDIS_WAN_LINE_UP, *PNDIS_WAN_LINE_UP;


typedef VOID DDKAPI
(*ADAPTER_SHUTDOWN_HANDLER)(
  /*IN*/ PVOID  ShutdownContext);


typedef struct _OID_LIST    OID_LIST, *POID_LIST;

/* PnP state */

typedef enum _NDIS_PNP_DEVICE_STATE {
  NdisPnPDeviceAdded,
  NdisPnPDeviceStarted,
  NdisPnPDeviceQueryStopped,
  NdisPnPDeviceStopped,
  NdisPnPDeviceQueryRemoved,
  NdisPnPDeviceRemoved,
  NdisPnPDeviceSurpriseRemoved
} NDIS_PNP_DEVICE_STATE;

#define	NDIS_DEVICE_NOT_STOPPABLE                 0x00000001
#define	NDIS_DEVICE_NOT_REMOVEABLE                0x00000002
#define	NDIS_DEVICE_NOT_SUSPENDABLE	              0x00000004
#define NDIS_DEVICE_DISABLE_PM                    0x00000008
#define NDIS_DEVICE_DISABLE_WAKE_UP               0x00000010
#define NDIS_DEVICE_DISABLE_WAKE_ON_RECONNECT     0x00000020
#define NDIS_DEVICE_RESERVED                      0x00000040
#define NDIS_DEVICE_DISABLE_WAKE_ON_MAGIC_PACKET  0x00000080
#define NDIS_DEVICE_DISABLE_WAKE_ON_PATTERN_MATCH 0x00000100


/* OID_GEN_NETWORK_LAYER_ADDRESSES */
typedef struct _NETWORK_ADDRESS {
  USHORT  AddressLength; 
  USHORT  AddressType; 
  UCHAR  Address[1]; 
} NETWORK_ADDRESS, *PNETWORK_ADDRESS;

typedef struct _NETWORK_ADDRESS_LIST {
	LONG  AddressCount; 
	USHORT  AddressType; 
	NETWORK_ADDRESS  Address[1]; 
} NETWORK_ADDRESS_LIST, *PNETWORK_ADDRESS_LIST;

/* Protocol types supported by NDIS */
#define	NDIS_PROTOCOL_ID_DEFAULT        0x00
#define	NDIS_PROTOCOL_ID_TCP_IP         0x02
#define	NDIS_PROTOCOL_ID_IPX            0x06
#define	NDIS_PROTOCOL_ID_NBF            0x07
#define	NDIS_PROTOCOL_ID_MAX            0x0F
#define	NDIS_PROTOCOL_ID_MASK           0x0F


/* OID_GEN_TRANSPORT_HEADER_OFFSET */
typedef struct _TRANSPORT_HEADER_OFFSET {
	USHORT  ProtocolType; 
	USHORT  HeaderOffset; 
} TRANSPORT_HEADER_OFFSET, *PTRANSPORT_HEADER_OFFSET;


/* OID_GEN_CO_LINK_SPEED / OID_GEN_CO_MINIMUM_LINK_SPEED */
typedef struct _NDIS_CO_LINK_SPEED {
  ULONG  Outbound;
  ULONG  Inbound;
} NDIS_CO_LINK_SPEED, *PNDIS_CO_LINK_SPEED;

typedef ULONG NDIS_AF, *PNDIS_AF;
#define CO_ADDRESS_FAMILY_Q2931           ((NDIS_AF)0x1)
#define CO_ADDRESS_FAMILY_PSCHED          ((NDIS_AF)0x2)
#define CO_ADDRESS_FAMILY_L2TP            ((NDIS_AF)0x3)
#define CO_ADDRESS_FAMILY_IRDA            ((NDIS_AF)0x4)
#define CO_ADDRESS_FAMILY_1394            ((NDIS_AF)0x5)
#define CO_ADDRESS_FAMILY_PPP             ((NDIS_AF)0x6)
#define CO_ADDRESS_FAMILY_TAPI            ((NDIS_AF)0x800)
#define CO_ADDRESS_FAMILY_TAPI_PROXY      ((NDIS_AF)0x801)

#define CO_ADDRESS_FAMILY_PROXY           0x80000000

typedef struct {
  NDIS_AF  AddressFamily;
  ULONG  MajorVersion;
  ULONG  MinorVersion;
} CO_ADDRESS_FAMILY, *PCO_ADDRESS_FAMILY;

typedef struct _CO_FLOW_PARAMETERS {
  ULONG  TokenRate;
  ULONG  TokenBucketSize;
  ULONG  PeakBandwidth;
  ULONG  Latency;
  ULONG  DelayVariation;
  SERVICETYPE  ServiceType;
  ULONG  MaxSduSize;
  ULONG  MinimumPolicedSize;
} CO_FLOW_PARAMETERS, *PCO_FLOW_PARAMETERS;

typedef struct _CO_SPECIFIC_PARAMETERS {
  ULONG  ParamType;
  ULONG  Length;
  UCHAR  Parameters[1];
} CO_SPECIFIC_PARAMETERS, *PCO_SPECIFIC_PARAMETERS;

typedef struct _CO_CALL_MANAGER_PARAMETERS {
  CO_FLOW_PARAMETERS  Transmit;
  CO_FLOW_PARAMETERS  Receive;
  CO_SPECIFIC_PARAMETERS  CallMgrSpecific;
} CO_CALL_MANAGER_PARAMETERS, *PCO_CALL_MANAGER_PARAMETERS;

/* CO_MEDIA_PARAMETERS.Flags constants */
#define RECEIVE_TIME_INDICATION           0x00000001
#define USE_TIME_STAMPS                   0x00000002
#define TRANSMIT_VC	                      0x00000004
#define RECEIVE_VC                        0x00000008
#define INDICATE_ERRED_PACKETS            0x00000010
#define INDICATE_END_OF_TX                0x00000020
#define RESERVE_RESOURCES_VC              0x00000040
#define	ROUND_DOWN_FLOW	                  0x00000080
#define	ROUND_UP_FLOW                     0x00000100

typedef struct _CO_MEDIA_PARAMETERS {
  ULONG  Flags;
  ULONG  ReceivePriority;
  ULONG  ReceiveSizeHint;
  CO_SPECIFIC_PARAMETERS  MediaSpecific;
} CO_MEDIA_PARAMETERS, *PCO_MEDIA_PARAMETERS;

/* CO_CALL_PARAMETERS.Flags constants */
#define PERMANENT_VC                      0x00000001
#define CALL_PARAMETERS_CHANGED           0x00000002
#define QUERY_CALL_PARAMETERS             0x00000004
#define BROADCAST_VC                      0x00000008
#define MULTIPOINT_VC                     0x00000010

typedef struct _CO_CALL_PARAMETERS {
  ULONG  Flags;
  PCO_CALL_MANAGER_PARAMETERS  CallMgrParameters;
  PCO_MEDIA_PARAMETERS  MediaParameters;
} CO_CALL_PARAMETERS, *PCO_CALL_PARAMETERS;

typedef struct _CO_SAP {
  ULONG  SapType;
  ULONG  SapLength;
  UCHAR  Sap[1];
} CO_SAP, *PCO_SAP;

typedef struct _NDIS_IPSEC_PACKET_INFO {
  _ANONYMOUS_UNION union {
    struct {
      NDIS_HANDLE  OffloadHandle;
      NDIS_HANDLE  NextOffloadHandle;
    } Transmit;
    struct {
      ULONG  SA_DELETE_REQ : 1;
      ULONG  CRYPTO_DONE : 1;
      ULONG  NEXT_CRYPTO_DONE : 1;
      ULONG  CryptoStatus;
    } Receive;
  } DUMMYUNIONNAME;
} NDIS_IPSEC_PACKET_INFO, *PNDIS_IPSEC_PACKET_INFO;

/* NDIS_MAC_FRAGMENT.Errors constants */
#define WAN_ERROR_CRC               			0x00000001
#define WAN_ERROR_FRAMING           			0x00000002
#define WAN_ERROR_HARDWAREOVERRUN   			0x00000004
#define WAN_ERROR_BUFFEROVERRUN     			0x00000008
#define WAN_ERROR_TIMEOUT           			0x00000010
#define WAN_ERROR_ALIGNMENT         			0x00000020

typedef struct _NDIS_MAC_FRAGMENT {
  NDIS_HANDLE  NdisLinkContext;
  ULONG  Errors;
} NDIS_MAC_FRAGMENT, *PNDIS_MAC_FRAGMENT;

typedef struct _NDIS_MAC_LINE_DOWN {
  NDIS_HANDLE  NdisLinkContext;
} NDIS_MAC_LINE_DOWN, *PNDIS_MAC_LINE_DOWN;

typedef struct _NDIS_MAC_LINE_UP {
  ULONG  LinkSpeed;
  NDIS_WAN_QUALITY  Quality;
  USHORT  SendWindow;
  NDIS_HANDLE  ConnectionWrapperID;
  NDIS_HANDLE  NdisLinkHandle;
  NDIS_HANDLE  NdisLinkContext;
} NDIS_MAC_LINE_UP, *PNDIS_MAC_LINE_UP;

typedef struct _NDIS_PACKET_8021Q_INFO {
	_ANONYMOUS_UNION union {
		struct {
			UINT32  UserPriority : 3;
			UINT32  CanonicalFormatId : 1;
			UINT32  VlanId : 12;
			UINT32  Reserved : 16;
		} TagHeader;
		PVOID  Value;
	} DUMMYUNIONNAME;
} NDIS_PACKET_8021Q_INFO, *PNDIS_PACKET_8021Q_INFO;

typedef enum _NDIS_PER_PACKET_INFO {
	TcpIpChecksumPacketInfo,
	IpSecPacketInfo,
	TcpLargeSendPacketInfo,
	ClassificationHandlePacketInfo,
	NdisReserved,
	ScatterGatherListPacketInfo,
	Ieee8021QInfo,
	OriginalPacketInfo,
	PacketCancelId,
	MaxPerPacketInfo
} NDIS_PER_PACKET_INFO, *PNDIS_PER_PACKET_INFO;

typedef struct _NDIS_PACKET_EXTENSION {
  PVOID  NdisPacketInfo[MaxPerPacketInfo];
} NDIS_PACKET_EXTENSION, *PNDIS_PACKET_EXTENSION;

/*
 * PNDIS_PACKET
 * NDIS_GET_ORIGINAL_PACKET(
 * IN PNDIS_PACKET  Packet);
 */
#define NDIS_GET_ORIGINAL_PACKET(Packet) \
  NDIS_PER_PACKET_INFO_FROM_PACKET(Packet, OriginalPacketInfo)

/*
 * PVOID
 * NDIS_GET_PACKET_CANCEL_ID(
 * IN PNDIS_PACKET  Packet);
 */
#define NDIS_GET_PACKET_CANCEL_ID(Packet) \
  NDIS_PER_PACKET_INFO_FROM_PACKET(Packet, PacketCancelId)

/*
 * PNDIS_PACKET_EXTENSION
 * NDIS_PACKET_EXTENSION_FROM_PACKET(
 * IN PNDIS_PACKET  Packet);
 */
#define NDIS_PACKET_EXTENSION_FROM_PACKET(Packet) \
  ((PNDIS_PACKET_EXTENSION)((PUCHAR)(Packet) \
    + (Packet)->Private.NdisPacketOobOffset + sizeof(NDIS_PACKET_OOB_DATA)))

/*
 * PVOID
 * NDIS_PER_PACKET_INFO_FROM_PACKET(
 * IN OUT  PNDIS_PACKET  Packet,
 * IN NDIS_PER_PACKET_INFO  InfoType);
 */
#define NDIS_PER_PACKET_INFO_FROM_PACKET(Packet, InfoType) \
  ((PNDIS_PACKET_EXTENSION)((PUCHAR)(Packet) + (Packet)->Private.NdisPacketOobOffset \
    + sizeof(NDIS_PACKET_OOB_DATA)))->NdisPacketInfo[(InfoType)]

/*
 * VOID
 * NDIS_SET_ORIGINAL_PACKET(
 * IN OUT  PNDIS_PACKET  Packet,
 * IN PNDIS_PACKET  OriginalPacket);
 */
#define NDIS_SET_ORIGINAL_PACKET(Packet, OriginalPacket) \
  NDIS_PER_PACKET_INFO_FROM_PACKET(Packet, OriginalPacketInfo) = (OriginalPacket)

/*
 * VOID
 * NDIS_SET_PACKET_CANCEL_ID(
 * IN PNDIS_PACKET  Packet
 * IN ULONG_PTR  CancelId);
 */
#define NDIS_SET_PACKET_CANCEL_ID(Packet, CancelId) \
  NDIS_PER_PACKET_INFO_FROM_PACKET(Packet, PacketCancelId) = (CancelId)

typedef enum _NDIS_TASK {
  TcpIpChecksumNdisTask,
  IpSecNdisTask,
  TcpLargeSendNdisTask,
  MaxNdisTask
} NDIS_TASK, *PNDIS_TASK;

typedef struct _NDIS_TASK_IPSEC {
  struct {
    ULONG  AH_ESP_COMBINED;
    ULONG  TRANSPORT_TUNNEL_COMBINED;
    ULONG  V4_OPTIONS;
    ULONG  RESERVED;
  } Supported;
 
  struct {
    ULONG  MD5 : 1;
    ULONG  SHA_1 : 1;
    ULONG  Transport : 1;
    ULONG  Tunnel : 1;
    ULONG  Send : 1;
    ULONG  Receive : 1;
  } V4AH;
 
  struct {
    ULONG  DES : 1;
    ULONG  RESERVED : 1;
    ULONG  TRIPLE_DES : 1;
    ULONG  NULL_ESP : 1;
    ULONG  Transport : 1;
    ULONG  Tunnel : 1;
    ULONG  Send : 1;
    ULONG  Receive : 1;
  } V4ESP;
} NDIS_TASK_IPSEC, *PNDIS_TASK_IPSEC;

typedef struct _NDIS_TASK_OFFLOAD {
  ULONG  Version;
  ULONG  Size;
  NDIS_TASK  Task;
  ULONG  OffsetNextTask;
  ULONG  TaskBufferLength;
  UCHAR  TaskBuffer[1];
} NDIS_TASK_OFFLOAD, *PNDIS_TASK_OFFLOAD;

/* NDIS_TASK_OFFLOAD_HEADER.Version constants */
#define NDIS_TASK_OFFLOAD_VERSION 1

typedef enum _NDIS_ENCAPSULATION {
  UNSPECIFIED_Encapsulation,
  NULL_Encapsulation,
  IEEE_802_3_Encapsulation,
  IEEE_802_5_Encapsulation,
  LLC_SNAP_ROUTED_Encapsulation,
  LLC_SNAP_BRIDGED_Encapsulation
} NDIS_ENCAPSULATION;

typedef struct _NDIS_ENCAPSULATION_FORMAT {
  NDIS_ENCAPSULATION  Encapsulation;
  struct {
    ULONG  FixedHeaderSize : 1;
    ULONG  Reserved : 31;
  } Flags;
  ULONG  EncapsulationHeaderSize;
} NDIS_ENCAPSULATION_FORMAT, *PNDIS_ENCAPSULATION_FORMAT;

typedef struct _NDIS_TASK_TCP_IP_CHECKSUM {
  struct {
    ULONG  IpOptionsSupported:1;
    ULONG  TcpOptionsSupported:1;
    ULONG  TcpChecksum:1;
    ULONG  UdpChecksum:1;
    ULONG  IpChecksum:1;
  } V4Transmit;
 
  struct {
    ULONG  IpOptionsSupported : 1;
    ULONG  TcpOptionsSupported : 1;
    ULONG  TcpChecksum : 1;
    ULONG  UdpChecksum : 1;
    ULONG  IpChecksum : 1;
  } V4Receive;
 
  struct {
    ULONG  IpOptionsSupported : 1;
    ULONG  TcpOptionsSupported : 1;
    ULONG  TcpChecksum : 1;
    ULONG  UdpChecksum : 1;
  } V6Transmit;
 
  struct {
    ULONG  IpOptionsSupported : 1;
    ULONG  TcpOptionsSupported : 1;
    ULONG  TcpChecksum : 1;
    ULONG  UdpChecksum : 1;
  } V6Receive;
} NDIS_TASK_TCP_IP_CHECKSUM, *PNDIS_TASK_TCP_IP_CHECKSUM;

typedef struct _NDIS_TASK_TCP_LARGE_SEND {
  ULONG  Version;
  ULONG  MaxOffLoadSize;
  ULONG  MinSegmentCount;
  BOOLEAN  TcpOptions;
  BOOLEAN  IpOptions;
} NDIS_TASK_TCP_LARGE_SEND, *PNDIS_TASK_TCP_LARGE_SEND;

typedef struct _NDIS_TCP_IP_CHECKSUM_PACKET_INFO {
  _ANONYMOUS_UNION union {
    struct {
      ULONG  NdisPacketChecksumV4 : 1;
      ULONG  NdisPacketChecksumV6 : 1;
      ULONG  NdisPacketTcpChecksum : 1;
      ULONG  NdisPacketUdpChecksum : 1;
      ULONG  NdisPacketIpChecksum : 1;
      } Transmit;
 
    struct {
      ULONG  NdisPacketTcpChecksumFailed : 1;
      ULONG  NdisPacketUdpChecksumFailed : 1;
      ULONG  NdisPacketIpChecksumFailed : 1;
      ULONG  NdisPacketTcpChecksumSucceeded : 1;
      ULONG  NdisPacketUdpChecksumSucceeded : 1;
      ULONG  NdisPacketIpChecksumSucceeded : 1;
      ULONG  NdisPacketLoopback : 1;
    } Receive;
    ULONG  Value;
  } DUMMYUNIONNAME;
} NDIS_TCP_IP_CHECKSUM_PACKET_INFO, *PNDIS_TCP_IP_CHECKSUM_PACKET_INFO;

typedef struct _NDIS_WAN_CO_FRAGMENT {
  ULONG  Errors;
} NDIS_WAN_CO_FRAGMENT, *PNDIS_WAN_CO_FRAGMENT;

typedef struct _NDIS_WAN_FRAGMENT {
  UCHAR  RemoteAddress[6];
  UCHAR  LocalAddress[6];
} NDIS_WAN_FRAGMENT, *PNDIS_WAN_FRAGMENT;

typedef struct _WAN_CO_LINKPARAMS {
  ULONG  TransmitSpeed; 
  ULONG  ReceiveSpeed; 
  ULONG  SendWindow; 
} WAN_CO_LINKPARAMS, *PWAN_CO_LINKPARAMS;


/* Call Manager */

typedef VOID DDKAPI
(*CM_ACTIVATE_VC_COMPLETE_HANDLER)(
  /*IN*/ NDIS_STATUS  Status,
  /*IN*/ NDIS_HANDLE  CallMgrVcContext,
  /*IN*/ PCO_CALL_PARAMETERS  CallParameters);

typedef NDIS_STATUS DDKAPI
(*CM_ADD_PARTY_HANDLER)(
  /*IN*/ NDIS_HANDLE  CallMgrVcContext,
  /*IN OUT*/ PCO_CALL_PARAMETERS  CallParameters,
  /*IN*/ NDIS_HANDLE  NdisPartyHandle,
  /*OUT*/ PNDIS_HANDLE  CallMgrPartyContext);

typedef NDIS_STATUS DDKAPI
(*CM_CLOSE_AF_HANDLER)(
  /*IN*/ NDIS_HANDLE  CallMgrAfContext);

typedef NDIS_STATUS DDKAPI
(*CM_CLOSE_CALL_HANDLER)(
  /*IN*/ NDIS_HANDLE  CallMgrVcContext,
  /*IN*/ NDIS_HANDLE  CallMgrPartyContext  /*OPTIONAL*/,
  /*IN*/ PVOID  CloseData  /*OPTIONAL*/,
  /*IN*/ UINT  Size  /*OPTIONAL*/);

typedef NDIS_STATUS DDKAPI
(*CM_DEREG_SAP_HANDLER)(
  /*IN*/ NDIS_HANDLE  CallMgrSapContext);

typedef VOID DDKAPI
(*CM_DEACTIVATE_VC_COMPLETE_HANDLER)(
  /*IN*/ NDIS_STATUS  Status,
  /*IN*/ NDIS_HANDLE  CallMgrVcContext);

typedef NDIS_STATUS DDKAPI
(*CM_DROP_PARTY_HANDLER)(
  /*IN*/ NDIS_HANDLE  CallMgrPartyContext,
  /*IN*/ PVOID  CloseData  /*OPTIONAL*/,
  /*IN*/ UINT  Size  /*OPTIONAL*/);

typedef VOID DDKAPI
(*CM_INCOMING_CALL_COMPLETE_HANDLER)(
  /*IN*/ NDIS_STATUS  Status,
  /*IN*/ NDIS_HANDLE  CallMgrVcContext,
  /*IN*/ PCO_CALL_PARAMETERS  CallParameters);

typedef NDIS_STATUS DDKAPI
(*CM_MAKE_CALL_HANDLER)(
  /*IN*/ NDIS_HANDLE  CallMgrVcContext,
  /*IN OUT*/ PCO_CALL_PARAMETERS  CallParameters,
  /*IN*/ NDIS_HANDLE  NdisPartyHandle	/*OPTIONAL*/,
  /*OUT*/ PNDIS_HANDLE  CallMgrPartyContext  /*OPTIONAL*/);

typedef NDIS_STATUS DDKAPI
(*CM_MODIFY_CALL_QOS_HANDLER)(
  /*IN*/ NDIS_HANDLE  CallMgrVcContext,
  /*IN*/ PCO_CALL_PARAMETERS  CallParameters);

typedef NDIS_STATUS DDKAPI
(*CM_OPEN_AF_HANDLER)(
  /*IN*/ NDIS_HANDLE  CallMgrBindingContext,
  /*IN*/ PCO_ADDRESS_FAMILY  AddressFamily,
  /*IN*/ NDIS_HANDLE  NdisAfHandle,
  /*OUT*/ PNDIS_HANDLE  CallMgrAfContext);

typedef NDIS_STATUS DDKAPI
(*CM_REG_SAP_HANDLER)(
  /*IN*/ NDIS_HANDLE  CallMgrAfContext,
  /*IN*/ PCO_SAP  Sap,
  /*IN*/ NDIS_HANDLE  NdisSapHandle,
  /*OUT*/ PNDIS_HANDLE  CallMgrSapContext);

typedef NDIS_STATUS DDKAPI
(*CO_CREATE_VC_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolAfContext,
  /*IN*/ NDIS_HANDLE  NdisVcHandle,
  /*OUT*/ PNDIS_HANDLE  ProtocolVcContext);

typedef NDIS_STATUS DDKAPI
(*CO_DELETE_VC_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolVcContext);

typedef VOID DDKAPI
(*CO_REQUEST_COMPLETE_HANDLER)(
  /*IN*/ NDIS_STATUS  Status,
  /*IN*/ NDIS_HANDLE  ProtocolAfContext  /*OPTIONAL*/,
  /*IN*/ NDIS_HANDLE  ProtocolVcContext  /*OPTIONAL*/,
  /*IN*/ NDIS_HANDLE  ProtocolPartyContext  /*OPTIONAL*/,
  /*IN*/ PNDIS_REQUEST  NdisRequest);

typedef NDIS_STATUS DDKAPI
(*CO_REQUEST_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolAfContext,
  /*IN*/ NDIS_HANDLE  ProtocolVcContext  /*OPTIONAL*/,
  /*IN*/ NDIS_HANDLE	ProtocolPartyContext  /*OPTIONAL*/,
  /*IN OUT*/ PNDIS_REQUEST  NdisRequest);

typedef struct _NDIS_CALL_MANAGER_CHARACTERISTICS {
	UCHAR  MajorVersion;
	UCHAR  MinorVersion;
	USHORT  Filler;
	UINT  Reserved;
	CO_CREATE_VC_HANDLER  CmCreateVcHandler;
	CO_DELETE_VC_HANDLER  CmDeleteVcHandler;
	CM_OPEN_AF_HANDLER  CmOpenAfHandler;
	CM_CLOSE_AF_HANDLER	 CmCloseAfHandler;
	CM_REG_SAP_HANDLER  CmRegisterSapHandler;
	CM_DEREG_SAP_HANDLER  CmDeregisterSapHandler;
	CM_MAKE_CALL_HANDLER  CmMakeCallHandler;
	CM_CLOSE_CALL_HANDLER  CmCloseCallHandler;
	CM_INCOMING_CALL_COMPLETE_HANDLER  CmIncomingCallCompleteHandler;
	CM_ADD_PARTY_HANDLER  CmAddPartyHandler;
	CM_DROP_PARTY_HANDLER  CmDropPartyHandler;
	CM_ACTIVATE_VC_COMPLETE_HANDLER  CmActivateVcCompleteHandler;
	CM_DEACTIVATE_VC_COMPLETE_HANDLER  CmDeactivateVcCompleteHandler;
	CM_MODIFY_CALL_QOS_HANDLER  CmModifyCallQoSHandler;
	CO_REQUEST_HANDLER  CmRequestHandler;
	CO_REQUEST_COMPLETE_HANDLER  CmRequestCompleteHandler;
} NDIS_CALL_MANAGER_CHARACTERISTICS, *PNDIS_CALL_MANAGER_CHARACTERISTICS;



/* Call Manager clients */

typedef VOID (*CL_OPEN_AF_COMPLETE_HANDLER)(
  /*IN*/ NDIS_STATUS Status,
  /*IN*/ NDIS_HANDLE ProtocolAfContext,
  /*IN*/ NDIS_HANDLE NdisAfHandle);

typedef VOID DDKAPI
(*CL_CLOSE_AF_COMPLETE_HANDLER)(
  /*IN*/ NDIS_STATUS  Status,
  /*IN*/ NDIS_HANDLE  ProtocolAfContext);

typedef VOID DDKAPI
(*CL_REG_SAP_COMPLETE_HANDLER)(
  /*IN*/ NDIS_STATUS  Status,
  /*IN*/ NDIS_HANDLE  ProtocolSapContext,
  /*IN*/ PCO_SAP  Sap,
  /*IN*/ NDIS_HANDLE  NdisSapHandle);

typedef VOID DDKAPI
(*CL_DEREG_SAP_COMPLETE_HANDLER)(
  /*IN*/ NDIS_STATUS  Status,
  /*IN*/ NDIS_HANDLE  ProtocolSapContext);

typedef VOID DDKAPI
(*CL_MAKE_CALL_COMPLETE_HANDLER)(
  /*IN*/ NDIS_STATUS  Status,
  /*IN*/ NDIS_HANDLE  ProtocolVcContext,
  /*IN*/ NDIS_HANDLE  NdisPartyHandle  /*OPTIONAL*/,
  /*IN*/ PCO_CALL_PARAMETERS  CallParameters);

typedef VOID DDKAPI
(*CL_MODIFY_CALL_QOS_COMPLETE_HANDLER)(
  /*IN*/ NDIS_STATUS  Status,
  /*IN*/ NDIS_HANDLE  ProtocolVcContext,
  /*IN*/ PCO_CALL_PARAMETERS  CallParameters);

typedef VOID DDKAPI
(*CL_CLOSE_CALL_COMPLETE_HANDLER)(
  /*IN*/ NDIS_STATUS  Status,
  /*IN*/ NDIS_HANDLE  ProtocolVcContext,
  /*IN*/ NDIS_HANDLE  ProtocolPartyContext  /*OPTIONAL*/);

typedef VOID DDKAPI
(*CL_ADD_PARTY_COMPLETE_HANDLER)(
  /*IN*/ NDIS_STATUS  Status,
  /*IN*/ NDIS_HANDLE  ProtocolPartyContext,
  /*IN*/ NDIS_HANDLE  NdisPartyHandle,
  /*IN*/ PCO_CALL_PARAMETERS  CallParameters);

typedef VOID DDKAPI
(*CL_DROP_PARTY_COMPLETE_HANDLER)(
  /*IN*/ NDIS_STATUS  Status,
  /*IN*/ NDIS_HANDLE  ProtocolPartyContext);

typedef NDIS_STATUS DDKAPI
(*CL_INCOMING_CALL_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolSapContext,
  /*IN*/ NDIS_HANDLE  ProtocolVcContext,
  /*IN OUT*/ PCO_CALL_PARAMETERS  CallParameters);

typedef VOID DDKAPI
(*CL_INCOMING_CALL_QOS_CHANGE_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolVcContext,
  /*IN*/ PCO_CALL_PARAMETERS  CallParameters);

typedef VOID DDKAPI
(*CL_INCOMING_CLOSE_CALL_HANDLER)(
  /*IN*/ NDIS_STATUS  CloseStatus,
  /*IN*/ NDIS_HANDLE  ProtocolVcContext,
  /*IN*/ PVOID  CloseData  /*OPTIONAL*/,
  /*IN*/ UINT  Size  /*OPTIONAL*/);

typedef VOID DDKAPI
(*CL_INCOMING_DROP_PARTY_HANDLER)(
  /*IN*/ NDIS_STATUS  DropStatus,
  /*IN*/ NDIS_HANDLE  ProtocolPartyContext,
  /*IN*/ PVOID  CloseData  /*OPTIONAL*/,
  /*IN*/ UINT  Size  /*OPTIONAL*/);

typedef VOID DDKAPI
(*CL_CALL_CONNECTED_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolVcContext);


typedef struct _NDIS_CLIENT_CHARACTERISTICS {
  UCHAR  MajorVersion;
  UCHAR  MinorVersion;
  USHORT  Filler;
  UINT  Reserved;
  CO_CREATE_VC_HANDLER  ClCreateVcHandler;
  CO_DELETE_VC_HANDLER  ClDeleteVcHandler;
  CO_REQUEST_HANDLER  ClRequestHandler;
  CO_REQUEST_COMPLETE_HANDLER  ClRequestCompleteHandler;
  CL_OPEN_AF_COMPLETE_HANDLER  ClOpenAfCompleteHandler;
  CL_CLOSE_AF_COMPLETE_HANDLER  ClCloseAfCompleteHandler;
  CL_REG_SAP_COMPLETE_HANDLER  ClRegisterSapCompleteHandler;
  CL_DEREG_SAP_COMPLETE_HANDLER  ClDeregisterSapCompleteHandler;
  CL_MAKE_CALL_COMPLETE_HANDLER  ClMakeCallCompleteHandler;
  CL_MODIFY_CALL_QOS_COMPLETE_HANDLER	 ClModifyCallQoSCompleteHandler;
  CL_CLOSE_CALL_COMPLETE_HANDLER  ClCloseCallCompleteHandler;
  CL_ADD_PARTY_COMPLETE_HANDLER  ClAddPartyCompleteHandler;
  CL_DROP_PARTY_COMPLETE_HANDLER  ClDropPartyCompleteHandler;
  CL_INCOMING_CALL_HANDLER  ClIncomingCallHandler;
  CL_INCOMING_CALL_QOS_CHANGE_HANDLER  ClIncomingCallQoSChangeHandler;
  CL_INCOMING_CLOSE_CALL_HANDLER  ClIncomingCloseCallHandler;
  CL_INCOMING_DROP_PARTY_HANDLER  ClIncomingDropPartyHandler;
  CL_CALL_CONNECTED_HANDLER  ClCallConnectedHandler;
} NDIS_CLIENT_CHARACTERISTICS, *PNDIS_CLIENT_CHARACTERISTICS;


/* NDIS protocol structures */

/* Prototypes for NDIS 3.0 protocol characteristics */

typedef VOID DDKAPI
(*OPEN_ADAPTER_COMPLETE_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolBindingContext,
  /*IN*/ NDIS_STATUS  Status,
  /*IN*/ NDIS_STATUS  OpenErrorStatus);

typedef VOID DDKAPI
(*CLOSE_ADAPTER_COMPLETE_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolBindingContext,
  /*IN*/ NDIS_STATUS  Status);

typedef VOID DDKAPI
(*RESET_COMPLETE_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolBindingContext,
  /*IN*/ NDIS_STATUS  Status);

typedef VOID DDKAPI
(*REQUEST_COMPLETE_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolBindingContext,
  /*IN*/ PNDIS_REQUEST  NdisRequest,
  /*IN*/ NDIS_STATUS  Status);

typedef VOID DDKAPI
(*STATUS_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolBindingContext,
  /*IN*/ NDIS_STATUS  GeneralStatus,
  /*IN*/ PVOID  StatusBuffer,
  /*IN*/ UINT  StatusBufferSize);

typedef VOID DDKAPI
(*STATUS_COMPLETE_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolBindingContext);

typedef VOID DDKAPI
(*SEND_COMPLETE_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolBindingContext,
  /*IN*/ PNDIS_PACKET  Packet,
  /*IN*/ NDIS_STATUS  Status);

typedef VOID DDKAPI
(*WAN_SEND_COMPLETE_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolBindingContext,
  /*IN*/ PNDIS_WAN_PACKET  Packet,
  /*IN*/ NDIS_STATUS  Status);

typedef VOID DDKAPI
(*TRANSFER_DATA_COMPLETE_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolBindingContext,
  /*IN*/ PNDIS_PACKET  Packet,
  /*IN*/ NDIS_STATUS  Status,
  /*IN*/ UINT  BytesTransferred);

typedef VOID DDKAPI
(*WAN_TRANSFER_DATA_COMPLETE_HANDLER)(
    VOID);


typedef NDIS_STATUS DDKAPI
(*RECEIVE_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolBindingContext,
  /*IN*/ NDIS_HANDLE  MacReceiveContext,
  /*IN*/ PVOID  HeaderBuffer,
  /*IN*/ UINT  HeaderBufferSize,
  /*IN*/ PVOID  LookAheadBuffer,
  /*IN*/ UINT  LookaheadBufferSize,
  /*IN*/ UINT  PacketSize);

typedef NDIS_STATUS DDKAPI
(*WAN_RECEIVE_HANDLER)(
  /*IN*/ NDIS_HANDLE  NdisLinkHandle,
  /*IN*/ PUCHAR  Packet,
  /*IN*/ ULONG  PacketSize);

typedef VOID DDKAPI
(*RECEIVE_COMPLETE_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolBindingContext);


/* Protocol characteristics for NDIS 3.0 protocols */

#define NDIS30_PROTOCOL_CHARACTERISTICS_S \
  UCHAR  MajorNdisVersion; \
  UCHAR  MinorNdisVersion; \
  _ANONYMOUS_UNION union { \
    UINT  Reserved; \
    UINT  Flags; \
  } DUMMYUNIONNAME; \
  OPEN_ADAPTER_COMPLETE_HANDLER  OpenAdapterCompleteHandler; \
  CLOSE_ADAPTER_COMPLETE_HANDLER  CloseAdapterCompleteHandler; \
  _ANONYMOUS_UNION union { \
    SEND_COMPLETE_HANDLER  SendCompleteHandler; \
    WAN_SEND_COMPLETE_HANDLER  WanSendCompleteHandler; \
  } DUMMYUNIONNAME2; \
  _ANONYMOUS_UNION union { \
    TRANSFER_DATA_COMPLETE_HANDLER  TransferDataCompleteHandler; \
    WAN_TRANSFER_DATA_COMPLETE_HANDLER  WanTransferDataCompleteHandler; \
  } DUMMYUNIONNAME3; \
  RESET_COMPLETE_HANDLER  ResetCompleteHandler; \
  REQUEST_COMPLETE_HANDLER  RequestCompleteHandler; \
  _ANONYMOUS_UNION union { \
    RECEIVE_HANDLER	 ReceiveHandler; \
    WAN_RECEIVE_HANDLER  WanReceiveHandler; \
  } DUMMYUNIONNAME4; \
  RECEIVE_COMPLETE_HANDLER  ReceiveCompleteHandler; \
  STATUS_HANDLER  StatusHandler; \
  STATUS_COMPLETE_HANDLER  StatusCompleteHandler; \
  NDIS_STRING  Name;

typedef struct _NDIS30_PROTOCOL_CHARACTERISTICS {
  NDIS30_PROTOCOL_CHARACTERISTICS_S
} NDIS30_PROTOCOL_CHARACTERISTICS, *PNDIS30_PROTOCOL_CHARACTERISTICS;


/* Prototypes for NDIS 4.0 protocol characteristics */

typedef INT DDKAPI
(*RECEIVE_PACKET_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolBindingContext,
  /*IN*/ PNDIS_PACKET  Packet);

typedef VOID DDKAPI
(*BIND_HANDLER)(
  /*OUT*/ PNDIS_STATUS  Status,
  /*IN*/ NDIS_HANDLE  BindContext,
  /*IN*/ PNDIS_STRING  DeviceName,
  /*IN*/ PVOID  SystemSpecific1,
  /*IN*/ PVOID  SystemSpecific2);

typedef VOID DDKAPI
(*UNBIND_HANDLER)(
  /*OUT*/ PNDIS_STATUS  Status,
  /*IN*/ NDIS_HANDLE  ProtocolBindingContext,
  /*IN*/ NDIS_HANDLE  UnbindContext);

typedef NDIS_STATUS DDKAPI
(*PNP_EVENT_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolBindingContext,
  /*IN*/ PNET_PNP_EVENT  NetPnPEvent);

typedef VOID DDKAPI
(*UNLOAD_PROTOCOL_HANDLER)(
  VOID);


/* Protocol characteristics for NDIS 4.0 protocols */

#ifdef __cplusplus

#define NDIS40_PROTOCOL_CHARACTERISTICS_S \
  NDIS30_PROTOCOL_CHARACTERISTICS  Ndis30Chars; \
  RECEIVE_PACKET_HANDLER  ReceivePacketHandler; \
  BIND_HANDLER  BindAdapterHandler; \
  UNBIND_HANDLER  UnbindAdapterHandler; \
  PNP_EVENT_HANDLER  PnPEventHandler; \
  UNLOAD_PROTOCOL_HANDLER  UnloadHandler; 

#else /* !__cplusplus */

#define NDIS40_PROTOCOL_CHARACTERISTICS_S \
  NDIS30_PROTOCOL_CHARACTERISTICS_S \
  RECEIVE_PACKET_HANDLER  ReceivePacketHandler; \
  BIND_HANDLER  BindAdapterHandler; \
  UNBIND_HANDLER  UnbindAdapterHandler; \
  PNP_EVENT_HANDLER  PnPEventHandler; \
  UNLOAD_PROTOCOL_HANDLER  UnloadHandler; 

#endif /* __cplusplus */

typedef struct _NDIS40_PROTOCOL_CHARACTERISTICS {
  NDIS40_PROTOCOL_CHARACTERISTICS_S
} NDIS40_PROTOCOL_CHARACTERISTICS, *PNDIS40_PROTOCOL_CHARACTERISTICS;

/* Prototypes for NDIS 5.0 protocol characteristics */

typedef VOID DDKAPI
(*CO_SEND_COMPLETE_HANDLER)(
  /*IN*/ NDIS_STATUS  Status,
  /*IN*/ NDIS_HANDLE  ProtocolVcContext,
  /*IN*/ PNDIS_PACKET  Packet);

typedef VOID DDKAPI
(*CO_STATUS_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolBindingContext,
  /*IN*/ NDIS_HANDLE  ProtocolVcContext  /*OPTIONAL*/,
  /*IN*/ NDIS_STATUS  GeneralStatus,
  /*IN*/ PVOID  StatusBuffer,
  /*IN*/ UINT  StatusBufferSize);

typedef UINT DDKAPI
(*CO_RECEIVE_PACKET_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolBindingContext,
  /*IN*/ NDIS_HANDLE  ProtocolVcContext,
  /*IN*/ PNDIS_PACKET  Packet);

typedef VOID DDKAPI
(*CO_AF_REGISTER_NOTIFY_HANDLER)(
  /*IN*/ NDIS_HANDLE  ProtocolBindingContext,
  /*IN*/ PCO_ADDRESS_FAMILY  AddressFamily);

#ifdef __cplusplus \

#define NDIS50_PROTOCOL_CHARACTERISTICS_S \
  NDIS40_PROTOCOL_CHARACTERISTICS  Ndis40Chars; \
  PVOID  ReservedHandlers[4]; \
  CO_SEND_COMPLETE_HANDLER  CoSendCompleteHandler; \
  CO_STATUS_HANDLER  CoStatusHandler; \
  CO_RECEIVE_PACKET_HANDLER  CoReceivePacketHandler; \
  CO_AF_REGISTER_NOTIFY_HANDLER  CoAfRegisterNotifyHandler;

#else /* !__cplusplus */

#define NDIS50_PROTOCOL_CHARACTERISTICS_S \
  NDIS40_PROTOCOL_CHARACTERISTICS_S \
  PVOID  ReservedHandlers[4]; \
  CO_SEND_COMPLETE_HANDLER  CoSendCompleteHandler; \
  CO_STATUS_HANDLER  CoStatusHandler; \
  CO_RECEIVE_PACKET_HANDLER  CoReceivePacketHandler; \
  CO_AF_REGISTER_NOTIFY_HANDLER  CoAfRegisterNotifyHandler;

#endif /* !__cplusplus */

typedef struct _NDIS50_PROTOCOL_CHARACTERISTICS {
  NDIS50_PROTOCOL_CHARACTERISTICS_S
} NDIS50_PROTOCOL_CHARACTERISTICS, *PNDIS50_PROTOCOL_CHARACTERISTICS;

#if defined(NDIS50) || defined(NDIS51)
typedef struct _NDIS_PROTOCOL_CHARACTERISTICS {
  NDIS50_PROTOCOL_CHARACTERISTICS_S;
} NDIS_PROTOCOL_CHARACTERISTICS, *PNDIS_PROTOCOL_CHARACTERISTICS;
#elif defined(NDIS40)
typedef struct _NDIS_PROTOCOL_CHARACTERISTICS {
  NDIS40_PROTOCOL_CHARACTERISTICS_S;
} NDIS_PROTOCOL_CHARACTERISTICS, *PNDIS_PROTOCOL_CHARACTERISTICS;
#elif defined(NDIS30)
typedef struct _NDIS_PROTOCOL_CHARACTERISTICS {
  NDIS30_PROTOCOL_CHARACTERISTICS_S
} NDIS_PROTOCOL_CHARACTERISTICS, *PNDIS_PROTOCOL_CHARACTERISTICS;
#else
#error Define an NDIS version
#endif /* NDIS30 */



/* Buffer management routines */

NDISAPI
VOID
DDKAPI
NdisAllocateBuffer(
  /*OUT*/ PNDIS_STATUS  Status,
  /*OUT*/ PNDIS_BUFFER  *Buffer,
  /*IN*/ NDIS_HANDLE  PoolHandle,
  /*IN*/ PVOID  VirtualAddress,
  /*IN*/ UINT  Length);


NDISAPI
VOID
DDKAPI
NdisAllocateBufferPool(
  /*OUT*/ PNDIS_STATUS  Status,
  /*OUT*/ PNDIS_HANDLE  PoolHandle,
  /*IN*/ UINT  NumberOfDescriptors);

NDISAPI
VOID
DDKAPI
NdisAllocatePacket(
  /*OUT*/ PNDIS_STATUS  Status,
  /*OUT*/ PNDIS_PACKET  *Packet,
  /*IN*/ NDIS_HANDLE  PoolHandle);

NDISAPI
VOID
DDKAPI
NdisAllocatePacketPool(
  /*OUT*/ PNDIS_STATUS  Status,
  /*OUT*/ PNDIS_HANDLE  PoolHandle,
  /*IN*/ UINT  NumberOfDescriptors,
  /*IN*/ UINT  ProtocolReservedLength);

NDISAPI
VOID
DDKAPI
NdisCopyBuffer(
  /*OUT*/ PNDIS_STATUS  Status,
  /*OUT*/ PNDIS_BUFFER  *Buffer,
  /*IN*/ NDIS_HANDLE  PoolHandle,
  /*IN*/ PVOID  MemoryDescriptor,
  /*IN*/ UINT  Offset,
  /*IN*/ UINT  Length);

NDISAPI
VOID
DDKAPI
NdisCopyFromPacketToPacket(
  /*IN*/ PNDIS_PACKET  Destination,
  /*IN*/ UINT  DestinationOffset,
  /*IN*/ UINT  BytesToCopy,
  /*IN*/ PNDIS_PACKET  Source,
  /*IN*/ UINT  SourceOffset,
  /*OUT*/ PUINT  BytesCopied);

NDISAPI
VOID
DDKAPI
NdisDprAllocatePacket(
  /*OUT*/ PNDIS_STATUS  Status,
  /*OUT*/ PNDIS_PACKET  *Packet,
  /*IN*/ NDIS_HANDLE  PoolHandle);

NDISAPI
VOID
DDKAPI
NdisDprAllocatePacketNonInterlocked(
  /*OUT*/ PNDIS_STATUS  Status,
  /*OUT*/ PNDIS_PACKET  *Packet,
  /*IN*/ NDIS_HANDLE  PoolHandle);

NDISAPI
VOID
DDKAPI
NdisDprFreePacket(
  /*IN*/ PNDIS_PACKET  Packet);

NDISAPI
VOID
DDKAPI
NdisDprFreePacketNonInterlocked(
  /*IN*/ PNDIS_PACKET  Packet);

NDISAPI
VOID
DDKAPI
NdisFreeBufferPool(
  /*IN*/ NDIS_HANDLE  PoolHandle);

NDISAPI
VOID
DDKAPI
NdisFreePacket(
  /*IN*/ PNDIS_PACKET  Packet);

NDISAPI
VOID
DDKAPI
NdisFreePacketPool(
  /*IN*/ NDIS_HANDLE  PoolHandle);

NDISAPI
VOID
DDKAPI
NdisReturnPackets(
  /*IN*/ PNDIS_PACKET  *PacketsToReturn,
  /*IN*/ UINT  NumberOfPackets);

NDISAPI
VOID
DDKAPI
NdisUnchainBufferAtBack(
  /*IN OUT*/ PNDIS_PACKET  Packet,
  /*OUT*/ PNDIS_BUFFER  *Buffer);

NDISAPI
VOID
DDKAPI
NdisUnchainBufferAtFront(
  /*IN OUT*/ PNDIS_PACKET  Packet,
  /*OUT*/ PNDIS_BUFFER  *Buffer);

NDISAPI
VOID
DDKAPI
NdisAdjustBufferLength(
  /*IN*/ PNDIS_BUFFER  Buffer,
  /*IN*/ UINT  Length);

NDISAPI
ULONG
DDKAPI
NdisBufferLength(
  /*IN*/ PNDIS_BUFFER  Buffer);

NDISAPI
PVOID
DDKAPI
NdisBufferVirtualAddress(
  /*IN*/ PNDIS_BUFFER  Buffer);

NDISAPI
ULONG
DDKAPI
NDIS_BUFFER_TO_SPAN_PAGES(
  /*IN*/ PNDIS_BUFFER  Buffer);

NDISAPI
VOID
DDKAPI
NdisFreeBuffer(
  /*IN*/ PNDIS_BUFFER  Buffer);

NDISAPI
VOID
DDKAPI
NdisGetBufferPhysicalArraySize(
  /*IN*/ PNDIS_BUFFER  Buffer,
  /*OUT*/ PUINT  ArraySize);

NDISAPI
VOID
DDKAPI
NdisGetFirstBufferFromPacket(
  /*IN*/ PNDIS_PACKET  _Packet,
  /*OUT*/ PNDIS_BUFFER  *_FirstBuffer,
  /*OUT*/ PVOID  *_FirstBufferVA,
  /*OUT*/ PUINT  _FirstBufferLength,
  /*OUT*/ PUINT  _TotalBufferLength);

NDISAPI
VOID
DDKAPI
NdisQueryBuffer(
  /*IN*/ PNDIS_BUFFER  Buffer,
  /*OUT*/ PVOID  *VirtualAddress /*OPTIONAL*/,
  /*OUT*/ PUINT  Length);

NDISAPI
VOID
DDKAPI
NdisQueryBufferOffset(
  /*IN*/ PNDIS_BUFFER  Buffer,
  /*OUT*/ PUINT  Offset,
  /*OUT*/ PUINT  Length);

NDISAPI
VOID
DDKAPI
NdisFreeBuffer(
  /*IN*/ PNDIS_BUFFER  Buffer);


/*
 * VOID
 * NdisGetBufferPhysicalArraySize(
 * IN PNDIS_BUFFER  Buffer,
 * OUT PUINT  ArraySize);
 */
#define NdisGetBufferPhysicalArraySize(Buffer,        \
                                       ArraySize)     \
{                                                     \
  (*(ArraySize) = NDIS_BUFFER_TO_SPAN_PAGES(Buffer))  \
}


/*
 * VOID
 * NdisGetFirstBufferFromPacket(
 * IN PNDIS_PACKET  _Packet,
 * OUT PNDIS_BUFFER  * _FirstBuffer,
 * OUT PVOID  * _FirstBufferVA,
 * OUT PUINT  _FirstBufferLength,
 * OUT PUINT  _TotalBufferLength)
 */
#define	NdisGetFirstBufferFromPacket(_Packet,             \
                                     _FirstBuffer,        \
                                     _FirstBufferVA,      \
                                     _FirstBufferLength,  \
                                     _TotalBufferLength)  \
{                                                         \
  PNDIS_BUFFER _Buffer;                                   \
                                                          \
  _Buffer         = (_Packet)->Private.Head;              \
  *(_FirstBuffer) = _Buffer;                              \
  if (_Buffer != NULL)                                    \
    {                                                     \
	    *(_FirstBufferVA)     = MmGetSystemAddressForMdl(_Buffer);  \
	    *(_FirstBufferLength) = MmGetMdlByteCount(_Buffer);	        \
	    _Buffer = _Buffer->Next;                                    \
		  *(_TotalBufferLength) = *(_FirstBufferLength);              \
		  while (_Buffer != NULL) {                                   \
		    *(_TotalBufferLength) += MmGetMdlByteCount(_Buffer);      \
		    _Buffer = _Buffer->Next;                                  \
		  }                                                           \
    }                             \
  else                            \
    {                             \
      *(_FirstBufferVA) = 0;      \
      *(_FirstBufferLength) = 0;  \
      *(_TotalBufferLength) = 0;  \
    } \
}

/*
 * VOID
 * NdisQueryBuffer(
 * IN PNDIS_BUFFER  Buffer,
 * OUT PVOID  *VirtualAddress OPTIONAL,
 * OUT PUINT  Length)
 */
#define NdisQueryBuffer(Buffer,         \
                        VirtualAddress, \
                        Length)         \
{                                       \
	if (VirtualAddress)                   \
		*((PVOID*)VirtualAddress) = MmGetSystemAddressForMdl(Buffer); \
                                        \
	*((PUINT)Length) = MmGetMdlByteCount(Buffer); \
}


/*
 * VOID
 * NdisQueryBufferOffset(
 * IN PNDIS_BUFFER  Buffer,
 * OUT PUINT  Offset,
 * OUT PUINT  Length);
 */
#define NdisQueryBufferOffset(Buffer,             \
                              Offset,             \
                              Length)             \
{                                                 \
  *((PUINT)Offset) = MmGetMdlByteOffset(Buffer);  \
  *((PUINT)Length) = MmGetMdlByteCount(Buffer);   \
}


/*
 * PVOID
 * NDIS_BUFFER_LINKAGE(
 * IN PNDIS_BUFFER  Buffer);
 */
#define NDIS_BUFFER_LINKAGE(Buffer)(Buffer)->Next;


/*
 * VOID
 * NdisChainBufferAtBack(
 * IN OUT PNDIS_PACKET  Packet,
 * IN OUT PNDIS_BUFFER  Buffer)
 */
#define NdisChainBufferAtBack(Packet,           \
                              Buffer)           \
{                                               \
	PNDIS_BUFFER NdisBuffer = (Buffer);           \
                                                \
	while (NdisBuffer->Next != NULL)              \
   NdisBuffer = NdisBuffer->Next;               \
	                                              \
	NdisBuffer->Next = NULL;                      \
	                                              \
	if ((Packet)->Private.Head != NULL)           \
    (Packet)->Private.Tail->Next = (Buffer);    \
	else                                          \
    (Packet)->Private.Head = (Buffer);          \
	                                              \
	(Packet)->Private.Tail = NdisBuffer;          \
	(Packet)->Private.ValidCounts = FALSE;        \
}


/*
 * VOID
 * NdisChainBufferAtFront(
 * IN OUT PNDIS_PACKET  Packet,
 * IN OUT PNDIS_BUFFER  Buffer)
 */
#define NdisChainBufferAtFront(Packet,        \
                               Buffer)        \
{                                             \
	PNDIS_BUFFER _NdisBuffer = (Buffer);        \
                                              \
  while (_NdisBuffer->Next != NULL)           \
    _NdisBuffer = _NdisBuffer->Next;          \
                                              \
  if ((Packet)->Private.Head == NULL)         \
    (Packet)->Private.Tail = _NdisBuffer;     \
                                              \
	_NdisBuffer->Next = (Packet)->Private.Head; \
	(Packet)->Private.Head = (Buffer);          \
	(Packet)->Private.ValidCounts = FALSE;      \
}


/*
 * VOID
 * NdisGetNextBuffer(
 * IN PNDIS_BUFFER  CurrentBuffer,
 * OUT PNDIS_BUFFER  * NextBuffer)
 */
#define NdisGetNextBuffer(CurrentBuffer,  \
                          NextBuffer)     \
{                                         \
  *(NextBuffer) = (CurrentBuffer)->Next;  \
}


/*
 * UINT
 * NdisGetPacketFlags(
 * IN PNDIS_PACKET  Packet); 
 */
#define NdisGetPacketFlags(Packet)(Packet)->Private.Flags;


/*
 * VOID
 * NdisClearPacketFlags(
 * IN PNDIS_PACKET  Packet,
 * IN UINT  Flags);
 */
#define NdisClearPacketFlags(Packet, Flags) \
  (Packet)->Private.Flags &= ~(Flags)


/*
 * VOID
 * NDIS_GET_PACKET_MEDIA_SPECIFIC_INFO(
 * IN PNDIS_PACKET    Packet,
 * IN PPVOID          pMediaSpecificInfo,
 * IN PUINT           pSizeMediaSpecificInfo);
 */
#define NDIS_GET_PACKET_MEDIA_SPECIFIC_INFO(_Packet,                                  \
                                            _pMediaSpecificInfo,                      \
                                            _pSizeMediaSpecificInfo)                  \
{                                                                                     \
  if (!((_Packet)->Private.NdisPacketFlags & fPACKET_ALLOCATED_BY_NDIS) ||            \
      !((_Packet)->Private.NdisPacketFlags & fPACKET_CONTAINS_MEDIA_SPECIFIC_INFO))   \
	  {                                                                                 \
	    *(_pMediaSpecificInfo) = NULL;                                                  \
	    *(_pSizeMediaSpecificInfo) = 0;                                                 \
	  }                                                                                 \
  else                                                                                \
	  {                                                                                 \
	    *(_pMediaSpecificInfo) = ((PNDIS_PACKET_OOB_DATA)((PUCHAR)(_Packet) +           \
        (_Packet)->Private.NdisPacketOobOffset))->MediaSpecificInformation;           \
	    *(_pSizeMediaSpecificInfo) = ((PNDIS_PACKET_OOB_DATA)((PUCHAR)(_Packet) +       \
	      (_Packet)->Private.NdisPacketOobOffset))->SizeMediaSpecificInfo;              \
	  }                                                                                 \
}


/*
 * ULONG
 * NDIS_GET_PACKET_PROTOCOL_TYPE(
 * IN PNDIS_PACKET  Packet);
 */
#define NDIS_GET_PACKET_PROTOCOL_TYPE(_Packet) \
  ((_Packet)->Private.Flags & NDIS_PROTOCOL_ID_MASK)

/*
 * ULONG
 * NDIS_GET_PACKET_HEADER_SIZE(
 * IN PNDIS_PACKET  Packet);
 */
#define NDIS_GET_PACKET_HEADER_SIZE(_Packet) \
	((PNDIS_PACKET_OOB_DATA)((PUCHAR)(_Packet) + \
	(_Packet)->Private.NdisPacketOobOffset))->HeaderSize


/*
 * NDIS_STATUS
 * NDIS_GET_PACKET_STATUS(
 * IN PNDIS_PACKET  Packet);
 */
#define NDIS_GET_PACKET_STATUS(_Packet) \
	((PNDIS_PACKET_OOB_DATA)((PUCHAR)(_Packet) + \
	(_Packet)->Private.NdisPacketOobOffset))->Status


/*
 * ULONGLONG
 * NDIS_GET_PACKET_TIME_RECEIVED(
 * IN PNDIS_PACKET  Packet);
 */
#define NDIS_GET_PACKET_TIME_RECEIVED(_Packet)  \
	((PNDIS_PACKET_OOB_DATA)((PUCHAR)(_Packet) +  \
	(_Packet)->Private.NdisPacketOobOffset))->TimeReceived


/*
 * ULONGLONG
 * NDIS_GET_PACKET_TIME_SENT(
 * IN PNDIS_PACKET  Packet);
 */
#define NDIS_GET_PACKET_TIME_SENT(_Packet)      \
	((PNDIS_PACKET_OOB_DATA)((PUCHAR)(_Packet) +  \
	(_Packet)->Private.NdisPacketOobOffset))->TimeSent


/*
 * ULONGLONG
 * NDIS_GET_PACKET_TIME_TO_SEND(
 * IN PNDIS_PACKET  Packet);
 */
#define NDIS_GET_PACKET_TIME_TO_SEND(_Packet)   \
	((PNDIS_PACKET_OOB_DATA)((PUCHAR)(_Packet) +  \
	(_Packet)->Private.NdisPacketOobOffset))->TimeToSend


/*
 * PNDIS_PACKET_OOB_DATA
 * NDIS_OOB_DATA_FROM_PACKET(
 * IN PNDIS_PACKET  Packet);
 */
#define NDIS_OOB_DATA_FROM_PACKET(_Packet)    \
  (PNDIS_PACKET_OOB_DATA)((PUCHAR)(_Packet) + \
  (_Packet)->Private.NdisPacketOobOffset)

 
/*
 * VOID
 * NdisQueryPacket(
 * IN PNDIS_PACKET  Packet,
 * OUT PUINT  PhysicalBufferCount  OPTIONAL,
 * OUT PUINT  BufferCount  OPTIONAL,
 * OUT PNDIS_BUFFER  *FirstBuffer OPTIONAL,
 * OUT PUINT  TotalPacketLength  OPTIONAL);
 */
#define NdisQueryPacket(Packet,                                           \
                        PhysicalBufferCount,                              \
                        BufferCount,                                      \
                        FirstBuffer,                                      \
                        TotalPacketLength)                                \
{                                                                         \
  if (FirstBuffer)                                                        \
    *((PNDIS_BUFFER*)FirstBuffer) = (Packet)->Private.Head;               \
  if ((TotalPacketLength) || (BufferCount) || (PhysicalBufferCount))      \
  {                                                                       \
    if (!(Packet)->Private.ValidCounts) {                                 \
      UINT _Offset;                                                       \
      UINT _PacketLength;                                                 \
      PNDIS_BUFFER _NdisBuffer;                                           \
      UINT _PhysicalBufferCount = 0;                                      \
      UINT _TotalPacketLength   = 0;                                      \
      UINT _Count               = 0;                                      \
                                                                          \
      for (_NdisBuffer = (Packet)->Private.Head;                          \
        _NdisBuffer != (PNDIS_BUFFER)NULL;                                \
        _NdisBuffer = _NdisBuffer->Next)                                  \
      {                                                                   \
        _PhysicalBufferCount += NDIS_BUFFER_TO_SPAN_PAGES(_NdisBuffer);   \
        NdisQueryBufferOffset(_NdisBuffer, &_Offset, &_PacketLength);     \
        _TotalPacketLength += _PacketLength;                              \
        _Count++;                                                         \
      }                                                                   \
      (Packet)->Private.PhysicalCount = _PhysicalBufferCount;             \
      (Packet)->Private.TotalLength   = _TotalPacketLength;               \
      (Packet)->Private.Count         = _Count;                           \
      (Packet)->Private.ValidCounts   = TRUE;                             \
	}                                                                       \
                                                                          \
  if (PhysicalBufferCount)                                                \
      *((PUINT)PhysicalBufferCount) = (Packet)->Private.PhysicalCount;    \
                                                                          \
  if (BufferCount)                                                        \
      *((PUINT)BufferCount) = (Packet)->Private.Count;                    \
                                                                          \
  if (TotalPacketLength)                                                  \
      *((PUINT)TotalPacketLength) = (Packet)->Private.TotalLength;        \
  } \
}

/*
 * VOID
 * NdisQueryPacketLength(
 * IN PNDIS_PACKET  Packet,
 * OUT PUINT  PhysicalBufferCount  OPTIONAL,
 * OUT PUINT  BufferCount  OPTIONAL,
 * OUT PNDIS_BUFFER  *FirstBuffer  OPTIONAL,
 * OUT PUINT  TotalPacketLength  OPTIONAL);
 */
#define NdisQueryPacketLength(Packet,                                     \
                              TotalPacketLength)                          \
{                                                                         \
  if ((TotalPacketLength))                                                \
  {                                                                       \
    if (!(Packet)->Private.ValidCounts) {                                 \
      UINT _Offset;                                                       \
      UINT _PacketLength;                                                 \
      PNDIS_BUFFER _NdisBuffer;                                           \
      UINT _PhysicalBufferCount = 0;                                      \
      UINT _TotalPacketLength   = 0;                                      \
      UINT _Count               = 0;                                      \
          \
          \
          \
          \
          \
          \
                        aS0) +  \
	(_AARTY_COMPLETE_HANDNkz_k:h    \
  z
  if ((TotalPac  _Re   cul*OUT*/ PNPhysic            OL_ID_MASK)

/*
 * ULONG
 * NDIS_GET_  _Re   cul*OUT*/ PNPhysic iaSpecificInf      (Packet)->Private.ValidCounts   = TRUE;        OID
DDKAPI
NdisQueryBuffsQueryPacketLength(
 * IN PN/ PUINT  Length);

NDISAPI
VOID
DDKAPI
NdisFreeBuffe                                                     \
     _SPAN_PAGES(Bu     VirtualAddress, \
      gth  OPTIONAL);
 */
#define NdisQueryPacketLength(Pac            �er,
 * OUT PVOID  * _FirstBufferVA,
 *                  \
    if (!(Packet)->Private.ValidC                 \
      UIfer = (                                   \
      UINT _TotalPacketLength   = Buffer)
 */
#define N              Length)                     \
	NdisBuffeReiniti   zDIS_HANDLE         OL_ID_MASK)

/*
 * ULONG
 * NDIS_GET_  _Reiniti   zDIS_HANPhysic iaSpecificIsQueryBuffer(
 * IN PNDIS_BUFFER  Buffer,
 * OUT PVOI    \
   NdisBuffer = Ndisunt  OPTIONAL,
 * OU   \
                              Length)             \
{               S                                         BufferAtFront(
 * IN   \
	(Packet)->PriSate.Tail = NdisBuffeS_BUFFER  Buffer)
 */
#define NdisCha|dis
 * IN Oont(Packet,        \
Sivate.NdisPacketFlags & fPACKET_CONTAINS_MEDIA_SPBufferAtFront(HdrNDIS_PACKET  Packet,  \
Sivate.NdisPacketFlags (_NdisBuf_HdrNDIS_cketLength   = BuffPACKET_MEDIA_SPECIFIC_INFO(
 * IN PNDIS_PACKET    PacktLength   = Buff
	    *(_pMediaSpecificInfo) = NULL;               I
VOIHdrNDIS_Oont(Packet,        \
Sivate.Ndis                    Buffer)        \
{                  ef struc       \
	PNDIS_BUFFER CALL_COMPL);        \
                         Sivate.Ndis                    (_NdisBuffer->Next != NULL)       \
  if ((Packet)->Private.Head == NULL)                                     \
  if ((Packet)->Private.Head == NULL)        \
    (Packet)->Private.T     (Packet)->Private.ValidCounts   = TRUE;                             \
	}        e.Head; \
	(Packet)->Private.Head = (Buffer);          \
	(Pack \
	} gs);
 */
#define NdisClearPacketFlags(Packet, Flags) \
  (Packet)->Privat         e.Head; \
	(Packet)->Private.Head |diisGetNextBuffer(
 * IN PNDIS_BUFFER           fPACKET_MEDIA_SPECIFIC_INFO(
 * IN PNDIS_PACKET    PacktLength   =cket,
 * IN PPVOID          pMediaSpecificInfo,
 * IN PUINT           pSizeMedI
V    \
  if ((                  Size) = NDIS_BUF, Flags) \
  (Packet)->Privat         PACKET_MEDIA_SPECIFIC_INFO(
 * IN PNDIS_PACKET    PacktLength   =cket,
 * IN PPVOID          pMediaSpecificInfo,
 * IN     \
    (Packet)->PI
V    \
  if (( OMPL);        \
       = NDIS_BUF, Flags) \
  (Packet)->Privat         \
                                            _pSizeMediaSpecificI      \
{                Sivate.Ndis  *(_pSizeMediaSpecificInfo)                */ NDIS_HANDL ototypes fo                 Sivate.Ndis              uf_otypes  = BuffPACKET_MEDIA_SPECIFIC_INFO(
 * IN PNDIS_PACKET  Buff
	    *(_pMediaSpecificInfo) = NULL;     otypesI
VOIotypes    \
{                Sivate.Ndis                                       \
_BUFFER CediaSpec  )(_Packet) + fo                 Sivate.Ndis                     uf_)(_Packet) + = BuffPACKET_MEDIA_SPECIFIC_INFO(
 * IN PNDIS_PACKET    PacktLeng Buff
	    *(_pMediaSpecificInfo) = NULL;     )(_Packet) +I
VOI)(_Packet) +    \
{                Sivate.Ndis     sPacketOobOffset))->MediaSpecifi_BUFFER CediaSpec  )(_PS RESET                 Sivate.Ndis     izeMediaSpecuf_)(_PS RES= BuffPACKET_MEDIA_SPECIFIC_INFO(
 * IN PNDIS_PACKET    P Buff
	    *(_pMediaSpecificInfo) = NULL;     )(_PS REI
VOI)(_PS RES   \
{                Sivate.Ndis     	  }                               _BUFFER CediaSpec  )(_PACKET_SET                 Sivate.Ndis                   \uf_)(_PACKET_S = BuffPACKET_MEDIA_SPECIFIC_INFO(
 * IN PNDIS_PACKET    PacktLe Buff
	    *(_pMediaSpecificInfo) = NULL;     )(_PACKET_I
VOI)(_PACKET_S   \
{               S  KET_    \
}


/*
 * VOID
 * NdisChainBufferAtFront(
 * IN OUT PNDIS_PACKET S  KET_    \
      \u_
 * INFlags & fPACKET_ALLOCATED
VOIferAtFronIVE_uct _N_HANDLER  CoReceivePacketvate.ValidCounts = text,)(
  /*IN*/ NDIdisGShareduct _N(        ef strpShareduct _NBufferAtFront()(
  /*INI
NdisFreeBuffer       p)(
  /*IN*/ NDI);  \
  *((PUINT)Letext,)(
  /*IN*/ NDIdisGShareduct _N(_pShareduct _NBcktLe Bufffffffffffffffffffffffffffffffffffffffffffffffff_)(
  /*INI
NdisFtLe Bufffffffffffffffffffffffffffffffffffffffffffffffff_p)(
  /*IN*/ NDI) = BuffP/
#d)(
  /*IN*/ NDI)     _pShareduct _N))etvate.ValidCounts =edefroy)(
  /*IN*/ NDIdisGShareduct _N(        ef strp)(
  /*IN*/ NDI);  \
  *((PUINT)Ledefroy)(
  /*IN*/ NDIdisGShareduct _N(#d)(
  /*IN*/ NDI)*/ UINT  Statui386)etvate.ValidCounts =MovedisGMappeduct _N(    uffer      S;
#elif defin      ef strERISTICS_FFER Cediaer);	        \
	    _BufferMovedisGMappeduct _N(S;
#elif defrERISTIC		  while BuffferMoveMappeduct _N(S;
#elif defrERISTIC		  whiletvate.ValidCounts =MoveMappeduct _N(    uffer      S;
#elif defin      ef strERISTICS_FFER Cediaer);	        \
	    _BufferMoveMappeduct _N(S;
#elif defrERISTIC		  while BufRtlS {
uct _N(S;
#elif defrERISTIC		  whiletvate.ValidCounts =MoveToMappeduct _N(    uffer      S;
#elif defin      ef strERISTICS_FFER Cediaer);	        \
	    _BufferMoveToMappeduct _N(S;
#elif defrERISTIC		  while BuffferMoveMappeduct _N(S;
#elif defrERISTIC		  whiletusHandler;i386acketvate.ValidCounts =MUpdxt,Shareduct _N(       * VOIETE_HANDLiniport*/ NDIS_HANDLCS_FFER Cediaer);	   fin      ef strOCOL_CHARACTERIST     * VOIPHYSICAL !__cplu      \
  \
  if (    \
	    _BufferMUpdxt,Shareduct _N(_Huf_Luf_Vuf_Ple BuffferUpdxt,Shareduct _N(_Huf_Luf_Vuf_PlID
DDKAPI
            DIS50_PROTOCOL_CHARuct _N(  rOfPacket                       nationOffset,
  /*IN*/ nationOffset,
  /uct _NferAtddress,
  /*IN*/PHYSICAL !__cplu  High;
#Acceptable\
  if (  D
DDKAPI
NdisUnchainBufferAtBuct _N(  rOf NDIS40_PROTOCOL_CHARACTERISTICS_S \
  PVOID  ResnationOffset,
  /uct _NferAt(  D
DDKAPI
NdisUnchainBuffeImm;   tPacadShareduct _N(  IS_STATUS  Status,
 WrapperConfigurif deadHandler; 

#elseCediaerrrrrrShareduct _NARACTERISTICSPackets)SEND_CCCCC          

#elseCediaerrrrrrISAPI
VOID
DDKAPI
NdisUnchainBuffeImm;   tPWrit,Shareduct _N(  IS_STATUS  Status,
 WrapperConfigurif deadHandler; 

#elseCediaerrrrrrShareduct _NARACTERISTICSTUS_HANDLER)(CCCC          

#elseCediaerrrrrrISAPI
VOID
DDKAPI
NdisUnchainBuffeMCOL_CHARShareduct _N(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#elseCediaerD  ResnationOffseBOOLEAN  CachedNDISAPI
VOID
DDKAPI
NdisFreePacketlHandle,
  /*IN*/ PHYSICAL !__cplu      \
  \
  if (  D
DDKAPI
            DIS50_PROTOMCOL_CHARShareduct _NAsync(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#elseCediaerD  ResnationOffseBOOLEAN  CachedNDISAP NDIS40_PROT_HANDLER  T UINT  StatusBuffer

	    _BufferUpdxt,Shareduct _N(*IN*/  NDIS_HANDLCe BuffffffffffffffffffffffffffffffI
NdisFtLeeeeeeeeee Buffffffffffffffffffffffffffffff                eee Buffffffffffffffffffffffffffffff    \
  \
  if (
  NDISdle,
  /*IN*/ PVOID  Memorypdxt,Shareduct _N(  IS_STATUS  Status,
 DDDDDDDDDDDD*IN*/  NDIS_HANDLC   

#elseCediaerrrrrrffffffffffffI
NdisFDISAP NDIS40_PROTfffffffffffffffff               dress,
  /*IN*/PHYSICAL !__cplu       \
  \
  if (  DusHandler;T  StatusBufferScketvate.V!((_PacketPrivate   \
  \
  if High(ST     * VOIPHYSICAL !__cplu      \
  \
  if (    \
	    _Buffervate   \
  \
  if High(    \
  \
  if (= BuffPA   \
  \
  if (.HighPartletvate.ValidCounts =Sate   \
  \
  if High(ST     * VOIPHYSICAL !__cplu      \
  \
  if CS_FFER CediaerValuS_PACKET  Packet,
  Sate   \
  \
  if High(    \
  \
  if CrValuS_= BuffPA   \
  \
  if (.HighPartl    ValuS_etvate.V!((_PacketPrivate   \
  \
  if Low(ST     * VOIPHYSICAL !__cplu      \
  \
  if (    \
	    _Buffervate   \
  \
  if Low(    \
  \
  if (= BuffPA   \
  \
  if (.LowPartlettvate.ValidCounts =Sate   \
  \
  if Low(ST     * VOIPHYSICAL !__cplu      \
  \
  if CS_FFER CediaerValuS_PACKET  Packet,
  Sate   \
  \
  if Low(    \
  \
  if CrValuS_= BuffPA   \
  \
  if (.LowPartl    ValuS_etvate.V             PHYSICAL !__cpluxtBuScketOobOfCediaerDowCS_FFER ediaerHighN   \
	(Packet)->    PHYSICAL !__cpluxtBuSckDowCrHighNee Bufff{ {(Cedia)kDow), (edia)kHighN} }etvate.V!((_PacketPriEq   uct _N(       tBuSc DDKAPI
ERISTI1,       tBuSc DDKAPI
ERISTI2CS_FFER Cediaer);	        \
	    _BufferEq   uct _N(ERISTI1, ERISTI2C		  while BufRtlEq   uct _N(ERISTI1, ERISTI2C		  whilttvate.ValidCounts =Filluct _N(        ef strS;
#elif defin     Cediaer);	   fin     NDLER)(Fill     \
	    _BufferFilluct _N(S;
#elif defrI
NdisFtFill e BufRtlFilluct _N(S;
#elif defrI
NdisFtFill ttvate.ValidCounts =ZeroMappeduct _N(        ef strS;
#elif defin     Cediaer);	        \
	    _BufferZeroMappeduct _N(S;
#elif defrI
Ndis e BufRtlZeroMct _N(S;
#elif defrI
Ndis etvate.ValidCounts =MoveMct _N(    uffeer      S;
#elif defin      ef strERISTICS_FFER Cediaer);	        \
	    _BufferMoveMct _N(S;
#elif defrERISTIC		  while BufRtlS {
uct _N(S;
#elif defrERISTIC		  whilet       \
	NdisBuffeRetrieveUlong(        CediaerS;
#elif de\
  if CS_FFER  CediaerERISTI\
  if (    \
	    _BufferRetrieveUlong(S;
#elif de\
  if CrERISTI\
  if (e BufRtlRetrieveUlong(S;
#elif de\
  if CrERISTI\
  if (ettvate.ValidCounts =StoreUlong(        CediaerS;
#elif de\
  if CS_FFER CediaerValuS_P  \
	(Packet)->PriStoreUlong(S;
#elif de\
  if CrValuS_= BufRtlStoreUlong(S;
#elif de\
  if CrValuS_ettvate.ValidCounts =ZeroMct _N(        ef strS;
#elif defin     Cediaer);	       \
	    _BufferZeroMct _N(S;
#elif defrI
Ndis e BufRtlZeroMct _N(S;
#elif defrI
Ndis etnIVE_Configurif deoReceivePacketHandler; \
  CO_AF_REGISI
(*Configurif de(  rOfPacket  */ NDIS_HANDLE  PoolHandle,
  /IS50_PROTOCOL_CConfigurif de_HANDLC   

#else50_PROTOCOL_CWrapperConfigurif deadHandlDIS_HANDLE  PoolHandle,
  /*INadNetworkSAPI
VOID
DDK
  /*IN*/ NDIS_HANDLE  PoolHandle,
  /*DDKAPI
NetworkSAPI
VOmberOfPackets);

NDNetworkSAPI
VOI
NdisFDISAP NDIS50_PROTOCOL_CConfigurif de_HANDLDIS_HANDLE  PoolHandle,
  /*INadEisaSlot   pSizeMedER  WanSendCompleteHandler; \
  } DUMMYUNIONNAME2; \
  _WrapperConfigurif deadHandler; 

Packets);

NDSlot

NDISlHandle,
  /*IN*/ ENDL_FUNC    FFER RMA      Eisa    DIS_HANDLE  PoolHandle,
  /*INadEisaSlot   pSizeMedExER  WanSendCompleteHandler; \
  } DUMMYUNIONNAME2; \
  _WrapperConfigurif deadHandler; 

Packets);

NDSlot

NDISlHandle,
  /*IN*/ ENDL_FUNC    FFER RMA      *Eisa    mberOfPackets);

NDN
NDISAPFuncf de (  D
DDKAPI
oCopy,
  /*IN*/ PINadPciSlot   pSizeMedER  WaYUNIONNAME2; \
  _*IN*/  NDIS_HANDLC   

#elseCediaerSlot

NDISlHandl#elseCediaer _NDIS_PROTOCOL_C*DDKAPI          

#elseCediaer*IN*/ UINT  BytesToCopy ,
  /*IN*/ PWrit,PciSlot   pSizeMedER  WaYUNIONNAME2; \
  _*IN*/  NDIS_HANDLC   

#elseCediaerSlot

NDISlHandl#elseCediaer _NDIS_PROTOCOL_C*DDKAPI          

#elseCediaer*IN*/ UINTnIVE_String_HANDLER  CoReceivePacketHandler;            DIS50_PROTOCnsiStringToUnicodeString/ UINT  Offset,
  /*ICompleteHa
#elif deString  NDIS30_PROTOCOLANSIICompleteERISTIString);ttvate.VBOOLEANacketPriEq   String/ U

/*
 * VOICompleteEtring1,        * VOICompleteEtring2CS_FFER BOOLEAN  CaseInsensitivS_PACKET  Packet,
  Eq   String/_Etring1, _Etring2C _CaseInsensitivS_e BufRtlEq   UnicodeString/_Etring1, _Etring2C _CaseInsensitivS_ID
DDKAPI
NdisUnchainBuffeInitCnsiString/ UINT  Offset,
  /*IANSIICompleteHa
#elif deString  NDIS30_PROCComteERISTIString);tt
DDKAPI
NdisUnchainBuffeInitUnicodeString/ UINT  Offset,
  /*ICompleteHa
#elif deString  NDIS30_PROCWComteERISTIString);tt
DDKAPI
            DIS50_PROTOUnicodeStringToCnsiString/ UINT  Offset,
  /*IANSIICompleteHa
#elif deString  NDIS30_PRO* VOICompleteERISTIString);tt	    _BufferFreeString/_s  =ufferAtBuct _N(/_s .        /_s .MaximumI
NdisFt0)t	    _BufferPrintString/_s  DbgPrint("%ls"  /_s .*/ NDI)*/IVE_Spin UINT reeceivePacketvate.ValidCounts =COL_CHARSpinLo  {       O* VOICPIN_LOCK  SpinLo  _PACKET  Packet,
  COL_CHARSpinLo  {_SpinLo  _e BufKeIniti   zDSpinLo  {&{_SpinLo  _->SpinLo  _ttvate.ValidCounts =FreeSpinLo  {       O* VOICPIN_LOCK  SpinLo  _PACKET  Packet,
  FreeSpinLo  {_SpinLo  _ttvate.ValidCounts =AcquirRSpinLo  {       O* VOICPIN_LOCK  SpinLo  _PACKET  Packet,
  CcquirRSpinLo  {_SpinLo  _e BufKeCcquirRSpinLo  {&{_SpinLo  _->SpinLo  , &{_SpinLo  _->OldIrql ttvate.ValidCounts =ReleaseSpinLo  {       O* VOICPIN_LOCK  SpinLo  _PACKET  Packet,
  ReleaseSpinLo  {_SpinLo  _e BufKeReleaseSpinLo  {&{_SpinLo  _->SpinLo  , {_SpinLo  _->OldIrql ttvate.ValidCounts =tus,cquirRSpinLo  {       O* VOICPIN_LOCK  SpinLo  _PACKET  Packet,
  tus,cquirRSpinLo  {_SpinLo  _eeeeeeeeeeeeeeee     (Packet)->Private.ValidCounts   = TRUE;               BufffKeCcquirRSpinLo  AtDpcLevel{&{_SpinLo  _->SpinLo  _        {_SpinLo  _->OldIrql =  VOPATCH_LEVE* OUT PUINT  Buff            \
        _tusReleaseSpinLo  {       O* VOICPIN_LOCK  SpinLo  _PACKET  Packet,
  tusReleaseSpinLo  {_SpinLo  _e BufKeReleaseSpinLo  disGDpcLevel{&{_SpinLo  _->SpinLo  _NTnIVE_I/OoReceivePacketvate.ValidCounts =RawINadPort)->PriUcharketOobOfCediaerPortcalCount = DLER)(           ER Cediaer);	        \
	    _BufferRawINadPort)->PriUcharkPortc(       		  while (_ BufREAD_PORT         DLERNFO(
 * INPort), (O(
 * IN*/ NDI), (e       etvate.ValidCounts =RawINadPort)->PriUlong(       CediaerPortcalCount = ediaer           ER Cediaer);	        \
	    _BufferRawINadPort)->PriUlong(Portc(       		  while  BufREAD_PORT         ediaNFO(edia)kPort), (O(edia)k*/ NDI), (e       etvate.ValidCounts =RawINadPort)->PriUshort(       CediaerPortcalCount = SHORTer           ER Cediaer);	        \
	    _BufferRawINadPort)->PriUshort(Portc(       		  while BufREAD_PORT         SHORTNFO(SHORT)kPort), (O(SHORT)k*/ NDI), (e       ettvate.ValidCounts =RawINadPortUcharketOobOfCediaerPortcalCount = DLER)(    DIS  \
	    _BufferRawINadPortUcharkPortc(    De Buf*(    De=fREAD_PORT  DLERNFO(
 * INPort) etvate.ValidCounts =RawINadPortUlong(       CediaerPortcalCount = ediaer    DIS  \
	    _BufferRawINadPortUlong(Portc(    De Buf*(    De=fREAD_PORT  ediaNFO(edia)kPort) etvate.ValidCounts =RawINadPortUshort(       CediaerrPortcalCount = SHORTe    DIS  \
	    _BufferRawINadPortUshort(Portc(    De Buf*(    De=fREAD_PORT  SHORTNFO(SHORT)kPort) ettvate.ValidCounts =RawWrit,Port)->PriUcharketOobOfCediaerPortcalCo    CDLER)(           ER Cediaer);	        \
	    _BufferRawWrit,Port)->PriUcharkPortc(       		  while BufWRITE_PORT         DLERNFO(
 * INPort), (O(
 * IN*/ NDI), (e       etvate.ValidCounts =RawWrit,Port)->PriUlong(       CediaerPortcalCo    Cediaer           ER Cediaer);	        \
	    _BufferRawWrit,Port)->PriUlong(Portc(       		  while BufWRITE_PORT         ediaNFO(edia)kPort), (O(edia)k*/ NDI), (e       etvate.ValidCounts =RawWrit,Port)->PriUshort(       CediaerrPortcalCo    CSHORTe           ER Cediaerr);	        \
	    _BufferRawWrit,Port)->PriUshort(Portc(       		  while BufWRITE_PORT         SHORTNFO(SHORT)kPort), (O(SHORT)k*/ NDI), (e       ettvate.ValidCounts =RawWrit,PortUcharketOobOfCediaerPortcalCo    DLER)(    DIS  \
	    _BufferRawWrit,PortUcharkPortc(    De BufWRITE_PORT  DLERNFO(
 * INPort), ((
 * IN    D etvate.ValidCounts =RawWrit,PortUlong(       CediaerPortcalCo    ediaer    DIS  \
	    _BufferRawWrit,PortUlong(Portc(    De e BufWRITE_PORT  ediaNFO(edia)kPort), ((edia)k    D etvate.ValidCounts =RawWrit,PortUshort(       CediaerPortcalCo   CSHORTer    DIS  \
	    _BufferRawWrit,PortUshort(Portc(    De BufWRITE_PORT  SHORTNFO(SHORT)kPort), ((SHORT)k    D ettvate.ValidCounts =ReadRegistriUcharketOobOf CDLER)(RegistricalCount = DLER)(    DIS  \
	    _BufferReadRegistriUcharkRegistric(    De Buf*(    De=f*kRegistri ttvate.ValidCounts =ReadRegistriUlong(        CediaerRegistricalCount = ediaer    DIS  \
	    _BufferReadRegistriUlong(Registric(    De e Buf*(    De=f*kRegistri ttvate.ValidCounts =ReadRegistriUshort(       = SHORTerRegistricalCount = SHORTer    DIS  \
	    _BufferReadRegistriUshort(Registric(    De       *(    De=f*kRegistri ttvate.ValidCounts =ReadRegistriUcharketOobOf CDLER)(RegistricalCo    DLER)(    DIS  \
	    _BufferWrit,RegistriUcharkRegistric(    De BufWRITE_REGIST    DLERNFRegistri , (    D etvate.ValidCounts =ReadRegistriUlong(        CediaerRegistricalCo    ediaer    DIS  \
	    _BufferWrit,RegistriUlong(Registric(    De BufWRITE_REGIST    ediaNFRegistri , (    D etvate.ValidCounts =ReadRegistriUshort(       = SHORTerRegistricalCo   CSHORTer    DIS  \
	    _BufferWrit,RegistriUshort(Registric(    De BufWRITE_REGIST    SHORTNFRegistri , (    D etIVE_Linked listPacketvate.ValidCounts =Initi   zDList    (       =LIST_ENTRYrr)ist    DIS  \
	    _BufferIniti   zDList    (_)ist    De BufIniti   zDList    (_)ist    DROTOCOL_TLIST_ENTRYCounts =IntriUINTedInsert    )ist(       =LIST_ENTRYrr)ist    ,       =LIST_ENTRYrr)istEnt_NBufferAtO* VOICPIN_LOCK  SpinLo  _PACKET  Packet,
  IntriUINTedInsert    )ist(_)ist    uf_ListEnt_NB _SpinLo  _e BufExIntriUINTedInsert    )ist(_)ist    uf_ListEnt_NB &{_SpinLo  _->SpinLo  _ttvate.VTLIST_ENTRYCounts =IntriUINTedInsertIfer)ist(       =LIST_ENTRYrr)ist    ,       =LIST_ENTRYrr)istEnt_NBufferAtO* VOICPIN_LOCK  SpinLo  _PACKET  Packet,
  IntriUINTedInsertIfer)ist(_)ist    uf_ListEnt_NB _SpinLo  _e BufExIntriUINTedInsertIfer)ist(_)ist    uf_ListEnt_NB &{_SpinLo  _->SpinLo  _ttvate.VTLIST_ENTRYCounts =IntriUINTedRemove    )ist(       =LIST_ENTRYrr)ist    ,       =* VOICPIN_LOCK  SpinLo  _PAKET  Packet,
  IntriUINTedRemove    )ist(_)ist    uf_SpinLo  _e BufExIntriUINTedRemove    )ist(_)ist    uf&{_SpinLo  _->SpinLo  _ttvate.ValidCounts =Initi   zDSList    (       =SLIST_Packet  S)ist    DIS  \
	    _BufferIniti   zDSList    (S)ist    DfExIniti   zDSList    (S)ist    Detvate.V!SHORTeffer   \
DepthS)ist(       =SLIST_Packet  S)ist    DIS  \
	    _Buffer   \
DepthS)ist(S)ist    DfEx   \
DepthS)ist(S)ist    DNTnIVE_IntriUINTedoReceivePacketvate.V((_PacketPriIntriUINTedDecrER  C(       =LdiaerAddET_SET             PriIntriUINTedDecrER  C(AddET_S IntriUINTedDecrER  C(AddET_Setvate.V((_PacketPriIntriUINTedIncrER  C(       =LdiaerAddET_SET             PriIntriUINTedIncrER  C(AddET_S IntriUINTedIncrER  C(AddET_Sttvate.ValidCounts =IntriUINTedAddUlong(        CediaerAddET_calCo    ediaerIncrER  CBufferAtO* VOICPIN_LOCK  SpinLo  _PACKET  Packet,
  IntriUINTedAddUlong(_AddET_c _IncrER  CBf_SpinLo  _e BufExIntriUINTedAddUlong(_AddET_c _IncrER  CBf&{_SpinLo  _->SpinLo  _NTnIVE_MiscellaneousoReceivePacketHandler; \
  CO_AF_REGISCloseConfigurif de(  rOf NDIS50_PROTOCOL_CConfigurif de_HANDLDIS_HANDLE  PoolHandle,
  /*INadConfigurif de(  rOfPacket  */ NDIS_HANDLE  PoolHandle,
  /IS50_PRCONFIGURA    _PARAMET   (PParametriValuSFDISAP NDIS50_PROTOCOL_CConfigurif de_HANDL  NDIS30_PRO* VOICompleteKeywordFDISAP NDIS50_PRPARAMET  ->PridisCrametriTypLDIS_HANDLE  PoolHandle,
  /*Writ,Configurif de(  rOfPacket  */ NDIS_HANDLE  PoolHandlYUNIONNAME2; \
  _WrapperConfigurif deadHandler; 

30_PRO* VOICompleteKeywordFDISAP NDISS50_PRCONFIGURA    _PARAMET   (PParametriValuSDIS_HANDLE  PoolHandCDECLle,
  /*Writ,ErrorLogEnt_NER  WaYUNIONNAME2; \
  _*IN*/  NDIS_HANDLC   

#elseIN*/ ERRORRCOD  _ErrorCodLC   

#elseCediaerN
NDISAPErrorValuSolHandlYUNIO...);ttvate.ValidCounts =StallExecuf de(  ferAtFront(MicrosecondsToStall    \
	    _BufferStallExecuf deeKeStallExecuf deProcessor        \
	NdisBuffer->(Packet!= NUL)(_P(       =LARGE_ronEG   (p!= NUL)(_P(    \
	    _Buffervat(Packet!= NUL)(_PeKe   \
!= NUL)(_PS_HANDLE  PoolHandle,
  /*vat(PacketProcessorCpuUsageER  WanSendCoCediaerpCpuUsageUINTnIVE_HAND helper macrosacketvate.ValidCountN*/ INIT_FUNC    (Funcf deName    \
	    _BufN*/ INIT_FUNC    (Funcf deName e (_ BufaOL_C_andl(init, Funcf deName  tvate.V             PAGABLE_FUNC    (Funcf deName e   \
	    _BufN*/ PackABLE_FUNC    (Funcf deName e BufaOL_C_andl(page, Funcf deName  t	    _BufN*/ PacABLE_FUNC    ufN*/ PackABLE_FUNC    TnIVE_HAND 4.0 ndlensionPacketHandler; \
  CO_AF_REGISMFreeShareduct _N(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#elseCediaerD  ResnationOffseBOOLEAN  CachedNDISAP NDIS40_PROTOCOL_CHARACTERISTICS_S \
IN*/ PHYSICAL !__cplu      \
  \
  if (  D
DDKAPI
 \
  CO_AF_REGISMWanIndic tPacket) ER  WanSendCompleteHandler; \
  } DUMMYUNIONNAME2; \
  _Liniport*/ NDIS_HANDLCS_ 

#elseNNAME2; \
  _*IN*LinkadHandler; 

30_PRO DLER)(ags &           

#elseC      gs & NDIS_PAD
DDKAPI
 \
  CO_AF_REGISMWanIndic tPacket) Completr(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDL_PAD
DDKAPI
 \
  CO_AF_REGISMWanKET_Completr(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLFDISAP NDISS50_PRWtalPa * NdisChainBufIS_STATUS  SteHandler; \
  );tt
DDKAPI
            DIS50_PROTOPciAssignResRISTIsER  WaYUNIONNAME2; \
  _*IN*Mac_HANDLCS_ 

#elseNNAME2; \
  _*IN*Wrapper_HANDLC   

#else50_PROTOCOL_CWrapperConfigurif deadHandlC   

#elseCediaerSlot

NDISlHandlnSendCompletcplOURCE_LIST (PAssignedResRISTIsN Oont(_HAND 5.0 ndlensionPacketHandler; \
  CO_AF_REGISCcquirRINadWrit,Lo  {  SAP NDISS50_PRRW_LOCK  Lo  ,ationOffseBOOLEAN  fWrit,FDISAP NDISSLOCK     E  Lo  ; \
e);tt
DDKAPI
            DIS50_PROTOCOL_CHARuct _NWithTagER  WanSendCo                     nationOffset,
  /*IN*/ nationOffsetSpec  )ag);tt
DDKAPI
NdisUnchainBuffeCOL_CHARsChainPoolExER  WanSendCompleteHandler; \
  } DUMMnSendCompletOTOCOL_CPool_HANDLCS_ 

#elseC;

NDN
NDISAPDescriptor nationOffset,
  /N
NDISAPOverflowDescriptor nationOffset,
  /ProtocolReservedISAPI
VOID
DDKAPI
NdisUnchainBuffeCompletrPnPEv  C(  IS_STATUS  SteHandler; \
  CS_ 

#elseNNAME2; \
  _*IN*Binding_HANDLFDISAP NDISS5ivatNP_EVE

NDNetPnPEv  CVOID
DDKAPI
NdisUnchainBuffevat(PacketProcessorChysic    WanSendCoCediaerpINDLacket)   WanSendCoCediaerpKernelAndUsISlHandlnSendCoCediaerpIndexVOID
DDKAPI
NdisUnchainBuffevatDrt) r_HANDL{  SAP NDISS50_PR2; \
  _*IN*Binding_HANDLFDISAPnSendCompletOTOCOL_C,
  trt) r_HANDLVOID
DDKAPI
 * VOID
 * NUnchainBuffevatacket) +IS_HANDLESAP NDISS50_PR2; \
  _*IN*Binding_HANDLFDISAP NDISS50_PR2; \
  _MacadHandlDIS_HANDLE  PoolHandle,
  /*vat!= NULUpt(_P(  ndlnSendCoCediaerp!= NULUp)(_P(  t
DDKAPI
NdisUnchainBuffeIniti   zDINadWrit,Lo  {  SAP NDISS50_PRRW_LOCK  Lo  (  D
DDKAPI
            DIS50_PROTOMDeregistriDevicr(  IS_STATUS  Status,
 D,
  tevicr_HANDL_PAD
DDKAPI
 \
  CO_AF_REGISMvatDevicrPropertN(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#eOffset,
DEVICE_OBJECT (P    \
  DevicrObject ndln       */CS_ 

#eOffset,
DEVICE_OBJECT (PFuncf de  DevicrObject ndln       */CS_ 

#eOffset,
DEVICE_OBJECT (P _FiDevicrObject ndln       */CS_ 

#eOffset,
CMtcplOURCE_LIST (PAOL_CHARdResRISTIs ndln       */CS_ 

#eOffset,
CMtcplOURCE_LIST (PAOL_CHARdResRISTIsTransl*OUd ndln       */(  D
DDKAPI
            DIS50_PROTOMIniti   zDSCHADISGathriDma(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLFDISAP NDISBOOLEAN  Dma64Bit       SolHandlYUNIOCediaerMaximum    \
  Mapping);tt
DDKAPI
            DIS50_PROTOMPromoARuiniport(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDL_PAD
DDKAPI
            DIS50_PROTOM   \
*/ NDISInstanceNameER  WanSendCompleteHmplete*/ NDISInstanceName} DUMMYUNIONNAME2; \
  _Liniport*/ NDIS_HANDL_PAD
DDKAPI
            DIS50_PROTOMRegistriDevicr(  IS_STATUS  Status,
 D,
  Wrapper_HANDLC   

#else
  /*ICompleteHavicrName} DUMMYUNIOO* VOICompleteEymbolicName} DUMMYUNIOODRIVER_ VOPATCHerMajorFuncf de []FDISAPnSendCoDEVICE_OBJECT (PpDevicrObjectFDISAPnSendCS  Status,
 D*,
  tevicr_HANDL_PAD
DDKAPI
 \
  CO_AF_REGISMRegistriUnload_HANDLr(  IS_STATUS  Status,
 D,
  Wrapper_HANDLC   

#else
DRIVER_UNLOA   Unload_HANDLr_PAD
DDKAPI
            DIS50_PROTOMRemoveuiniport(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDL_PAD
DDKAPI
            DIS50_PROTOMSetLiniportSeconda_N(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#elsempletOTOCOL_CPrima_NLiniport*/ NDIS_HANDL_PAD
DDKAPI
 \
  CO_AF_REGISI
(*Configurif deKeyByIndexER  WanSendCompleteHandler; \
  } DUMMYUNIONNAME2; \
  _Configurif de_HANDL  NDIS30_PR ediaerIndexFDISAPnSendCompletCompleteKeyName} DUMMnSendCompletOTOCOL_CKey_HANDL_PAD
DDKAPI
 \
  CO_AF_REGISI
(*Configurif deKeyByNameER  WanSendCompleteHandler; \
  } DUMMYUNIONNAME2; \
  _Configurif de_HANDL  NDIS30_PRO* VOICompleteEubKeyName} DUMMnSendCompletOTOCOL_CEubKey_HANDL_PAD
DDKAPI
t,
  DIS50_PROTOPChainPoolUsageER  Wa#elsempletOTOCOL_CPool_HANDL_PAD
DDKAPI
            DIS50_PROTO   \
*/ NDISInstanceNameER  WanSendCompleteHmplete*/ NDISInstanceName} DUMMYUNIONNAME2; \
  _*IN*Binding_HANDL(  D
DDKAPI
oCopy,
  /*IN*/ PINadPcmciaAttributBuct _N(  rOf NDISNNAME2; \
  _*IN*/  NDIS_HANDLC   

#elseCediaer _NDIS_PROTOCOL_C*DDKAPI          

#elseCediaer*IN*/ UINT  BytesTPoolHandle,
  /*INleaseINadWrit,Lo  {  SAP NDISS50_PRRW_LOCK  Lo  ,ationOffseSLOCK     E  Lo  ; \
e);tt
DDKAPI
            DIS50_PROTOWrit,Ev  CLogEnt_NER  WaYUNIO*DDKAPILog_HANDLCS_ 

#elsempleteHandlerEv  CCodLC   

#elseCediaerUniqu,Ev  CValuSFDISAP NDISCSHORTerN
NStrings_PROTOCOL_C*DDKAPIStrings)ist ndln       */CS_ 

#elseCediaer    NDIS_PROTOCOL_C*DDKAPI     ndln       */(  D
DDKAPI
oCopy,
  /*IN*/ PWrit,PcmciaAttributBuct _N(  rOf NDISNNAME2; \
  _*IN*/  NDIS_HANDLC   

#elseCediaer _NDIS_PROTOCOL_C*DDKAPI          

#elseCediaer*IN*/ UINTIVE_Connecf del    servicePacketHandler;            DIS50_PROTOC    PartN(  rOf NDISNNAME2; \
  _*IN*Vc_HANDLCS_ 

#elseNNAME2; \
  _ProtocolPartNadHandlC   

#eOffset,
CO_CALL_PARAMET  S  CallParametri } DUMMnSendCompletOTOCOL_CROTOPCrtN_HANDL_PAD
DDKAPI
            DIS50_PROTOClClose       FamilN(  rOf NDISNNAME2; \
  _*IN*/f_HANDL_PAD
DDKAPI
            DIS50_PROTOClCloseCall(  rOf NDISNNAME2; \
  *IN*Vc_HANDLCS_ 

#elseNNAME2; \
  ROTOPCrtN_HANDL ndln       */CS_ 

#else*DDKAPI       ndln       */CS_ 

#elseCALL_COMPL_PAD
DDKAPI
            DIS50_PROTOClDeregistriSap(  rOf NDISNNAME2; \
  _*IN*Sap_HANDL_PAD
DDKAPI
            DIS50_PROTOClDropPartN(  rOf NDISNNAME2; \
  _*IN*PCrtN_HANDLCS_ 

#else*DDKAPI       ndln       */CS_ 

#elseCALL_COMPL_PAD
DDKAPI
 \
  CO_AF_REGISClIncomingCallCompletr(  IS_STATUS  SteHandler; \
  CS_ 

#elseNNAME2; \
  _*IN*Vc_HANDLCS_ 

#else
CO_CALL_PARAMET  S  CallParametri _PAD
DDKAPI
            DIS50_PROTOClMakeCall(  rOf NDISNNAME2; \
  _*IN*Vc_HANDLCS_ 

#eOffset,
CO_CALL_PARAMET  S  CallParametri } DUMM#elseNNAME2; \
  _ProtocolPartNadHandl ndln       */CS_ 

nSendCompletOTOCOL_CROTOPCrtN_HANDL ndln       */(  D
DDKAPI
             DIS50_PROTOClModifyCallQoS(  rOf NDISNNAME2; \
  _*IN*Vc_HANDLCS_ 

#else
CO_CALL_PARAMET  S  CallParametri _PADD
DDKAPI
            DIS50_PROTOClI
(*       FamilN(  rOf NDISNNAME2; \
  _*IN*Binding_HANDLFDISAP NDISSCO_!__cpluxFAMILYerAdd    FamilN} DUMM#elseNNAME2; \
  _ProtocolAfadHandler; 

30_PRO* VOICLIENT_DLERACT  ISTICS  ClCharactriistic nationOffset,
  /OMPLOfClCharactriistic nationnSendCompletOTOCOL_CROTO/f_HANDL_PAD
DDKAPI
            DIS50_PROTOClRegistriSap(  rOf NDISNNAME2; \
  _*IN*/f_HANDL} DUMM#elseNNAME2; \
  _ProtocolSapadHandler; 

30_PROCO_KAP /OapnationnSendCompletOTOCOL_CROTOSap_HANDL_PADIVE_CallrMaNDLEr servicePacketHandler;            DIS50_PROTOCmAcf T_ALVc(  IS_STATUS  Status,
 D*IN*Vc_HANDLCS_ 

#eOffset,
CO_CALL_PARAMET  S  CallParametri _PAD
DDKAPI
 \
  CO_AF_REGISCm   PartNCompletr(  IS_STATUS  SteHandler; \
  CS_ 

#elseNNAME2; \
  _*IN*PCrtN_HANDLCS_ 

#elseNNAME2; \
  _CallMgrPartNadHandl ndln       */CS_ 

#else
CO_CALL_PARAMET  S  CallParametri _PAD
DDKAPI
 \
  CO_AF_REGISCmClose       FamilNCompletr(  IS_STATUS  SteHandle; \
  CS_ 

#elseNNAME2; \
  ROTO/f_HANDL_PAD
DDKAPI
 \
  CO_AF_REGISCmCloseCallCompletr(  IS_STATUS  SteHandler; \
  CS_ 

#elseNNAME2; \
  _*IN*Vc_HANDLCS_ 

#elsempletOTOCOL_CROTOPCrtN_HANDL ndln       */(  D
DDKAPI
            CO_AF_REGISCmDeacf T_ALVc(  IS_STATUS  Status,
 D*IN*Vc_HANDL_PAD
DDKAPI
 \
  CO_AF_REGISCmDeregistriSapCompletr(  IS_STATUS  SteHandler; \
  CS_ 

#elseNNAME2; \
  _*IN*Sap_HANDL_PAD
DDKAPI
 \
  CO_AF_REGISCmDispatchCallConnecfed(  IS_STATUS  Status,
 D*IN*Vc_HANDL_PAD
DDKAPI
            CO_AF_REGISCmDispatchIncomingCall(  rOf NDISNNAME2; \
  _*IN*Sap_HANDLCS_ 

#elseNNAME2; \
  _*IN*Vc_HANDLCS_ 

#else
CO_CALL_PARAMET  S  CallParametri _PAD
DDKAPI
 \
  CO_AF_REGISCmDispatchIncomingCallQoSChangeER  Wa#elsempletOTOCOL_C*IN*Vc_HANDLCS_ 

#else
CO_CALL_PARAMET  S  CallParametri _PAD
DDKAPI
 \
  CO_AF_REGISCmDispatchIncomingCloseCall(  rOf NDISNNAMEeHandlerClose; \
  CS_ 

#elseNNAME2; \
  _*IN*Vc_HANDLCS_ 

#else
DDKAPI       ndln       */CS_ 

#elseCALL_COMPL_PAD
DDKAPI
 \
  CO_AF_REGISCmDispatchIncomingDropPartN(  rOf NDISNNAMEeHandlerDrop; \
  CS_ 

#elseNNAME2; \
  _*IN*PCrtN_HANDLCS_ 

#else
DDKAPI       ndln       */CS_ 

#elseCALL_COMPL_PAD
DDKAPI
 \
  CO_AF_REGISCmDropPartNCompletr(  IS_STATUS  SteHandler; \
  CS_ 

#elseNNAME2; \
  _*IN*PCrtN_HANDL_PAD
DDKAPI
 \
  CO_AF_REGISCmMakeCallCompletr(  IS_STATUS  SteHandler; \
  CS_ 

#elseNNAME2; \
  _*IN*Vc_HANDLCS_ 

#elsempletOTOCOL_CROTOPCrtN_HANDL ndln       */CS_ 

#elseNNAME2; \
  _CallMgrPartNadHandl ndln       */CS_ 

#else
CO_CALL_PARAMET  S  CallParametri _PAD
DDKAPI
 \
  CO_AF_REGISCmModifyCallQoSCompletr(  IS_STATUS  SteHandler; \
  CS_ 

#elseNNAME2; \
  _*IN*Vc_HANDLCS_ 

#else
CO_CALL_PARAMET  S  CallParametri _PAD
DDKAPI
 \
  CO_AF_REGISCmI
(*       FamilNCompletr(  IS_STATUS  SteHandle; \
  CS_ 

#elseNNAME2; \
  ROTO/f_HANDLCS_ 

#elseNNAME2; \
  CallMgrAfadHandl_PAD
DDKAPI
            CO_AF_REGISCmRegistri       FamilN(  rOf NDISNNAME2; \
  _*IN*Binding_HANDLFDISAP NDISSCO_!__cpluxFAMILYerAdd    FamilN} DUMM#elseO* VOICALL_MANAGER_DLERACT  ISTICS  CmCharactriistic nationOffset,
  /OMPLOfCmCharactriistic _PAD
DDKAPI
 \
  CO_AF_REGISCmRegistriSapCompletr(  IS_STATUS  SteHandler; \
  CS_ 

#elseNNAME2; \
  _*IN*Sap_HANDLCS_ 

#elseNNAME2; \
  _CallMgrSapadHandl_PADD
DDKAPI
            DIS50_PROTOMCmAcf T_ALVc(  IS_STATUS  Status,
 D*IN*Vc_HANDLCS_ 

#else
CO_CALL_PARAMET  S  CallParametri _PAD
DDKAPI
            DIS50_PROTOMCmetext,Vc(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#elseNNAME2; \
  _*IN*/f_HANDL} DUMM#elseNNAME2; \
  _LiniportVcadHandler; 

PacketCompletOTOCOL_CROTOVc_HANDL_PAD
DDKAPI
            CO_AF_REGISMCmDeacf T_ALVc(  IS_STATUS  Status,
 D*IN*Vc_HANDL_PAD
DDKAPI
            CO_AF_REGISMCmDeletrVc(  IS_STATUS  Status,
 D*IN*Vc_HANDL_PAD
DDKAPI
            CO_AF_REGISMCmRegistri       FamilN(  rOf NDISNNAME2; \
  _Liniport*/ NDIS_HANDLFDISAP NDISSCO_!__cpluxFAMILYerAdd    FamilN} DUMM#elseO* VOICALL_MANAGER_DLERACT  ISTICS  CmCharactriistic nationOffset,
  /OMPLOfCmCharactriistic _PAD
DDKAPI
            CO_AF_REGISMCmRequest(  IS_STATUS  Status,
 D*IN*/f_HANDL} DUMM#elseNNAME2; \
  _*IN*Vc_HANDL ndln       */CS_ 

#elseNNAME2; \
  _ROTOPCrtN_HANDL ndln       */CS_ 

#e PacketCompletREQUEST (  /*INquestUINTIVE_Connecf de-orienOUd servicePacketHandler;            DIS50_PROTOCoetext,Vc(  IS_STATUS  Status,
 D*IN*Binding_HANDLFDISAP NDISS  Status,
 D*IN*/f_HANDL ndln       */CS_ 

#elseNNAME2; \
  _ProtocolVcadHandler; 

  Offset,
  /*Iatus,
 D*IN*Vc_HANDL_PAD
DDKAPI
            CO_AF_REGISCoDeletrVc(  IS_STATUS  Status,
 D*IN*Vc_HANDL_PAD
DDKAPI
            CO_AF_REGISCoRequest(  IS_STATUS  Status,
 D*IN*Binding_HANDLFDISAP NDISS  Status,
 D*IN*/f_HANDL ndln       */CS_ 

#elseNNAME2; \
  _*IN*Vc_HANDL ndln       */CS_ 

#elseNNAME2; \
  _ROTOPCrtN_HANDL ndln       */CS_ 

#e PacketCompletREQUEST (  /*INquestUINT
DDKAPI
 \
  CO_AF_REGISCoRequestCompletr(  IS_STATUS  SteHandler; \
  CS_ 

#elseNNAME2; \
  _*IN*/f_HANDL} DUMM#elseNNAME2; \
  _*IN*Vc_HANDL ndln       */CS_ 

#elseNNAME2; \
  _ROTOPCrtN_HANDL ndln       */CS_ 

#eDISS50_PRREQUEST (  /*INquestUINT
DDKAPI
 \
  CO_AF_REGISCoKET_PChainsER  WaYUNIONNAME2; \
  _*IN*Vc_HANDLCS_ 

#else
 * VOID
 * NdisChainArraynationOffset,
  /N
NDISAPPChains_PAD
DDKAPI
 \
  CO_AF_REGISMCoAcf T_ALVcCompletr(  IS_STATUS  SteHandler; \
  CS_ 

#elseNNAME2; \
  _*IN*Vc_HANDLCS_ 

#else
CO_CALL_PARAMET  S  CallParametri _PAD
DDKAPI
 \
  CO_AF_REGISMCoDeacf T_ALVcCompletr(  IS_STATUS  SteHandler; \
  CS_ 

#elseNNAME2; \
  _*IN*Vc_HANDL_PAD
DDKAPI
 \
  CO_AF_REGISMCoIndic tPacket) IS_HANDLESAP NDISNNAME2; \
  _*IN*Vc_HANDLCS_ 

#else
 * VOID
 * NdisChainArraynationOffset,
  /N
NDISAPPChains_PAD
DDKAPI
 \
  CO_AF_REGISMCoIndic tP; \
  (  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#elseNNAME2; \
  _*IN*Vc_HANDL ndln       */CS_ 

#elseNNAMEeHandlerGener  St\
  CS_ 

#else*DDKAPISt\
         ndln       */CS_ 

#elseCediaerSt\
        NDIS_PAD
DDKAPI
 \
  CO_AF_REGISMCoReket) Completr(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDL_PAD
DDKAPI
 \
  CO_AF_REGISMCoRequestCompletr(  IS_STATUS  SteHandler; \
  CS_ 

#elseNNAME2; \
  _Liniport*/ NDIS_HANDLFDISAP NDISS50_PRREQUEST (INquestUINT
DDKAPI
 \
   CO_AF_REGISMCoKET_Completr(  IS_STATUS  SteHandler; \
  CS_ 

#elseNNAME2; \
  _*IN*Vc_HANDLCS_ 

#else
* VOID
 * NdisChainN Oont(_HAND 5.0 ndlensionPafor intrim;   tP drt) rPacketHandler; \
  CO_AF_REGISIMAssoc  tPuiniport(  IS_STATUS  Status,
 Dtrt) r_HANDLCS_ 

#elseNNAME2; \
  _Protocol_HANDL_PAD
DDKAPI
             CO_AF_REGISIMCancelIniti   zDtevicrInstance(  IS_STATUS  Status,
 Dtrt) r_HANDLCS_ 

#else
  /*ICompleteHavicrInstance(  t
DDKAPI
NdisUnchainBuffeIMS {
KET_CompletrPersChain   p{  SAP NDISS50_PRD
 * NdiDstsChainBufIS_STATUS50_PRD
 * NdiSrcsChainN Oo
DDKAPI
NdisUnchainBuffeIMS {
KET_PersChain   p{  SAP NDISS50_PRD
 * NdiDstsChainBufIS_STATUS50_PRD
 * NdiSrcsChainN Oo
DDKAPI
NdisUnchainBuffeIMDeregistriLayereduiniport(  IS_STATUS  Status,
 Dtrt) r_HANDL_PAD
DDKAPI
     atus,
UnchainBuffeIMGetBindingadHandl(  IS_STATUS  Status,
 D*IN*Binding_HANDL_PAD
DDKAPI
     atus,
UnchainBuffeIMGetHavicradHandl(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDL_PAD
DDKAPI
            DIS50_PROTOIMIniti   zDtevicrInstanceExER  WaSTATUS  Status,
 Dtrt) r_HANDLCS_ 

#else
  /*ICompleteHrt) rInstanceCS_ 

#elseNNAME2; \
  _HavicradHandl ndln       */(  D
DDKAPI
PSpleLE_LIST_ENTRYCnchainBuffeIntriUINTedPopEnt_NS)ist(   

#else
SLIST_Packet  )ist    ,   

#else
KCPIN_LOCK  Lo  (  D
DDKAPI
PSpleLE_LIST_ENTRYCnchainBuffeIntriUINTedPushEnt_NS)ist(   

#else
SLIST_Packet  )ist    ,   

#else
SpleLE_LIST_ENTRYrr)istEnt_NBuf 

#else
KCPIN_LOCK  Lo  (  D
DDKAPI
NdisUnchainBuffe   \
      NafL{  SAP NDISS50_PR      PI          

nSendCo                      ndln       */CS_ 

Packets);

NDD  ResnationOffset,
  /PriorityN Oont(_PrototypePafor 50_PRMINIPORT DLERACT  ISTICS ckettypedefSBOOLEAN nchainB(*W DLECK_FORE2; GE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDISadHandl_PADtypedefS     nchainB(*W DDKABLE_ronERRUPTE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDISadHandl_PADtypedefS     nchainB(*W ENABLE_ronERRUPTE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDISadHandl_PADtypedefS     nchainB(*W HALTE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDISadHandl_PADtypedefS     nchainB(*W HAus,
_ronERRUPTE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDISadHandl_PADtypedefS            nchainB(*W INITIALIZEE2; \
 R)(  IS_nSendCompleteHandlerI
(*Error; \
  } DUMMnSendCot,
  /Oelecfed);  umIndexFDISAP NDISS50_PRMEDIUM /uc  umArraynationOffset,
  /uc  umArrayNDIS_PROTOCOL_CS  Status,
 DLiniport*/ NDISadHandl_PROTOCOL_CS  Status,
 DWrapperConfigurif deadHandlDIS_typedefS     nchainB(*W ISRE2; \
 R)(  IS_nSendCoBOOLEAN  IntriruptackognDISdNDISAPI
VOID
BOOLEAN     uPuiniport_HANDLIntrirupt_PROTOCOL_CS  Status,
 DLiniport*/ NDISadHandl(   DtypedefS            nchainB(*W QUERYFFER RMA    E2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDISadHandl_PROTOCOL_CS  St     OidNDISAP NDIS40_PROT   pSizeMed          

#elseCediaer   pSizeMed      D  ResnationnSendCoCediaerBytePWritlennationnSendCoCediaerBytePNeeded_PADtypedefS            nchainB(*W RECONFIGUREE2; \
 R)(  IS_nSendCompleteHandlerI
(*Error; \
  } DUMMCOL_CS  Status,
 DLiniport*/ NDISadHandl_PROTOCOL_CS  Status,
	WrapperConfigurif deadHandlDIS_typedefS            nchainB(*W RESiva2; \
 R)(  IS_nSendCoBOOLEAN         ingReset_PROTOCOL_CS  Status,
 DLiniport*/ NDISadHandl(  _typedefS            nchainB(*W     E2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDISadHandl_PROTOCOL_C * VOID
 * NdisChainBufionOffset,
  /ferAt(  DtypedefS            nchainB(*WM     E2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDISadHandl_PROTOCOL_CS  Status,
 D*IN*Link_HANDLFDISAP NDISS50_PRWtalPa * NdisChain(  _typedefS            nchainB(*W   TFFER RMA    E2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDISadHandl_PROTOCOL_CS  St     OidNDISAP NDIS40_PROT   pSizeMed          

#elseCediaer   pSizeMed      D  ResnationnSendCoCediaerBytePR   ,   

nSendCoCediaerBytePNeeded_PADtypedefS            nchainB(*W TRANS    DATAE2; \
 R)(  IS_nSendCompletD
 * NdisChainBufionnSendCot,
  /BytePTrans   redFDISAP NDIS50_PRatus,
 DLiniport*/ NDISadHandl_PROTOCOL_CS  Status,
 DLiniportReket) CoHandlC   

#elseC,
  /Byte _NDIS_PROTOCOL_Ct,
  /BytePToTrans   (  DtypedefS            nchainB(*WM TRANS    DATAE2; \
 R)(  I0_PRN Oont(_HAND structu    available only to miniport drt) rPacket	    _BufN*/30RMINIPORT DLERACT  ISTICS_Se Buf DLER)(Major*IN*V rPMed;e Buf DLER)(Minor*IN*V rPMed;e Buf ,
  /Reserved;e BufW DLECK_FORE2; GE2; \
 R  CheckFor_HAg_HANDLr;e BufW DDKABLE_ronERRUPTE2; \
 R _HisableIntrirupt_HANDLr;e BufW ENABLE_ronERRUPTE2; \
 R  EnableIntrirupt_HANDLr;e BufW HALTE2; \
 R  Halt_HANDLr;e BufW HAus,
_ronERRUPTE2; \
 R  HaANDLIntrirupt_HANDLr;e BufW INITIALIZEE2; \
 RufIniti   zD_HANDLr;e BufW ISRE2; \
 RufISR_HANDLr;e BufW QUERYFFER RMA    E2; \
 R     ry   pSizeMed_HANDLr;e BufW RECONFIGUREE2; \
 R /ReconfigurD_HANDLr;e BufW RESiva2; \
 R /Reset_HANDLr;e Buf_ANONYMOUS_UN   uun dee{       W     E2; \
 R /Oend_HANDLr;e Buf  WM     E2; \
 R /WanKET__HANDLr;e Buf} _UN   _NAME(u1);e BufW   TFFER RMA    E2; \
 R /Oet   pSizeMed_HANDLr;e Buf_ANONYMOUS_UN   uun dee{       W TRANS    DATAE2; \
 R  Trans       _HANDLr;e Buf  WM TRANS    DATAE2; \
 R  WanTrans       _HANDLr;e Buf} _UN   _NAME(u2(  DtypedefSstruct _fN*/30RMINIPORT DLERACT  ISTICS {BuffN*/30RMINIPORT DLERACT  ISTICS_S
}ffN*/30RMINIPORT DLERACT  ISTICS, *PSfN*/30RMINIPORT DLERACT  ISTICS Oont(_EdlensionPafor HAND 4.0 miniports ckettypedefS     nchainB(*W     ED
 * NSE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDISadHandl_PROTOCOL_C  * VOID
 * NdisChainArraynationOffset,
  /N
NDISAPPChains_PADtypedefS     nchainB(*W RETURalPa * NE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDISadHandl_PROTOCOL_C * VOID
 * NdisChain_PADtypedefS     nchainB(*W ALLOCATE_COMPLETEE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDISadHandl_PROTOCOL_C 0_PROTOCOL_CHARACTERISTICS_S \
*IN*/ PHYSICAL !__cplu      \
  \
  if     

#elseCediaerI
NdisFDISAP NDIS40_PROT_HANDLER  T UIdefS__cpluspluset	    _BufN*/40RMINIPORT DLERACT  ISTICS_Se BuffN*/30RMINIPORT DLERACT  ISTICS D*IN*30Chars;e BufW RETURalPa * NE2; \
 R /Retu nsChain_HANDLr;e BufW     ED
 * NSE2; \
 R /OendPChains_HANDLr;e BufW ALLOCATE_COMPLETEE2; \
 R   OL_CHARCompletr_HANDLr;
  NDISSAP !__cplusplusacket	    _BufN*/40RMINIPORT DLERACT  ISTICS_Se BuffN*/30RMINIPORT DLERACT  ISTICS_Se BufW RETURalPa * NE2; \
 R /Retu nsChain_HANDLr;e BufW     ED
 * NSE2; \
 R /OendPChains_HANDLr;e BufW ALLOCATE_COMPLETEE2; \
 R   OL_CHARCompletr_HANDLr;
  Nnandler;!__cplusplusackettypedefSstruct _fN*/40RMINIPORT DLERACT  ISTICS {BuffN*/40RMINIPORT DLERACT  ISTICS_S
}ffN*/40RMINIPORT DLERACT  ISTICS, *PfN*/40RMINIPORT DLERACT  ISTICS Oont(_EdlensionPafor HAND 5.0 miniports ckettypedefS            nchainB(*W CO_CREATE_VCE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDISadHandl_PROTOCOL_CS  Status,
 D*IN*Vc_HANDLCS_ 

ffset,
  /*Iatus,
 DLiniportVcadHandl_PADtypedefS            nchainB(*W CO_DELETEEVCE2; \
 R)(  IS_STATUS  Status,
 DLiniportVcadHandl_PADtypedefS            nchainB(*W CO_ACTIVATE_VCE2; \
 R)(  IS_STATUS  Status,
 DLiniportVcadHandler; 

  Offset,
CO_CALL_PARAMET  S  CallParametri _PADtypedefS            nchainB(*W CO_DEACTIVATE_VCE2; \
 R)(  IS_STATUS  Status,
 DLiniportVcadHandl_PADtypedefS     nchainB(*W CO_K   ED
 * NSE2; \
 R)(  IS_STATUS  Status,
 DLiniportVcadHandler; 

  L_C  * VOID
 * NdisChainArraynationOffset,
  /N
NDISAPPChains_PADtypedefS            nchainB(*W CO_REQUESTE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDISadHandl_PROTOCOL_CS  Status,
 DLiniportVcadHandl ndln       */CS_ 

#e PacketS50_PRREQUEST (  /*INquestUINT UIdefS__cpluspluset	    _BufN*/50RMINIPORT DLERACT  ISTICS_Se BuffN*/40RMINIPORT DLERACT  ISTICS (  /*40Chars;e BufW CO_CREATE_VCE2; \
 ROT_Hetext,Vc_HANDLr;e BufW CO_DELETEEVCE2; \
 ROT_HDeletrVc_HANDLr;e BufW CO_ACTIVATE_VCE2; \
 ROT_HAcf T_ALVc_HANDLr;e BufW CO_DEACTIVATE_VCE2; \
 ROT_HDeacf T_ALVc_HANDLr;e BufW CO_    ED
 * NSE2; \
 R /CoKET_PChains_HANDLr;e BufW CO_REQUESTE2; \
 R /CoINquest_HANDLr;
  NDISSAP !__cplusplusacket	    _BufN*/50RMINIPORT DLERACT  ISTICS_Se BuffN*/40RMINIPORT DLERACT  ISTICS_Se BufW CO_CREATE_VCE2; \
 ROT_Hetext,Vc_HANDLr;e BufW CO_DELETEEVCE2; \
 ROT_HDeletrVc_HANDLr;e BufW CO_ACTIVATE_VCE2; \
 ROT_HAcf T_ALVc_HANDLr;e BufW CO_DEACTIVATE_VCE2; \
 ROT_HDeacf T_ALVc_HANDLr;e BufW CO_    ED
 * NSE2; \
 R /CoKET_PChains_HANDLr;e BufW CO_REQUESTE2; \
 R /CoINquest_HANDLr;
  Nnandler;!__cplusplusackettypedefSstruct _fN*/50RMINIPORT DLERACT  ISTICS {BufufN*/50RMINIPORT DLERACT  ISTICS_S
}ffN*/50RMINIPORT DLERACT  ISTICS, *PSfN*/50RMINIPORT DLERACT  ISTICS Oont(_EdlensionPafor HAND 5.1 miniports ckettypedefS     nchainB(*W CANCEL     ED
 * NSE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDISadHandl_PROTOCOL_C 0_PROT_ancelId_PADT UI     _Bd(fN*/51)ttypedefSstruct _fN*/RMINIPORT DLERACT  ISTICS {BuffN*/50RMINIPORT DLERACT  ISTICS_S
}ffN*/RMINIPORT DLERACT  ISTICS, *PfN*/RMINIPORT DLERACT  ISTICS O NDUI     _Bd(fN*/50)ttypedefSstruct _fN*/RMINIPORT DLERACT  ISTICS {BuffN*/50RMINIPORT DLERACT  ISTICS_S
}ffN*/RMINIPORT DLERACT  ISTICS, *PfN*/RMINIPORT DLERACT  ISTICS O NDUI     _Bd(fN*/40)ttypedefSstruct _fN*/RMINIPORT DLERACT  ISTICS {BuffN*/40RMINIPORT DLERACT  ISTICS_S
}ffN*/RMINIPORT DLERACT  ISTICS, *PfN*/RMINIPORT DLERACT  ISTICS O NDUI     _Bd(fN*/30)ttypedefSstruct _fN*/RMINIPORT DLERACT  ISTICS {BuffN*/30RMINIPORT DLERACT  ISTICS_S
}ffN*/RMINIPORT DLERACT  ISTICS, *PfN*/RMINIPORT DLERACT  ISTICS O Nnandler;fN*/30 cketDtypedefS            nchainB(*    E2; \
 R)(  IS_STATUS  Status,
 DLacBinding_HANDLFDISAP NDISS50_PRPa * NdisChain(  _typedefS            nchainB(*TRANS    DATAE2; \
 R)(  IS_STATUS  Status,
 DLacBinding_HANDLFDISAP NDISS  Status,
 DLacReket) CoHandlC   

#elseC,
  /Byte _NDIS_PROTOCOL_Ct,
  /BytePToTrans   CS_ 

ffset,
  /*ID
 * NdisChainBufionnSendCot,
  /BytePTrans   red(  _typedefS            nchainB(*RESiva2; \
 R)(  IS_STATUS  Status,
 DLacBinding_HANDL(  _typedefS            nchainB(*REQUESTE2; \
 R)(  IS_STATUS  Status,
 DDLacBinding_HANDLFDISAP NDISS50_PRREQUEST ((  /*INquestUINTIIVE_Structu    available only to fullrMAC drt) rPackettypedefSBOOLEAN nchainB(*S50_PRronERRUPTESERVICE)(  IS_STATU40_PROT  triruptadHandl_PADtypedefS     nchainB(*S50_PRDE   RE EDROCESSple)(  IS_STATU40_PROT!= NULSpecific1NDISAP NDIS40_PROT  triruptadHandlCS_ 

#else*DDKAPIS= NULSpecific2CS_ 

#else*DDKAPIS= NULSpecific3UINTIItypedefSstruct _fN*/RMINIPORT BLOCK fN*/RMINIPORT BLOCK, *PfN*/RMINIPORT BLOCK;ItypedefSstruct _fN*/RDROTOCOL BLOCK fN*/RDROTOCOL BLOCK, *PfN*/RDROTOCOL BLOCK;ItypedefSstruct _fN*/ROPEN BLOCK		fN*/ROPEN BLOCK, Buff*PfN*/ROPEN BLOCK;ItypedefSstruct _fN*/RM_DRIVER_BLOCK fN*/RM_DRIVER_BLOCK, *PfN*/RM_DRIVER_BLOCK;Itypedef	struct _fN*/RAF_LIST (((((((fN*/RAF_LIST, (((((((*PfN*/RAF_LIST;TIItypedefSstruct _fN*/RMINIPORT ronERRUPT {BufPKronERRUPT T  triruptObject;BufKCPIN_LOCK  DpcacketLo  ;Buf*DDKAPILiniportIdField;BufW ISRE2; \
 RufLiniportIsr;BufW HAus,
_ronERRUPTE2; \
 R  LiniportDpc;BufKDPC T  triruptDpc;BufPfN*/RMINIPORT BLOCK  Liniport;Buf DLER)(Dpcacket;BufBOOLEAN  FilDLr1;BufKEVE

NDDpceCompletrdEv  C;BufBOOLEAN  Shared  trirupt;BufBOOLEAN	 IsrINquested;B}ffN*/RMINIPORT ronERRUPT, *PfN*/RMINIPORT ronERRUPT  DtypedefSstruct _fN*/RMINIPORT TIM R {BufKTIM R  )(_Pr;BufKDPC TDpc;BufPfN*/RTIM R_FUNC    u Liniport)(_PrFuncf de;Buf*DDKAPILiniport)(_PradHandl;BufPfN*/RMINIPORT BLOCK  Liniport;Bufstruct _fN*/RMINIPORT TIM R (P _FiDe   red)(_Pr;B}ffN*/RMINIPORT TIM R, *PfN*/RMINIPORT TIM R  DtypedefSstruct _fN*/RronERRUPT {BufPKronERRUPT T  triruptObject;BufKCPIN_LOCK  DpcacketLo  ;Buf*50_PRronERRUPTESERVICEDDLacIsr;BufS50_PRDE   RE EDROCESSpleDDLacDpc;BufKDPC T  triruptDpc;BufP0_PROT  triruptadHandl;Buf DLER)(Dpcacket;BufBOOLEAN	 Removing;BufKEVE

NDDpceCompletrdEv  C;B}ffN*/RronERRUPT, *PfN*/RronERRUPT  DDtypedefSstruct _MAP_REGIST   ENTRYr{
	*DDKAPILapRegistri;
	BOOLEAN  Writ,ToHavicr;B}fMAP_REGIST   ENTRY, *PMAP_REGIST   ENTRY  DDtypedefSenum _fN*/RWORK_ITEM->Prid{Buff /*WorkINULINquest,Buff /*WorkINULSET_calff /*WorkINULINtu nsChainscalff /*WorkINULINsatacquestedcalff /*WorkINULINsatIeProg if     f /*WorkINULHalt,Buff /*WorkINULSET_Loopba  ,atif /*WorkINULLiniportCallba  ,atif /*MaxWorkINULsB}ffN*/RWORK_ITEM->Pri, *PfN*/RWORK_ITEM->Pri;et	    _B	NUMB   OFRWORK_ITEM->PriSINT  Bufff /*MaxWorkINULsB	    _B	NUMB   OFRSpleLE_WORK_ITEMSINT  Bu6 DtypedefSstruct _fN*/RMINIPORT WORK_ITEMr{
	SpleLE_LIST_ENTRYrr)in ;B	fN*/RWORK_ITEM->Prid WorkINULTypL;
	*DDKAPIWorkINULadHandl;B}ffN*/RMINIPORT WORK_ITEM, *PfN*/RMINIPORT WORK_ITEM;TIItypedefSstruct _fN*/RBI  ED
THS {B	t,
  /N
NDIS;B	fN*/RCompletePaths[1];B}ffN*/RBI  ED
THS, *PfN*/RBI  ED
THS;et	    _B DECLlRE_UNKNOWNRComUCT(BaseName e BuftypedefSstruct _##BaseName BaseName, *P##BaseName;et	    _B DECLlRE_UNKNOWNRDROTO>Pri(Name e BuftypedefSDDKAP(*(Name )(0_PRN Oo	    _B ETH_LENGTH_OFR!__cplu 6 DDECLlRE_UNKNOWNRComUCT(ETH_BI  pleFFER ) DDECLlRE_UNKNOWNRDROTO>Pri(ETH_!__cpluxC2; GE)DDECLlRE_UNKNOWNRDROTO>Pri(ETH_FILTER_DLE GE)DDECLlRE_UNKNOWNRDROTO>Pri(ETH_DE   RE ECLOSE)DItypedefSstruct _ETH_FILTER {BufPfN*/RCPIN_LOCK  Lo  ;BufDLER)((*MCast       Buf)[ETH_LENGTH_OFR!__cplu];Bufstruct _fN*/RMINIPORT BLOCK  *Liniport;Buf ,
  /Comb _BdsChainFiltPr;BufPETH_BI  pleFFER erI
(*)ist;BufETH_!__cpluxC2; GE         ChangeAcf de;BufETH_FILTER_DLE GE  FilDISahangeAcf de;BufETH_DE   RE ECLOSEerCloseAcf de;Buft,
  /uaxMulticast       es;Buft,
  /N
N       es;BuftDLER)*/ NDIS       [ETH_LENGTH_OFR!__cplu];Buft,
  /OldComb _BdsChainFiltPr;BufDLER)((*OldMCast       Buf)[ETH_LENGTH_OFR!__cplu];Buft,
  /OldN
N       es;BufPETH_BI  pleFFER erDirecfed)ist;BufPETH_BI  pleFFER erBM)ist;BufPETH_BI  pleFFER erMCastSet;B UI     _Bd(_fN*/R)Buft,
  /N
NI
(*s;BufP0_PROTBind)istLo  ;B NnandB}fETH_FILTER, *PETH_FILTERPADtypedefS     nchainB(*ETH_RCV_COMPLETEE2; \
 R)(  IS_STATUPETH_FILTER  FilDIS_PADtypedefS     nchainB(*ETH_RCV_I  pCATE_2; \
 R)(  IS_STATUPETH_FILTER  FilDISFDISAP NDISS  Status,
 DLacReket) CoHandlC   

#elsePDLER)(ARACTERISTICS_S \
*0_PROT    er          

#elseC         er      NDIS_PROTOCOL_C*DDKAPILookah             

#elseC     Lookah         NDIS_PROTOCOL_CC      gs & NDIS_PADtypedefS     nchainB(*FDDI_RCV_COMPLETEE2; \
 R)(  IS_STATUPFDDI_FILTER  FilDIS_PADtypedefS     nchainB(*FDDI_RCV_I  pCATE_2; \
 R)(  IS_STATUPFDDI_FILTER  FilDISFDISAP NDISS  Status,
 DLacReket) CoHandlC   

#elsePDLER)(ARACTERISTICS_S \
C     ARACTERI
NdisFDISAP NDIS40_PROT    er          

#elseC         er      NDIS_PROTOCOL_C*DDKAPILookah             

#elseC     Lookah         NDIS_PROTOCOL_CC      gs & NDIS_PADtypedefS     nchainB(*FILTER_Pa * NEI  pCAT   E2; \
 R)(  IS_STATUS  Status,
 DLiniport_PROTOCOL_C  * VOID
 * NdisChainArraynationOffset,
  /N
NDISAPPChains_PADtypedefS     nchainB(*TR_RCV_COMPLETEE2; \
 R)(  IS_STATUPTR_FILTER  FilDIS_PADtypedefS     nchainB(*TR_RCV_I  pCATE_2; \
 R)(  IS_STATUPTR_FILTER  FilDISFDISAP NDISS  Status,
 DLacReket) CoHandlC   

#elseP0_PROT    er          

#elseC         er      NDIS_PROTOCOL_C*DDKAPILookah             

#elseC     Lookah         NDIS_PROTOCOL_CC      gs & NDIS_PADtypedefS     nchainB(*WtalRCV_COMPLETEE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#elseNNAME2; \
  _*IN*LinkadHandl_PADtypedefS     nchainB(*WtalRCV_2; \
 R)(  IS_nSendCompleteHandler; \
  } DUMMYUNIONNAME2; \
  _Liniport*/ NDIS_HANDLCS_ 

#elseNNAME2; \
  _*IN*LinkadHandler; 

30_PRO DLER)(ags &     

#elseCediaer gs & NDIS_PADtypedefS     nchFAeHainB(*fN*/RM_DEQUEUE_WORK_ITEM)(  IS_STATUPfN*/RMINIPORT BLOCK  LiniportCS_ 

#elseNNAMEWORK_ITEM->Prid WorkINULTypL    

nSendCo       WorkINULadHandl(  _typedefS            nchFAeHainB(*fN*/RM_QUEUE_NEW_WORK_ITEM)(  IS_STATUPfN*/RMINIPORT BLOCK  LiniportCS_ 

#elseNNAMEWORK_ITEM->Prid WorkINULTypL    

COL_C*DDKAPIWorkINULadHandl(  _typedefS            nchFAeHainB(*fN*/RM_QUEUE_WORK_ITEM)(  IS_STATUPfN*/RMINIPORT BLOCK  LiniportCS_ 

#elseNNAMEWORK_ITEM->Prid WorkINULTypL    

COL_C*DDKAPIWorkINULadHandl(  _typedefS     nchainB(*fN*/RM_REQ_COMPLETEE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#elseNNAMEeHandler; \
  );tttypedefS     nchainB(*fN*/RM_RESivaCOMPLETEE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#elseNNAMEeHandler; \
  CS_ 

#elseBOOLEAN         ingReset);tttypedefS     nchainB(*fN*/RM_    ECOMPLETEE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#else * VOID
 * NdisChainBufionOffseNNAMEeHandler; \
  );tttypedefS     nchainB(*fN*/RM_    EcplOURCESE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDL(  _typedefSBOOLEAN nchFAeHainB(*fN*/RM_eHaRT_    S)(  IS_STATUPfN*/RMINIPORT BLOCK  Liniport);tttypedefS     nchainB(*fN*/RM_ HandlE2; \
 R)(  IS_STATUS  Status,
 DLiniport_HANDLCS_ 

#elseNNAMEeHandlerGener  St\
  CS_ 

#else*DDKAPISt\
        _PROTOCOL_CC     St\
        NDIS_PADtypedefS     nchainB(*fN*/RM_ HSECOMPLETEE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDL_PADtypedefS     nchainB(*fN*/RM_T ECOMPLETEE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#else * VOID
 * NdisChainBufionOffseNNAMEeHandler; \
  _PROTOCOL_Ct,
  /BytePTrans   red(  _typedefSDDKAP(nchain *fN*/RWM_    ECOMPLETEE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#else DDKAPIsChainBufionOffseNNAMEeHandler; \
  );ttB UI ARCNETOo	    _B ARC_    E      SINT  Bufffffffffff8o	    _B ARC_Packet_SIZEINT  Bufffffffffff 4IItypedefSstruct _fN*/RARC_    {BuffN*/tatus,
 DArcn&       Pool;BufP DLER)(Arcn& Lookah         ;Buft,
  /N
NFree;BufARC_       LIST Arcn&       s[ARC_    E      S];B}ffN*/RARC_   , *PfN*/RARC_   ;
  Nnandler;ARCNETacket	    _BufN*/RMINIPORT WORK_QUEUE_SIZEI10IItypedefSstruct _fN*/RLOG {BufPfN*/RMINIPORT BLOCK  Liniport;BufKCPIN_LOCK  LogLo  ;Buf*IRP  Irp;Buft,
  /Tot  SDIS;Buf ,
  /CPacket!DIS;Buf ,
  /InPt ;Buft,
  /OutPt ;BuftDLER)(Log   [1];B}ffN*/RLOG, *PfN*/RLOG  DtypedefSstruct _FILTERDBS {Buf_ANONYMOUS_UN   uun dee{
fff PETH_FILTER  EthDB;
fff PNULL_FILTER  NullDB;
ff} DUMMYUN   NAME;Buf*TR_FILTER  TrDB;
ffPFDDI_FILTER  FddiDB;
 UI ARCNETOffPARC_FILTER  ArcDB;
 NDISSAP !ARCNETackeufP0_PROTXXXDB;
 Nnandler;!ARCNETacke} FILTERDBS, *PFILTERDBS;ttBstruct _fN*/RMINIPORT BLOCK {eufP0_PROTSignatu  ;BufPfN*/RMINIPORT BLOCK   _FiLiniport;BufPfN*/RM_DRIVER_BLOCK Dtrt) r_HANDL;BuffN*/tatus,
 DLiniport*/ NDISadHandl;BuftNICOD RCompleteLiniportName;eufPfN*/RBI  ED
THS TBindPaths;BuffN*/tatus,
 DI
(*   uP;BufRE   ENCEDDRef;BuffN*/tatus,
 DHavicradHandl;BuftDLER)(Padding1;BuftDLER)(LockCcquirRd;BuftDLER)(PmodeI
(*s;Buf DLER)(AssignedProcessor;BufKCPIN_LOCK  Lo  ;Buf*50_PRREQUEST (uc  aacquest;BufPfN*/RMINIPORT ronERRUPT T  trirupt;Buf ediaerferAt;Buf ediaerPnPferAt;BufLIST_ENTRYrrsChain)ist;BufP* VOID
 * NdiFirstPendingsChain;BufP* VOID
 * NdiINtu nsChains   uP;Buf ediaeracquest      ;BufP0_PROTSetMCast      ;BufPfN*/RMINIPORT BLOCK  Prima_NLiniport;BufP0_PROTWrapperConandl;BufPDDKAPI  s    adHandl;BuftediaerPnPCapabilities;BufPCMtcplOURCE_LIST (ResRISTIs;BuffN*/tTIM R (WakeUpDpc)(_Pr;BuftNICOD RCompleteBaseName;euftNICOD RCompleteEymbolicLinkName;euftediaerCheckFor_HAgSecondt;Buf SHORTerCF_HAgTickt;Buf SHORTerCF_HAgCPacketTick;BuffN*/teHandlerReset; \
  ;BuffN*/tatus,
 DResetI
(*;BufFILTERDBS  FilDISDbs;BufFILTER_Pa * NEI  pCAT   E2; \
 RrrsChainIndic tP_HANDLr;
  fN*/RM_    ECOMPLETEE2; \
 R /OendCompletr_HANDLr;
  fN*/RM_    EcplOURCESE2; \
 R /OendResRISTIs_HANDLr;
  fN*/RM_RESivaCOMPLETEE2; \
 R DResetCompletr_HANDLr;
  fN*/RMEDIUM /uc  aTypL;
uftediaer  sN
NDIS;B ffN*/RronERFACE_>Prid   sTypL;
uffN*/RronERFACE_>Prid */ NDISTypL;
ufoDEVICE_OBJECT (DevicrObject;
ufoDEVICE_OBJECT (    \
  DevicrObject;
ufoDEVICE_OBJECT ( _FiDevicrObject;
ufoMAP_REGIST   ENTRYrILapRegistris;BufPfN*/RAF_LIST (CallMgrAf)ist;BufPDDKAPILiniport)hr   ;BufP0_PROTSet   p   ;Buf SHORTerSet   p   L(*;Buf SHORTerMaxKET_PChains;BuffN*/teHandlerFake; \
  ;Buf*DDKAPILock_HANDLr;
  PtNICOD RCompletep*/ NDISInstanceName;BufPfN*/RMINIPORT TIM R  )(_Pr   uP;Buf ,
  /uacOpf de ;Buf*50_PRREQUEST (Pendingacquest;Buft,
  /uaximumLong       es;Buft,
  /uaximumShort*/     es;Buft,
  /CPacketLookah   ;Buft,
  /uaximumLookah   ;BufW HAus,
_ronERRUPTE2; \
 R  HaANDLIntrirupt_HANDLr;
ufW DDKABLE_ronERRUPTE2; \
 R _HisableIntrirupt_HANDLr;
ufW ENABLE_ronERRUPTE2; \
 R  EnableIntrirupt_HANDLr;
ufW     ED
 * NSE2; \
 R /OendPChains_HANDLr;
  fN*/RM_ HaRT_    S (De   redKET__HANDLr;
ufETH_RCV_I  pCATE_2; \
 R  EthRxIndic tP_HANDLr;
  TR_RCV_I  pCATE_2; \
 R  TrRxIndic tP_HANDLr;
  FDDI_RCV_I  pCATE_2; \
 R  FddiRxIndic tP_HANDLr;
  ETH_RCV_COMPLETEE2; \
 R  EthRxCompletr_HANDLr;
  TR_RCV_COMPLETEE2; \
 R  TrRxCompletr_HANDLr;
  FDDI_RCV_COMPLETEE2; \
 R  FddiRxCompletr_HANDLr;
  fN*/RM_ HandlE2; \
 Rer; \
  _HANDLr;
  fN*/RM_ HSECOMPLETEE2; \
 Rer; \
  Completr_HANDLr;
  fN*/RM_T ECOMPLETEE2; \
 R  TDCompletr_HANDLr;
  fN*/RM_REQ_COMPLETEE2; \
 R     ryCompletr_HANDLr;
  fN*/RM_REQ_COMPLETEE2; \
 R  SetCompletr_HANDLr;
  fN*/RWM_    ECOMPLETEE2; \
 R /WanKET_Completr_HANDLr;
  WtalRCV_2; \
 R /WanRcv_HANDLr;
  WtalRCV_COMPLETEE2; \
 R /WanRcvCompletr_HANDLr;
 UI     _Bd(_fN*/R)BufPfN*/RMINIPORT BLOCK   _FiGlobalLiniport;BufSpleLE_LIST_ENTRYrrWork   uP[NUMB   OFRWORK_ITEM->PriS];BufSpleLE_LIST_ENTRYrrSingleWorkINULs[NUMB   OFRSpleLE_WORK_ITEMS];Buf DLER)(KET_ferAt;Buf DLER)(TrRNsataing;Buf DLER)(Arcn& */     ;Buf DLER)(X; \
e;Buf_ANONYMOUS_UN   uun dee{
 UI ARCNETOffufPfN*/RARC_    (Arc   ;B NnandBffufPDDKAPI  sIntriface;
ff} DUMMYUN   NAME;Buf*fN*/RLOG (Log;
uftediaerSlotN
NDIS;B fPCMtcplOURCE_LIST (AOL_CHARdResRISTIs;B fPCMtcplOURCE_LIST (AOL_CHARdResRISTIsTransl*OUd;BufSpleLE_LIST_ENTRYrrPHADIS*)ist;Buf* VOIDNP_CAPABILITIiSINPMCapabilities;BufDEVICE_CAPABILITIiSINHavicraapt;Buf ediaerWakeUpEnable;BufDEVICE_POWet_S   E  CPacketDevicrPower; \
e;Buf*IRP  pIrpWaitWake;BufSYSTEM-POWet_S   E  WaitWakeS= NULS \
e;BufLARGE_ronEG R /VcIndex;BufKCPIN_LOCK  VcacketLo  ;BufLIST_ENTRYrrWmiEnabledVc ;Buf*50_PRGUKAPIp*IN*GuidLap;Buf*50_PRGUKAPIpCustomGuidLap;Buf SHORTerVcacket;Buf SHORTerc*IN*GuidLap;Buf SHORTercCustomGuidLap;Buf SHORTerCPacketLapRegistri;
ufPKEVE

NDAOL_CHA deEv  C;Buf SHORTerBaseLapRegistrisNeeded;Buf SHORTerSGLapRegistrisNeeded;Buf ediaerMaximum    \
  Mapping;BuffN*/tTIM R (uc  aHisconnecf)(_Pr;BuftSHORTerMc  aHisconnecf)(_POuC;Buf SHORTerInstanceN
NDIS;B ffN*/REVE

NDI
(*R   yEv  C;Buf* VOIDNP_DEVICE_S   E  PnPDevicrS \
e;Buf* VOIDNP_DEVICE_S   E  OldPnPDevicrS \
e;BufPGET   TFDEVICE_DATA  Set  s    ;BufPGET   TFDEVICE_DATA  Get  s    ;BufKDPC TDe   redDpc;B UI 0
fionfFIXME:ackeuffN*/teHanS (  /*S \
s;
 NDISBuf ediaer  /*S \
s;
 NnandBffP* VOID
 * NdiIndic tPdPChain[MAXIMUMEDROCESSORS];BufPKEVE

NDRemoveR   yEv  C;BufPKEVE

NDAOLI
(*sClosedEv  C;BufPKEVE

NDAOLacquesteCompletrdEv  C;BufCediaer  if)(_PMs;BuffN*/tMINIPORT WORK_ITEMrIWorkINUL      [NUMB   OFRSpleLE_WORK_ITEMS];BufPDMA_ADAPTER  S= NUL*/ NDISObject;
ufCediaer rt) rVerifyferAt;BufPDKA_LIST (Oid)ist;Buf SHORTerInDIS*alResetCoket;Buf SHORTerLiniportResetCoket;Buf SHORTerLc  aKETseConnecfCoket;Buf SHORTerLc  aKETseHisconnecfCoket;BufP* VOID
 * Ndi*xPChains;BufCediaerUserModeI
(*Re   enTIs;B f_ANONYMOUS_UN   uun dee{
fff P0_PROTSavedKET__HANDLr;
uff P0_PROTSavedWanKET__HANDLr;
ff} DUMMYUN   NAME2;BufP0_PROTSavedKET_PChains_HANDLr;
  P0_PROTSaved_ancelKET_PChains_HANDLr;
  W     ED
 * NSE2; \
 R /WKET_PChains_HANDLr;eeeeeeeeeeeeeeeeBuf ediaerMiniport*ttributBs;BufPDMA_ADAPTER  SavedK= NUL*/ NDISObject;
ufCSHORTerN
NI
(*s;Buf SHORTerCF_HAgXTickt;eBuf ediaerRequestCou C;BufCediaer  dic tPdPChainsCou C;BufCediaer    \
  Mc  umTypL;
ufo50_PRREQUEST (Lastacquest;Bufediaer ma*/ NDISRe Coket;BufP0_PROTFakeuac;BufCediaerLo  Dbg;BufCediaerLo  DbgX;Buf*DDKAPILock)hr   ;BufCediaer   pferAt;BufKCPIN_LOCK  )(_Pr   uPLo  ;Buf*KEVE

NDResetCompletrdEv  C;BufPKEVE

ND   uPdBindingadmpletrdEv  C;BufPKEVE

ND maResRISTIsINleasedEv  C;BufFILTER_Pa * NEI  pCAT   E2; \
 RrrSavedsChainIndic tP_HANDLr;
   ediaerRegistried  trirupt ;Buf*5PAGEA_LOOKASIDE_LIST (SG)istLookaside)ist;Buf ediaerScHADISGather)ist!DIS;B Nnandler;_fN*/Racke} Oont(__HANDLr prototypePafor 50_PROPEN BLOCK ckettypedefS            (nchain *Wtal    E2; \
 R)(  IS_STATUS  Status,
 DLacBinding_HANDLFDISAP NDISS  Status,
 DLink_HANDLFDISAP NDISSDDKAPIsChain);ttt(_HAND 4.0 ndlension ckettypedefS     (nchain *    ED
 * NSE2; \
 R)(  IS_STATUS  Status,
 DLiniport*/ NDISadHandl_PROTOCOL_C  * VOID
 * NdisChainArraynationOffset,
  /N
NDISAPPChains_PADItypedefSstruct _fN*/RCOMM  EOPEN BLOCK {Buf*DDKAPILac_HANDL;BuffN*/tatus,
 DBinding_HANDL;BufPfN*/RMINIPORT BLOCK  Liniport_HANDL;BufPfN*/RDROTOCOL BLOCK _Protocol_HANDL;BuffN*/tatus,
 DProtocolBindingadHandl;BufPfN*/ROPEN BLOCK eLiniportNndlI
(*;BufPfN*/ROPEN BLOCK eProtocolNndlI
(*;BuffN*/tatus,
 DLiniport*/ NDISadHandl;BufBOOLEAN  Reserved1;BufBOOLEAN  Reserved2;BufBOOLEAN  Reserved3;BufBOOLEAN  Reserved4;BufPfN*/RCompleteBindDevicrName;BufKCPIN_LOCK  Reserved5;BufPfN*/RCompleteRootDevicrName;Buf_ANONYMOUS_UN   uun dee{
fff     E2; \
 R /Oend_HANDLr;
fff Wtal    E2; \
 R /WanKET__HANDLr;
ff} DUMMYUN   NAME;BufTRANS    DATAE2; \
 R  Trans       _HANDLr;
f     ECOMPLETEE2; \
 R /OendCompletr_HANDLr;
  TRANS    DATAECOMPLETEE2; \
 R  Trans       Completr_HANDLr;
  RECEIVEE2; \
 R /Recet) _HANDLr;
  RECEIVEECOMPLETEE2; \
 R DReket) Completr_HANDLr;
  WtalRECEIVEE2; \
 R /WanRecet) _HANDLr;
  REQUESTECOMPLETEE2; \
 R DRequestCompletr_HANDLr;
  RECEIVEEPa * NE2; \
 R /Reket) IS_HAN_HANDLr;
f     ED
 * NSE2; \
 R /OendPChains_HANDLr;
  RESiva2; \
 R /Reset_HANDLr;
  REQUESTE2; \
 R DRequest_HANDLr;
  RESivaCOMPLETEE2; \
 R DResetCompletr_HANDLr;
   HandlE2; \
 Rer; \
  _HANDLr;
   HandlECOMPLETEE2; \
 Rer; \
  Completr_HANDLr;
 UI     _Bd(_fN*/R)BuftediaerferAt;Buf ediaerRe   enTIs;B fKCPIN_LOCK  SpinLo  ;BuffN*/tatus,
 DFilDIS_HANDL;BufCediaer rotocolOpf de ;Buf SHORTerCPacketLookah   ;BuftSHORTerConnecfDampTickt;Buf SHORTerHisconnecfDampTickt;BufW     E2; \
 R /WKET__HANDLr;
ffW TRANS    DATAE2; \
 R  WTrans       _HANDLr;
f W     ED
 * NSE2; \
 R /WKET_PChains_HANDLr;
f W CANCEL     ED
 * NSE2; \
 ROT_ancelKET_PChains_HANDLr;
f  ediaerWakeUpEnable;BufPKEVE

NDCloseCompletrEv  C;BufQUEUE ECLOSEerQC;
f  ediaerAfRe   enTIs;B fPfN*/ROPEN BLOCK e _FiGlobalI
(*;B Nnandler;_fN*/Racke} fN*/RCOMM  EOPEN BLOCK;tBstruct _fN*/ROPEN BLOCK
{
fff fN*/RCOMM  EOPEN BLOCK EGISCommonI
(*Blo  ;B UI     _Bd(_fN*/R)Buf Sstruct _fN*/ROPEN COBuf S{
fff uf Sstruct _fN*/RCO_AF BLOCK c e _FiAf;
fff uf SW CO_CREATE_VCE2; \
 ROTTTTTLiniportCHetext,Vc_HANDLr;
fff uf SW CO_REQUESTE2; \
 R DOTTTTTLiniportCHRequest_HANDLr;
        CO_CREATE_VCE2; \
 ROTTTTTOT_Hetext,Vc_HANDLr;
        CO_DELETEEVCE2; \
 ROTTTTTOT_HDeletrVc_HANDLr;
        *DDKAPIIIIIIIIIIIIIIIIIIIIIICmAcf T_ALVcCompletr_HANDLr;
        *DDKAPIIIIIIIIIIIIIIIIIIIIIICmDeacf T_ALVcCompletr_HANDLr;
        *DDKAPIIIIIIIIIIIIIIIIIIIIIICoRequestCompletr_HANDLr;
        LIST_ENTRYrrrrrrrrrrrrrrrrrrAcf TrVc_   ;Buf      LIST_ENTRYrrrrrrrrrrrrrrrrrrInacf TrVc_   ;Buf      LdiaerrrrrrrrrrrrrrrrrrrrrrrPendingAfNotificaf de ;BufrrrrrrPKEVE

NDDDDDDDDDDDDDDDDDDDDAfNotifyCompletrEv  C;Bufff};B Nnandler;_fN*/Racke} Oontt(_Rout _BPafor HAND miniport drt) rPacketHANDAPI
NdisUnchainBuffeIniti   zDWrapper(  IS_nSendComplet2; \
  _*IN*Wrapper_HANDLFDISAP NDISSDDKAPI!= NULSpecific1NDISAP NDIS40_PROTS= NULSpecific2CS_ 

#else*DDKAPIS= NULSpecific3UINTHANDAPI
            CO_AF_REGISMAOL_CHARLapRegistris(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#elset,
  / maahannelCS_ 

#elseBOOLEAN   ma32Bit*/     es    

#elseCediaer    \
  MapRegistrisNeeded    

#elseCediaerMaximum    \
  Mapping);ttt(
 c NdisU c EGISMArcIndic tPacket) (U c INUS  Status,
 DLiniport*/ NDIS_HANDLCS_c INUP DLER)(    er         c INUP DLER)(             c INU);

NDD  Res(   cke	    _BufGISMArcIndic tPacket) (Liniport*/ NDIS_HANDLCe Buf                                  er                  Buf                                                      Buf                              D  Res(                \
{uf                                                     Buf  ArcFilDISDprIndic tPacket) (                        Buf      (((PfN*/RMINIPORT BLOCK)(Liniport*/ NDIS_HANDL))->FilDISDbs.ArcDB)Ce Buf      (    er      )Ce Buf      (          ),    Buf      (D  Res();       B}ttt(
 c NdisU c EGISMArcIndic tPacket) Completr(  c INUS  Status,
 DLiniport*/ NDIS_HANDL(   cke	    _BufGISMArcIndic tPacket) Completr(Liniport*/ NDIS_HANDL( \
{uf                                                             Buf  ndl(((PfN*/RMINIPORT BLOCK)Liniport*/ NDIS_HANDL(->EthDB)   B	uf  {uf                                                       B	uf      fGISMEthIndic tPacket) Completr(_H);eeeeeeeeeeeeeeee  B	uf  }uf                                                       Buf                                                              Buf  ArcFilDISDprIndic tPacket) Completr(                        Buf    ((PfN*/RMINIPORT BLOCK)Liniport*/ NDIS_HANDL(->ArcDB);    B}ttHANDAPI
NdisUnchainBuffeMCloseLog(  IS_STATUS  Status,
 DLog_HANDL_PADHANDAPI
            CO_AF_REGISMetext,Log(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#elset,
  /NDIS_PROTOnSendComplet2; \
  _Log_HANDL_PADHANDAPI
NdisUnchainBuffeMDeregistri*/ NDISShutdowd_HANDLr(  IS_STATUS  Status,
 DLiniport_HANDL_PADHANDAPI
NdisUnchainBuffeMDeregistri  trirupt(  IS_STATUPfN*/RMINIPORT ronERRUPT T  trirupt_PADHANDAPI
NdisUnchainBuffeMDeregistri oPortRange(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#elset,
  /Initi  PortCS_ 

#elset,
  /N
NDISAPPortsFDISAP NDISSDDKAPIsort _NDIS);ttt(
 c NdisU c EGISMEthIndic tPacket) (U c INUS  Status,
 DLiniport*/ NDIS_HANDLCS_c INUS  Status,
 DLiniportReket) CoHandlC  c INUP0_PROT    er         c INU);

ND    er      NDIS_PRc INUP0_PROTLookah            c INU);

NDDookah         NDIS_PRc INU);

ND gs & NDIS_PA cke	    _BufGISMEthIndic tPacket) (Liniport*/ NDIS_HANDLCe  Buf                              LiniportReket) CoHandlCe Buf                                  er                 e Buf                                  er      NDIS_      e Buf                              Lookah                 e Buf                              Dookah         NDIS_   e Buf                               gs & NDIS_             \
{uf                                                      Buf  (*((PfN*/RMINIPORT BLOCK)(Liniport*/ NDIS_HANDL))->EthRxIndic tP_HANDLr)(  Buf      (((PfN*/RMINIPORT BLOCK)(Liniport*/ NDIS_HANDL))->FilDISDbs.EthDB)Ce B		(LiniportReket) CoHandl)Ce B		(    er      )Ce           B		(    er      )Ce           B		(    er      NDIS_,        B		(Dookah         ),         B		(Dookah         NDIS_,     B		( gs & NDIS_);eeeeeeeeeeee B}ttt(
 c NdisU c EGISMEthIndic tPacket) Completr(S_c INUS  Status,
 Liniport*/ NDIS_HANDL(   cke	    _BufGISMEthIndic tPacket) Completr(Liniport*/ NDIS_HANDL( \
{uf                                                             Buf  (*((PfN*/RMINIPORT BLOCK)(Liniport*/ NDIS_HANDL))->EthRxCompletr_HANDLr)(  Buf      ((PfN*/RMINIPORT BLOCK)Liniport*/ NDIS_HANDL(->FilDISDbs.EthDB);eeee B}ttt(
 c NdisU c EGISMFddiIndic tPacket) (U c INUS  Status,
 DLiniport*/ NDIS_HANDLCS_c INUS  Status,
 DLiniportReket) CoHandlC  c INUP0_PROT    er         c INU);

ND    er      NDIS_PRc INUP0_PROTLookah            c INU);

NDDookah         NDIS_PRc INU);

ND gs & NDIS_PA cke	    _B EGISMFddiIndic tPacket) (Liniport*/ NDIS_HANDLCe  Buf                               LiniportReket) CoHandlCe Buf                                   er                 e Buf                                   er      NDIS_      e Buf                               Lookah                 e Buf                               Dookah         NDIS_   e Buf                                gs & NDIS_             \
{uf                                                       Buf  (*((PfN*/RMINIPORT BLOCK)(Liniport*/ NDIS_HANDL))->FddiRxIndic tP_HANDLr)(  Buf      (((PfN*/RMINIPORT BLOCK)(Liniport*/ NDIS_HANDL))->FilDISDbs.FddiDB),    Buf      (LiniportReket) CoHandl)Ce              Buf      (P DLER)(    er      ) + 1              Buf      (((*(P DLER*)(    er      )) & 0x40) ?e Buf          FDDI_LENGTH_OFRediaR!__cplu :       B		    FDDI_LENGTH_OFRSHORTR!__cplu)Ce     Buf      (    er      )Ce                        Buf      (    er      NDIS_,                     Buf      (Dookah         ),                      Buf      (Dookah         NDIS_,                  Buf      (Pgs & NDIS_);eeeeeeeeeeee              B}Oontt(
 c NdisU c EGISMFddiIndic tPacket) Completr(  c INUS  Status,
 DLiniport*/ NDIS_HANDL(   cke	    _BufGISMFddiIndic tPacket) Completr(Liniport*/ NDIS_HANDL( \
{uf                                                              Buf  (*((PfN*/RMINIPORT BLOCK)(Liniport*/ NDIS_HANDL))->FddiRxCompletr_HANDLr)(  Buf      ((PfN*/RMINIPORT BLOCK)Liniport*/ NDIS_HANDL(->FilDISDbs.FddiDB);       B}ttHANDAPI
NdisUnchainBuffeMFlushLog(  IS_STATUS  Status,
 DLog_HANDL_PADHANDAPI
NdisUnchainBuffeMFreRLapRegistris(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDL);ttt(
 c NdisU c EGISMIndic tP; \
  (U c INUS  Status,
 DLiniport*/ NDIS_HANDLCS_c INUS  SteHandlerGener  St\
  CS_c INUP0_PROTSt\
        _PRc INU);

NDSt\
        NDIS_PAacket	    _BufGISMIndic tP; \
  (Liniport*/ NDIS_HANDLCe  Buf Gener  St\
  CTSt\
        _DSt\
        NDIS_    Buf(*((PfN*/RMINIPORT BLOCK)(_M))->; \
  _HANDLr)(    BufLiniport*/ NDIS_HANDLCeGener  St\
  CTSt\
        _DSt\
        NDIS_ttt(
 c NdisU c EGISMIndic tP; \
  Completr(  c INUS  Status,
 DLiniport*/ NDIS_HANDL(   cke	    _BufGISMIndic tP; \
  Completr(Liniport*/ NDIS_HANDL( \
  (*((PfN*/RMINIPORT BLOCK)(Liniport*/ NDIS_HANDL))->; \
  Completr_HANDLr)(  Buf  Liniport*/ NDIS_HANDL)ttt(
 c NdisU c EGISMIniti   zDWrapper(  * PacComplet2; \
  _*IN*Wrapper_HANDLFDIc INUP0_PROTS= NULSpecific1NDIc INUP0_PROTS= NULSpecific2NDIc INUP0_PROTS= NULSpecific3(   cke	    _BufGISMIniti   zDWrapper(*IN*Wrapper_HANDLFe Buf                             S= NULSpecific1N  e Buf                             S= NULSpecific2N  e Buf                             S= NULSpecific3)  e Buf  uffeIniti   zDWrapper((*IN*Wrapper_HANDL)_   e Buf                        (S= NULSpecific1_,       Buf                        (S= NULSpecific2_,       Buf                        (S= NULSpecific3))ADHANDAPI
            CO_AF_REGISMLapIoSpace(  IS_nSendCo       OCOL_CHARACTERISTICS_S \
S  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#elsefN*/RDHYSICAL !__cplu      \
  \
  if     

#elseC;

NDD  Res(  tt(
 c NdisU c EGISM   ry   pSizeMedCompletr(  c INUS  Status,
 DLiniport*/ NDIS_HANDLCS_c INUS  SteHandler; \
  );t cke	    _BufGISM   ry   pSizeMedCompletr(Liniport*/ NDIS_HANDLCe; \
  ) \
  (*((PfN*/RMINIPORT BLOCK)(Liniport*/ NDIS_HANDL))->   ryCompletr_HANDLr)(Liniport*/ NDIS_HANDLCe; \
  )ADHANDAPI
NdisUnchainBuffeMRegistri*/ NDISShutdowd_HANDLr(  IS_STATUS  Status,
 DLiniport_HANDLCS_ 

#else*DDKAPIShutdowdadHandl_PROTOCOL_CADAPTERRSHUTDOWNR2; \
 Rer;hutdowd_HANDLr_PADHANDAPI
            CO_AF_REGISMRegistri  trirupt(  IS_nSendCompletMINIPORT ronERRUPT T  triruptISTICS_S \
S  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#elset,
  /IntriruptVecto _PROTOCOL_CC     IntriruptLevelCS_ 

#elseBOOLEAN  RequestIsrCS_ 

#elseBOOLEAN  Shared  triruptISTICS_S \
S  StronERRUPTEMODE  IntriruptMode_PADHANDAPI
            CO_AF_REGISMRegistri oPortRange(  IS_nSendCo       sort _NDISISTICS_S \
S  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#elset,
  /Initi  PortCS_ 

#elset,
  /N
NDISAPPorts_PADHANDAPI
            CO_AF_REGISMRegistriLiniport(  IS_STATUS  Status,
 D*IN*Wrapper_HANDLFDISAP NDISSmpletMINIPORT DLERACT  ISTICS (LiniportCharactriistic     

#elseC;

NDCharactriistic D  Res(  tB UI !    _Bd(_fN*/R)Btt(
 c NdisU c EGISMResetCompletr(  c INUS  Status,
 DLiniport*/ NDIS_HANDLCS_c INUS  SteHandler; \
  CS_c INUBOOLEAN         ingReset);t cke	    _B	EGISMResetCompletr(Liniport*/ NDIS_HANDLCe Buf                         St\
  CTTTTTTTTTTTTTTTT Buf                                ingReset)TTTTTTT B{uf                                                Buf  (*((PfN*/RMINIPORT BLOCK)(Liniport*/ NDIS_HANDL))->ResetCompletr_HANDLr)(  Buf      Liniport*/ NDIS_HANDLCe; \
  ,        ingReset);e B}ttt(
 c NdisU c EGISMOendCompletr(U c INUS  Status,
 DLiniport*/ NDIS_HANDLCS_c INUP* VOID
 * NdisChainCS_c INUS  SteHandler; \
  );t cke	    _B	EGISMOendCompletr(Liniport*/ NDIS_HANDLCe Buf                        sChainCTTTTTTTTTTTTTTTT Buf                        ; \
  ) TTTTTTTTTTTTTTT B{uf                                               Buf  (*((PfN*/RMINIPORT BLOCK)(Liniport*/ NDIS_HANDL))->OendCompletr_HANDLr)(  Buf      Liniport*/ NDIS_HANDLCesChainCT; \
  );ee B}ttt(
 c NdisU c EGISMOendResRISTIsAvailable(  c INUS  Status,
 DLiniport*/ NDIS_HANDL(   cke	    _B	EGISMOendResRISTIsAvailable(Liniport*/ NDIS_HANDL( \
{uf                                               Buf  (*((PfN*/RMINIPORT BLOCK)(Liniport*/ NDIS_HANDL))->OendResRISTIs_HANDLr)(  Buf      Liniport*/ NDIS_HANDL);e B}ttt(
 c NdisU c EGISMTrans       Completr(U c INUS  Status,
 DLiniport*/ NDIS_HANDLCS_c INUP* VOID
 * NdisChainCS_c INUS  SteHandler; \
  _PRc INU);

NDBytePTrans   red(   cke	    _B	EGISMTrans       Completr(Liniport*/ NDIS_HANDLCe Buf                                sChainCTTTTTTTTTTTTTTTT Buf                                St\
  CTTTTTTTTTTTTTTTT Buf                                BytePTrans   red(TTTTTT B{uf                                                       Buf  (*((PfN*/RMINIPORT BLOCK)(Liniport*/ NDIS_HANDL))->TDCompletr_HANDLr)(  Buf      Liniport*/ NDIS_HANDLCesChainCT; \
  , BytePTrans   red(TTTTTT      B}
  Nnandler;!_fN*/Rackettt(
 c NdisU c EGISMOet*ttributBs(U c INUS  Status,
 DLiniport*/ NDIS_HANDLCS_c INUS  Status,
 DLiniport*/ NDISadHandl_PRc INUBOOLEAN  BusMast  _PRc INUS  StronERFACE_>Prid */ NDISTypL);t cke	    _BufGISMOet*ttributBs(Liniport*/ NDIS_HANDLCe T Buf                         Liniport*/ NDISadHandl_ T Buf                         BusMast  _                Buf                         */ NDISTypL)              BuffGISMOet*ttributBsEx(Liniport*/ NDIS_HANDLCe T     Buf  Liniport*/ NDISadHandl_ TTTTTTTTTTTTTTTTTTTTTTTT Buf  0_ TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT Buf  (BusMast  ) ?eS  StATTRIBUTE_BU/RMAST   : 0_ TTT Buf  A/ NDISTypL)ADHANDAPI
Ndis  CO_AF_REGISMOet*ttributBsEx(STICS_S \
S  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#elsefN*/Ratus,
 DLiniport*/ NDISadHandl_PROTOCOL_CC;

NDCheckFor_HAg)(_PInSecondt  IS_n       */CS_ 

#elseCediaer*ttributBferAtISTICS_S \
S  StronERFACE_>Prid*/ NDISTypL); ttt(
 c NdisU c EGISMOet   pSizeMedCompletr(  c INUS  Status,
 DLiniport*/ NDIS_HANDLCS_c INUS  SteHandler; \
  );t cke	    _BufGISMOet   pSizeMedCompletr(Liniport*/ NDIS_HANDLCe Buf                                 e; \
  ) \
  (*((PfN*/RMINIPORT BLOCK)(Liniport*/ NDIS_HANDL))->SetCompletr_HANDLr)(  Buf  Liniport*/ NDIS_HANDLCe; \
  )ADHANDAPI
NdisUnchainBuffeMSleep(S_ 

#elseCediaerMicrosecondtToSleep_PADHANDAPI
BOOLEANUnchainBuffeMSynchron zDWithIntrirupt(  IS_STATUPfN*/RMINIPORT ronERRUPT T  triruptCS_ 

#else*DDKAPIS=nchron zDFuncf deCS_ 

#else*DDKAPIS=nchron zDadHandl(  _t(
 c NdisU c EGISMTrIndic tPacket) (U c INUS  Status,
 DLiniport*/ NDIS_HANDLCS_c INUS  Status,
 DLiniportReket) CoHandlC  c INUP0_PROT    er         c INU);

ND    er      NDIS_PRc INUP0_PROTLookah            c INU);

NDDookah         NDIS_PRc INU);

ND gs & NDIS_PA cke	    _B EGISMTrIndic tPacket) (Liniport*/ NDIS_HANDLCe  Buf                             LiniportReket) CoHandlCe Buf                                 er                 e Buf                                 er      NDIS_      e Buf                             Lookah                 e Buf                             Dookah         NDIS_   e Buf                              gs & NDIS_             \
{uf                                                     Buf  (*((PfN*/RMINIPORT BLOCK)(Liniport*/ NDIS_HANDL))->TrRxIndic tP_HANDLr)(  Buf    (((PfN*/RMINIPORT BLOCK)(Liniport*/ NDIS_HANDL))->FilDISDbs.TrDB)Ce     B		(LiniportReket) CoHandl)Ce B		(    er      )Ce           B		(    er      )Ce           B		(    er      NDIS_,        B		(Dookah         ),         B		(Dookah         NDIS_,     B		( gs & NDIS_);eeeeeeeeeeee B}ttt(
 c NdisU c EGISMTrIndic tPacket) Completr(  c INUS  Status,
 DLiniport*/ NDIS_HANDL(   cke	    _BufGISMTrIndic tPacket) Completr(Liniport*/ NDIS_HANDL( \
{uf                                                            B	(*((PfN*/RMINIPORT BLOCK)(Liniport*/ NDIS_HANDL))->TrRxCompletr_HANDLr)(  Buf  ((PfN*/RMINIPORT BLOCK)Liniport*/ NDIS_HANDL(->FilDISDbs.TrDB);eeee B}ttHANDAPI
            CO_AF_REGISMWrit,Log    (  IS_STATUS  Status,
 DLog_HANDL_PROTOCOL_C*DDKAPILog          

#elseC     Log      NDIS_PADHANDAPI
NdisUnchainBuffeM   ry*/ NDISResRISTIs(  IS_nSendCompleteHandler; \
  } DUMMYUNIONNAME2; \
  _WrapperConfigurzeMedCoHandl_PROTOnSendCompletcplOURCE_LIST (ResRISTI)ist} DUMMYU nSendCot,
  /B     NDIS_PADHANDAPI
NdisUnchainBuffeTermin tPWrapper(  IS_STATUS  Status,
 D*IN*Wrapper_HANDLFDISAP NDISS0_PROTS= NULSpecific_PADHANDAPI
NdisUnchainBuffeMUnmapIoSpace(  IS_STATUS  Status,
 DLiniport*/ NDIS_HANDLCS_ 

#else DDKAPIOCOL_CHARACTERISTICS_S \
C;

NDD  Res(  tttt(_HAND i trimc  ate miniport structu    ckettypedefS     (nchain *WtMINIPORT DALLBACK)(S_ 

#elsefN*/Ratus,
 DLiniport*/ NDISadHandl_PROTOCOL_C 0_PROT_allba  adHandl(  _ntt(_Rout _BPafor i trimc  ate miniport drt) rPacketHANDAPI
            CO_AF_REGISIMDeIniti   zDDevicrInstance(S_ 

#elsefN*/Ratus,
 uffeMiniport_HANDL_PADt(
 c              c EGISIMIniti   zDDevicrInstance(S_c INUS  Status,
 Dtrt) r_HANDLCS_c INUP* VOICompleteDevicrInstance(   cke	    _BufGISIMIniti   zDDevicrInstance(trt) r_HANDLCeDevicrInstance(  BuffGISIMIniti   zDDevicrInstanceEx(trt) r_HANDLCeDevicrInstance, NULL)ADHANDAPI
            CO_AF_REGISIMRegistriLayriedLiniport(  IS_STATUS  Status,
 D*IN*Wrapper_HANDLFDISAP NDISSmpletMINIPORT DLERACT  ISTICS (LiniportCharactriistic     

#elseC;

NDCharactriistic D  Res_PROTOnSendComplet2; \
  _trt) r_HANDL) Oont(_Funcf des obsoletrd by_HAND 5.0acketHANDAPI
NdisUnchainBuffeFreR maahannel(  IS_STATUPfN*/Ratus,
 D*IN* ma_HANDL_PADHANDAPI
NdisUnchainBuffeSetup maTrans   (  IS_nSendCompleteHandler; \
  } DUMMYUNIOPfN*/Ratus,
 D*IN* ma_HANDL} DUMMYUNIOPfN*/R       /B     CS_ 

#elseCediaer _NDIS_PROTOCOL_CtediaerL
NdisFDISAP NDISBOOLEAN  Writ,ToHavicr_PADHANDAPI
 T       CO_AF_REGISUpcaseU _NDICS_ 

#else*ISALCe Buf          OD_e DDKAPIOCOL_._NDICS_ 

#else*ISALCe Buf          OD_e FNDIS_HANDLCeGener  St\
  P0_PROTLookah            c INIUNIOPfN*/R      SytHANDLr;
 CAF_REGISUpcaseU _NDICS_ 
Ua_PADHANDAPI
NdisUncha*/RronERRUPT, *PfN*/RronERRUPT  DDtypedefSstruct _MAP_REGIST   ENTRYr{
	*DDKAPILapRegistri;
	BOOLEAN  Writi6F_REGISUpcaseU _NDICSe Buf  Is_HANDLr) CO_AF_REGISUpcaseU _NDIC
        _DSt\
    o7 )Ce               chainBuff          chainBuffI P_REGIST   ENTckeRatus,
 D*IN* ma_HANDL} DUMMYUndstruct _MAP_REGIST   ENTRYr{
	*DDKAPILapRegistri;
	BOOLEAN  Writi6F_REGISUpcaseU _NDICSe Brans       ComRatus,
 D*IN* ma_HANDL} DUMMYUnd ediaerCharactriistic     

#elseC;Writi6F_REGISUpcaseU _NDIEN BLOCK {Buf*DDKAPILac_HANDL;BuffN*/tatus,
 DBinding_HANDL;BS0_PROTS= NULSpecific_PADTTTTTTTTTT struct _MAP_REGIST   ENTRYYYYYYYr{
	*DDKAPILapRegistri;
	BOOLEAN  Writi6F_REGISUpcaseU _NDtrimc  ate minDKAPILookah             

#          GISUpcaseU _NDICS_           oDTTTTTTTatus,
 D*IN*WrapGISMTrans       CompleeGener  St\tatus,
 DLiniport*/ NDIS_S0_PROTS= NULSpecific_PA_LENGTt) rPa
    o7 )Ce               chainBuff          chainBuffI P_REGIST   ENTckeRatus,
 D*IN* ma_HANDL} DUMMB}ttHANDGISTTt) rPa
    o       chainBuffI GISTTt) rPaah             

#             chainBuff          cha        CK cT  Bufffffs,
 D*IN* ma_HANDL} DUMMB}ttHANDUnbISTTt) rPa
    o       chainBuffI UnbISTTt) rPaah             

#             chainBffffs,
 D*IN* ma_HANDL} DUMMrtCS_ 

#efDampTic
    o7 )Ce               chainBuff          chainBuffI P_REBufPfN*/ROPEN ffffs,
 D*IN* ma_HANDL} DUMMCK cTt) rPa
    o7 )Ce               chainBuff   7 )Ce               * maComp;_r       l  DDtypedefSstK cT  Bufffffs,
      *e       * mcitus,M_S0_PROTS= NULSpecific_PA_LENGTTain *WtMINIPORT DALLBACK)(S_ 

#elsefN*/Ratus,
 DLiniport*/ NDISadHandl_PROTOCOL_C 0_PROT_allba  adHandl(  _ntt(_Rout _BPafor i tr   }pedefS     nchae               chainBuff   7 )fS     nchae            Reserved2;BufBOOLEAN  l_PROTOCOL_C 0_PRERRUPT     l  DECLlR_ntt(_Rout _BPafOTS=DLr;
f l_PROTOCOL_CERRUPT    dCompletiniport*/ NCe               * maComp;_r    Reservedpper_HANDLFDIDtypedefSstK cT  Bufffffs,
      *e       * mcitus        pper_HANDLFDIactriistic     

#elseCKNOWNRDROeservedSec*/ NCe               * maComp;_rRN*/ROPEN ffffs,
 D*IN* ma_HANDL} DUMMCK cTt) rPa
    ENGTTain *WtMINIPORT DALhainBuff   7 )fS     nchaport*/ NDISadHaUnchainBuffeFreR Reservedper; \
  CS_c INUBOOLEAN         ingReset);t cke	    _B	E_MAO \
  } DUin W;Buows XPstri;_MAPsChain);ttt(_HAND 4MACaUnchainBuffeFreR* ckettypedefS     (nchai*st_HAt*/ NDISDDKAPILac_HAND    * mcitus,M_S0_PROTS= NULSpecific_PA_LENGTTan *WtMINIPORT*iniport*/ NDISadHandl_*/Ratus,
 DLiniport*/ NDISadHandl_PROTOCOL_C 0_PROT_allba  adHandl(  _ntt(_Rout _BPafor i tr   }pedefS     nchae               c2;BufBOOLEAN  l_PROTOCOL_oDTTTTTTTatus,
    pSizeMedCompletr(  c INUS  SOTS=DLr;
f l_PROTOCOL_CERRUPT    dCompletiniport*/ NANDLCS_c INUS dHandl(  _typedefS     n         ISComAt*/ NDISDDKAPILac_HANDOCOL_oDTTTTTTTatus,
 ffI GISTTt) rPaahettypedefS     (nchain *    ED
 *;BufPKEVE

NDCloseComac_HA)DDECLlRettypedefS     (nchain *    EinBRY_GLOBAL   (nffeFreSDDKAPILac_HANDOCOL_oDTTTTTTTatus,
 efN*/Ratus,
 uffeMiniport_    chainBuff          chainBacketHANDAPI
         UNLOAD4MACaDDKAPILac_HANDOCOL_oDTTTTTTTatus,
 ,
 rkINULadHandl(  _typedefS     n         ADDAt*/ NDISDDKAPILac_HANDOCOL_oDTTTTTTTatus,
 ,
 rkINULa(  IS_STATUS  Status,
 D*IN*Wrapper_HANDLFDISAP NDISS0_PROCOL_C 0_PRERRUPT     l  DECLlainBacketHANDAPI
 *REMOVmAt*/ NDISDDKAPILac_HANDOCOL_oDTTTTTTTatus,
 efN*/Ratus,
 uainBacketHAND RCompleteLinACaUnchainBuffeFreR           Major    VegiLENGTH_O      Minor    VegiLENGTH_OIiaerRegi; \
GTH_st_HAt*/ NDISDDKAPIL SOTS=fN*/Ratus,
 DSet;B SComAt*/ NDISDDKAPIL{
fff ffN*/Ratus,
 DSet;BDLr;
  TRANS    DATAECOMPLETERecet) _HANDLr;
  RECEIVEECOMPLETEE2; \
 R DRe; \
  Completr_HANDLr;
 UI     _Bd(_fN*/R)BuftediaerferAt;Buf ediainBRY_GLOBAL   (nffeFreSDDKAPILRCV_COMEN COBpeci);t ckAt;Buf ediaUNLOAD4MACaDDKAPILrtCSload BLOCK eL ediaADDAt*/ NDISDDKAPIL    dfN*/Ratus,
 DSet;BREMOVmAt*/ NDISDDKAPILRK_ITEMSfN*/Ratus,
 DSet;B 0_PRERRUPT    ECOM}HAND 4MACaUnchainBuffeFreER  FddiDMACaUnchainBuffeFreinBacketHA	eteLinACaUnchainBuffeFreRRRRRRRReteLiD
 *MACaUnchainBuffeFreinacketHA	eteLiD
 *MACaUnchainBuffeFreRRRR  FddiDD
 *MACaUnchainBuffeFreinGISMtHAN  DDtypOOLD
 *MACaUnchainBuffeFra chILrtCSload BLOCK eL ediaADDAt*/ NDISDDKAPIL chainBuffeFreinGISSIRmAt*/ NDISDDKAPN*/Ratus,tus,
 efN*/RatmpleteLinACaUnchainBuffeFT(8   B	(*((PfN*/DISDDKAPILac_HAND    * mcitus,M_S0_PROTS= NULde/ddk//Rasguid.hCaUnchainBuffeFT(8   B	(*((PfN*/DISDDKAPILac_HAND    * mcitus,M_S0_PROTSSSSSSS0100644 0000764 0001040 00000041152 10601620205S016570  0CaUnchainBuffeFT(8   B	(*((PfN*/DISDDKAPILac_HAND    * mcitus,M_S0_PROTSSSSSSSSSSSSSSSSSSSSSSSSSSSSSustar   iron    SSSSSSSSSSSSSSSSSSSSSSSSAdInitaeratorsCaUnchainBuffeFT(8   B	(*((PfN*/DISDDKAPILac_HAND    * mcitus,M_S0_PROTSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSL)ADHA/Rasguid.hADHADHAaHisREGISUpcase       ADHADHAThiREGile iREpart of the w32apiEpackage.ADHADHAr        ors:ADHA R UPfN*OTOCOCasDKA S. HornaerRp <chorna@uDSes.L_CHARGISge.net>ADHADHATHaseSOFTWARE aseNOT COPYRIGHTEDADHADHAThiREL_CHAR fSst iREo    *OTGISUuDS*/ Nthe public domain. You mayADHAuDS, moRaty ISUdtaer    e it freely.ADHADHAThiREfSst iREdtaer    ed*/ Nthe hopeNthat it w