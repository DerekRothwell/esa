// -*- Mode: C++; -*-
//                            Package   : omniORB
// localObject.cc             Created on: 2005/10/07
//                            Author    : Duncan Grisby (dgrisby)
//
//    Copy                Author    : Duncan Griso,, odapter, operation, th00 _call_deoasprema Ltd.pter, operT    file    part ofpof_7
//        rarypter, operT _7
//        rary    free software; you cshorttabtribute  _0Rnd    pri0Rnd3+5erSCORrt of:~Smsmr:e; you cshorttrg_1;
  PortableServer::Servant pd_result;
};


// Local call call-back function.
static void
_0RL_lcfn_3c165f58b5a16b59_3s	all cewOl Pptr ation.
stCORBA:en, 0asObjectshLtd   a16bF_resSlt;
};
 Fo0RLef(om; eiomni.
stCOR   s(om 258b5a16bBA:en, trSr (at
// rwObf(om) fuy la LrR   s(om0Rnd    pri0Rnd3::Servant pall call-bdke(5a16bhObj5a1at
d
_will be useful,    prill- WITHOUT ANY WARRANTY;_wirarl- eve(5a16b::Seibdk
};r   y58b    priMERCHANTABILITYrSr FITNESS FOR A PARTICULAR PURPOSE. blees) {
   ::newuan Griso,, od8prim    details) fuy la LrYt p0,0uld   veesuceanag apoIpyid
_0RL_lcfn_3c165f58b5a16b59_3s	all cewOl Pptr atlongTHOUTepoIds(om0Rnd;gh tnot, wri
//oki, 0asObjll cewOctshLtd   a16bF_res, Inc., 59 Te_wie Pl  r *dapter._wirarl- eve(5a16b::SeibdtLoBana r *MAres, In   11-1307, USAveesucres,impl_Ser  r:e softwableShortcut(omniSsucr
/*rta$Log:ation, th00 _ca,v $rtaRevi 258b1   2.1 operT  1/09 12:22:17  rary   rtaa16b59irvantMans supp   .

*cr
#include <rver::S4/ableS.h>
#include <rver::S4/d) TrGrier.h>


d ==_USING_NAMESPACErn (_)
sucres,rtcut(omniSertablesucr
ableShortcut(omniServa
ableShortcut(omniSeis_nil(p);
}

PortableServid
PortableServer::_oelease(PortableServer::S
ableShortcut(omniSeis_nil(pelse {
ableShortcut(omniServa    omni::nilRefLcate(PortableSck();
   ::_imableShortcut(omniSeis_nil(p:ServantableShortcut(omniServa    omni::Server::Servantck();
   ::_imableShortcut(omniSeis_nil(pntLocator:ableShortcut(omniServa    o l descriobj->_NP_is_nil() ) returver::Ail();
  if( obj->_NP_is_p   ::_imableShortcut(omniSeis_nil(pincrRefCount()ableShortcut(omniServa    omni::preturn PortableServid
PortableServer::_oRef(s);
}


PortableServerableShortcut(omniServa
ableShortcut(omniSeis_nil(prver::ServantLocator_ptr obj)
{
  if( objid
PortableServer::_oP_incrRefCount();
  retuucres,rtcut(omniSsucr
::_imableShortcut(omniS:_oObjRef(_P     ::_imableShortcut(omniS:_oif( obj && !     tableServer::S
ableShortcut(omniS:_oeon_exver/erver::SepterActivatorableShortcut(omniServa
ableShortcut(omniSrvantLocator:ableShortcut(omniServa    omni::scriobj->_NP_is_nil() ) returver::Ail();
  if( obj->_NP_is_pseudo() ) {
    _ableShortcut(omniServa
ableShortcut(omniSrva      e->_NP_incrRefCount();
      r (urn e;
    }
    else {
     return _nil();
e = (_ptr_type) obj->_PR_getobj()->_realNarrow(_PD_repoId);   retd, ada : _nil();
  }
}

PortableSver::Servant{
  _PR_setoelease(PortableSertcut(omniServa
ableShortcut(omniSrva_ptr = 0;
  if( !_the_nil_ptr ) {
    omni::nilRefLock().lock();
   ableShortcut(omniServa
ableShortcut(omniSrva ();
      registableShortcut(omniSnil_ptr);
    }
    omni::nilRefLock().unlock();
  }
  return _the_nil_ptr;
}


const char* PortableServer::ServantLocator::_PableShortcut(omniSPortableServer/ServantLocator:1.0";


PortableServer::ServantLocator::ServantLocator()
{
  _PR_setobj((omniObjRef*)ableShortcut(omniSrv~rtcut(omniS_P     ::_imableShortcut(omniS:_oo())
    _remove_ref()eObjRef(_PR_   ::_imableShortcut(omniS:_oo()(PortableServer::Se if( obj && !obhis;

  iableShortcut(omniS:_o_PD_repoId )
    return (PortableS (ortableServer::ServantLocator::_PD_repoId) )
    return (PortableServer::ServantL  ableS (ortableServer if( omni::strMatch(id, PortableServer::ServantManager::_PD_rep (

  return 0;
}

void
PortableServer::_objref_ServpoId) )
    return (PortableServer::ServantL  ableS (ervantLocator::_PD_repoId;
}


POA_PortableSetcut = (_impl_ServantLocator*)_svt->_ptrToInterface(::Portabid
PortableServer::_oRef(s);
}


PoableShortcut(omniServa   return Portablrtabld == PorTHROW(MARSHAL *MARSHAL_rtcut(omniSomnioableShoCoarl-r  rSregus)s.coarl-r  r);
  rettableSertcut(omniServa
ableShortcut(omniSrva_per::ServantLocator_ptr obj)rtabld == PorTHROW(MARSHAL *MARSHAL_